-- MySQL dump 10.13  Distrib 5.7.18, for Linux (x86_64)
--
-- Host: localhost    Database: tttp
-- ------------------------------------------------------
-- Server version	5.7.18-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `capcoquanquanly`
--

DROP TABLE IF EXISTS `capcoquanquanly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capcoquanquanly` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `ma` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `cha_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKql46k6sa1y99p4irrs1y4gm` (`nguoiSua_id`),
  KEY `FKnbmssluv9b76okncln5bv6ve8` (`nguoiTao_id`),
  KEY `FK226iui4n9f6kwwwt3ose76fl2` (`cha_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capcoquanquanly`
--

LOCK TABLES `capcoquanquanly` WRITE;
/*!40000 ALTER TABLE `capcoquanquanly` DISABLE KEYS */;
INSERT INTO `capcoquanquanly` VALUES (1,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','001','Cấp Chính phủ','Cấp Chính phủ',1,1,NULL),(2,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','002','UBND Tỉnh, TP','UBND Tỉnh, TP',1,1,1),(3,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','003','UBND Quận, Huyện','UBND Quận, Huyện',1,1,2),(4,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','004','UBND Phường, Xã, Thị trấn','UBND Phường, Xã, Thị trấn',1,1,3),(5,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','005','Sở ban ngành','Sở ban ngành',1,1,2),(6,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','006','Phòng ban','Phòng ban',1,1,5),(7,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','007','Chi cục','Chi cục',1,1,5),(8,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','008','Cấp Bộ, Ngành','Cấp Bộ, Ngành',1,1,1),(9,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','009','Tổng cục','Tổng cục',1,1,8),(10,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','010','Cục','Cục',1,1,8),(11,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','011','Vụ','Vụ',1,1,8),(12,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','012','Trung tâm','Trung tâm',1,1,8),(13,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','013','Cục thuộc Tổng cục','Cục thuộc Tổng cục',1,1,9),(14,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','014','Vụ thuộc Tổng cục','Vụ thuộc Tổng cục',1,1,9),(15,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','015','Trung tâm thuộc Tổng cục','Trung tâm thuộc Tổng cục',1,1,9),(16,'\0','2017-04-23 13:55:52','2017-04-23 13:55:52','016','Cơ quan hành chính sự nghiệp','Cơ quan hành chính sự nghiệp',1,1,5);
/*!40000 ALTER TABLE `capcoquanquanly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capdonvihanhchinh`
--

DROP TABLE IF EXISTS `capdonvihanhchinh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capdonvihanhchinh` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `ma` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3fh3i3p8mx3dnvle2fd1g3inc` (`nguoiSua_id`),
  KEY `FKfr9ltxr889al8r58kide6qp5q` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capdonvihanhchinh`
--

LOCK TABLES `capdonvihanhchinh` WRITE;
/*!40000 ALTER TABLE `capdonvihanhchinh` DISABLE KEYS */;
INSERT INTO `capdonvihanhchinh` VALUES (1,'\0','2017-04-23 11:06:20','2017-04-23 11:06:22','001','Tỉnh','Cấp tỉnh',1,1),(2,'\0','2017-04-23 11:06:20','2017-04-23 11:06:22','002','Huyện','Cấp Huyện',1,1),(3,'\0','2017-04-23 11:06:20','2017-04-23 11:06:22','003','Xã','Cấp Xã',1,1),(4,'\0','2017-04-23 11:06:20','2017-04-23 11:06:22','004','TP','TP trực thuộc TW',1,1),(5,'\0','2017-04-23 11:06:20','2017-04-23 11:06:22','005','Quận','Cấp Quận',1,1),(6,'\0','2017-04-23 11:06:20','2017-04-23 11:06:22','006','Phường','Cấp Phường',1,1),(7,'\0','2017-04-23 11:06:22','2017-04-23 11:06:22','007','Thị trấn','Thị trấn',1,1),(8,'\0','2017-04-23 11:06:22','2017-04-23 11:06:22','008','Thị xã','Thị xã',1,1),(9,'\0','2017-04-23 11:06:22','2017-04-23 11:06:22','009','TP trực thuộc tỉnh','TP trực thuộc tỉnh',1,1);
/*!40000 ALTER TABLE `capdonvihanhchinh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chucvu`
--

DROP TABLE IF EXISTS `chucvu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chucvu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKa4m4n19mqfls51jse63v2ncyw` (`nguoiSua_id`),
  KEY `FK2dhtqx8qhmlx7c0gf4tl03jmf` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chucvu`
--

LOCK TABLES `chucvu` WRITE;
/*!40000 ALTER TABLE `chucvu` DISABLE KEYS */;
INSERT INTO `chucvu` VALUES (1,'\0','2017-06-05 10:37:34','2017-04-24 10:38:09','Lãnh đạo','Lãnh đạo',1,1),(2,'\0','2017-06-05 10:35:56','2017-04-24 10:38:15','Trưởng phòng','Trưởng phòng',1,1),(3,'\0','2017-06-05 10:36:09','2017-05-03 15:56:59','Chuyên viên','Chuyên viên',1,1),(4,'\0','2017-06-05 10:37:27','2017-05-03 15:59:46','Chuyên viên nhập liệu','Chuyên viên nhập liệu',1,1);
/*!40000 ALTER TABLE `chucvu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chungchihanhnghe`
--

DROP TABLE IF EXISTS `chungchihanhnghe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chungchihanhnghe` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `duongDan` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ma` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `congDan_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKpalqugnxv6moc20ivs1sjybbh` (`nguoiSua_id`),
  KEY `FKl9aqo0q30ficruu92la0xnkkh` (`nguoiTao_id`),
  KEY `FK34nvh79x3thvpo652yyjd35i0` (`congDan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chungchihanhnghe`
--

LOCK TABLES `chungchihanhnghe` WRITE;
/*!40000 ALTER TABLE `chungchihanhnghe` DISABLE KEYS */;
/*!40000 ALTER TABLE `chungchihanhnghe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `congchuc`
--

DROP TABLE IF EXISTS `congchuc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `congchuc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `dienThoai` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `gioiTinh` bit(1) NOT NULL,
  `hoVaTen` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `chucVu_id` bigint(20) DEFAULT NULL,
  `coQuanQuanLy_id` bigint(20) DEFAULT NULL,
  `nguoiDung_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKt6pg6su8p9bg5h1cgxswpkam5` (`nguoiSua_id`),
  KEY `FK5vpxg545trubavoaane211k5p` (`nguoiTao_id`),
  KEY `FKd2p1qcfhvws57wdftekjkhund` (`chucVu_id`),
  KEY `FKsedbgmc9y7moxeg2byas7gafw` (`coQuanQuanLy_id`),
  KEY `FKagb75px243w4ihob0ff4xg674` (`nguoiDung_id`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `congchuc`
--

LOCK TABLES `congchuc` WRITE;
/*!40000 ALTER TABLE `congchuc` DISABLE KEYS */;
INSERT INTO `congchuc` VALUES (1,'\0','2017-06-10 16:06:31','2017-04-24 10:49:48','01206189116','','Administrator',1,1,1,2,1),(2,'\0','2017-06-10 16:07:05','2017-05-03 15:30:58','01206189116','','Tran Vo Dinh Nam',1,1,2,90,2),(3,'\0','2017-06-10 16:07:10','2017-05-03 15:51:28','01206189116','','Phạm Xuân Thành',1,1,3,90,4),(4,'\0','2017-06-10 16:07:01','2017-05-03 15:52:46','01206189116','','Võ Tiến An',1,1,4,2,5),(5,'\0','2017-06-10 16:07:07','2017-05-17 19:06:57','01206189445','','Lý Văn Vinh',1,1,2,90,6),(6,'\0','2017-06-10 16:07:13','2017-05-17 19:42:57','01206185446','','Huỳnh Quang Thắng',1,1,3,90,7),(7,'\0','2017-06-10 16:07:27','2017-05-17 19:43:49','01204548796','','Tôn Thất Toàn',1,1,3,90,8),(8,'\0','2017-06-10 16:06:34','2017-05-17 19:44:59','01206132554','','Thanh Tra Thành Phố',1,1,1,2,9),(9,'\0','2017-06-10 16:06:40','2017-05-17 19:47:34','01206541254','','Hà Xuân Thành',1,1,1,2,10),(10,'\0','2017-06-10 16:06:43','2017-05-17 19:52:42','01206523664','','Phùng Duy Thiện',1,1,1,2,11),(11,'\0','2017-06-10 16:06:37','2017-05-17 19:53:38','01206214552','','Trần Xuân Vũ',1,1,1,2,12),(12,'\0','2017-06-11 08:58:45','2017-05-31 16:37:56','01204512665','','Sở Tài Nguyên Môi Trường',1,1,1,14,13),(13,'\0','2017-06-11 08:58:42','2017-05-31 16:39:46','0905463253','','Nguyễn Văn Mỹ',1,1,3,91,14),(14,'\0','2017-06-10 16:15:31','2017-05-31 16:44:22','01206154221','','Trần Tiến Hùng',1,1,2,91,15),(15,'\0','2017-06-10 16:15:19','2017-05-31 16:46:51','01206125441','','Lê Thị Nhàn',1,1,2,91,16),(16,'\0','2017-06-11 08:57:54','2017-06-10 17:23:12','01206189116','','Nguyễn Văn Nam',1,1,3,91,18),(17,'\0','2017-06-11 08:58:27','2017-06-10 17:24:09','01206189116','','Nguyễn Phạm Xuân Hùng',1,1,3,91,19),(18,'\0','2017-06-11 08:59:18','2017-06-10 17:24:53','01206189116','','Vũ Ngọc Bằng',1,1,1,14,20),(19,'\0','2017-06-11 09:02:49','2017-06-10 17:25:33','01206189116','','Võ Thị Huyền Trân',1,1,1,14,21),(20,'\0','2017-06-11 09:31:43','2017-06-11 09:31:43','01206189116','','Hoàng Anh Vũ',1,1,1,14,22),(21,'\0','2017-06-11 09:34:12','2017-06-11 09:34:12','01206189116','','Trần Thị Thu Thùy',1,1,4,14,23),(22,'\0','2017-06-11 09:35:23','2017-06-11 09:35:23','01206189116','','Nguyễn Đại Đồng',1,1,2,123,24),(23,'\0','2017-06-11 09:36:09','2017-06-11 09:36:09','01206189116','','Bùi Văn Vượng',1,1,2,93,25),(24,'\0','2017-06-11 09:37:52','2017-06-11 09:37:52','01206189116','','Phạm Nguyên Phong',1,1,3,93,26),(25,'\0','2017-06-11 09:38:33','2017-06-11 09:38:33','01206189116','','Quán Đức Bình',1,1,3,93,27),(26,'\0','2017-06-11 09:39:01','2017-06-11 09:39:01','01206189116','','Đinh Đức Trọng',1,1,3,93,28),(27,'\0','2017-06-11 09:39:50','2017-06-11 09:39:50','01206189116','','Tạ Bá Thành Huy',1,1,2,94,29),(28,'\0','2017-06-11 09:41:36','2017-06-11 09:40:27','01206189116','','Phạm Công Toàn',1,1,2,94,30),(29,'\0','2017-06-11 09:41:39','2017-06-11 09:41:17','01206189116','','Nguyễn Trường Thành',1,1,3,94,31),(30,'\0','2017-06-11 09:42:06','2017-06-11 09:42:06','01206189116','','Hoàng Nhât Trường',1,1,3,94,32),(31,'\0','2017-06-11 09:42:33','2017-06-11 09:42:33','01206189116','','Phan Quốc Việt',1,1,3,94,33),(32,'\0','2017-06-11 09:48:07','2017-06-11 09:48:07','01206189116','','Sở Giao Thông Vận Tải',1,1,1,4,34),(33,'\0','2017-06-11 09:48:41','2017-06-11 09:48:41','01206189116','','Nguyễn Quốc Bão',1,1,1,4,35),(34,'\0','2017-06-11 09:49:10','2017-06-11 09:49:10','01206189116','','Lê Văn Vĩnh Tín',1,1,1,4,36),(35,'\0','2017-06-11 09:49:34','2017-06-11 09:49:34','01206189116','','Nguyễn Đăng Hòa',1,1,1,4,37),(36,'\0','2017-06-11 09:50:01','2017-06-11 09:50:01','01206189116','','Phạm Ngọc Thao',1,1,4,4,38),(37,'\0','2017-06-11 09:51:24','2017-06-11 09:51:11','01206189116','','Võ Hoàng Phương Dung',1,1,2,96,39),(38,'\0','2017-06-11 09:51:49','2017-06-11 09:51:49','01206189116','','Nguyễn Lê Ngọc Vỹ',1,1,2,96,40),(39,'\0','2017-06-11 09:52:11','2017-06-11 09:52:11','01206189116','','Nguyễn Hữu Hiếu',1,1,3,96,41),(40,'\0','2017-06-11 09:52:51','2017-06-11 09:52:51','01206189116','','Võ An Ninh',1,1,3,96,42),(41,'\0','2017-06-11 09:53:16','2017-06-11 09:53:16','01206189116','','Nguyễn Văn Minh',1,1,3,96,43),(42,'\0','2017-06-11 09:53:43','2017-06-11 09:53:43','01206189116','','Võ Văn Thành',1,1,2,97,44),(43,'\0','2017-06-11 09:54:16','2017-06-11 09:54:16','01206189116','','Nguyễn Tri Thành',1,1,2,97,45),(44,'\0','2017-06-11 09:54:38','2017-06-11 09:54:38','01206189116','','Lê Đức',1,1,3,97,46),(45,'\0','2017-06-11 09:55:05','2017-06-11 09:55:05','01206189116','','Trương Ngọc Âu',1,1,3,97,47),(46,'\0','2017-06-11 09:55:25','2017-06-11 09:55:25','01206189116','','Nguyễn Hoàng Vũ',1,1,3,97,48),(47,'\0','2017-06-11 09:58:10','2017-06-11 09:58:10','01206189116','','Sở Xây Dựng',1,1,1,17,49),(48,'\0','2017-06-11 09:59:49','2017-06-11 09:59:49','01206189116','','Nguyễn Thị Thanh Hòa',1,1,1,17,50),(49,'\0','2017-06-11 10:00:17','2017-06-11 10:00:17','01206189116','','Trần Văn Lành',1,1,1,17,51),(50,'\0','2017-06-11 10:00:46','2017-06-11 10:00:46','01206189116','','Nguyễn Tri Giảng',1,1,1,17,52),(51,'\0','2017-06-11 10:01:12','2017-06-11 10:01:12','01206189116','','Lê Phước Khanh',1,1,4,17,53),(52,'\0','2017-06-11 10:01:44','2017-06-11 10:01:44','01206189116','','Thân Vĩnh Minh',1,1,2,135,54),(53,'\0','2017-06-11 10:02:06','2017-06-11 10:02:06','01206189116','','Hồ Minh Tuấn',1,1,2,135,55),(54,'\0','2017-06-11 10:02:30','2017-06-11 10:02:30','01206189116','','Trương Ngọc Tiến',1,1,3,135,56),(55,'\0','2017-06-11 10:02:51','2017-06-11 10:02:51','01206189116','','Hồ Chí Thành',1,1,3,135,57),(56,'\0','2017-06-11 10:03:23','2017-06-11 10:03:23','01206189116','','Đỗ Quang Thắng',1,1,3,135,58),(57,'\0','2017-06-11 10:03:54','2017-06-11 10:03:46','01206189116','','Lê Duy Tân',1,1,2,136,59),(58,'\0','2017-06-11 10:04:18','2017-06-11 10:04:18','01206189116','','Đặng Trần Chí Toàn',1,1,2,136,60),(59,'\0','2017-06-11 10:04:44','2017-06-11 10:04:44','01206189116','','Lưu Trọng Nghĩa',1,1,3,136,61),(60,'\0','2017-06-11 10:05:07','2017-06-11 10:05:07','01206189116','','Lê Kim Tuấn',1,1,3,136,62),(61,'\0','2017-06-11 10:05:33','2017-06-11 10:05:33','01206189116','','Trần Lê Quang Phú',1,1,3,136,63),(62,'\0','2017-06-11 10:08:28','2017-06-11 10:08:28','01206189116','','UBND quận Thanh Khê',1,1,1,20,64),(63,'\0','2017-06-11 10:08:57','2017-06-11 10:08:57','01206189116','','Trần Thị Thu Huyền',1,1,1,20,65),(64,'\0','2017-06-11 10:09:27','2017-06-11 10:09:27','01206189116','','Thôi Hiển Chính',1,1,1,20,66),(65,'\0','2017-06-11 10:11:56','2017-06-11 10:11:42','01206189116','','Dương Anh Hào',1,1,1,20,67),(66,'\0','2017-06-11 10:12:19','2017-06-11 10:12:19','01206189116','','Bùi Thị Hoài Thương',1,1,4,20,68),(67,'\0','2017-06-11 10:14:07','2017-06-11 10:14:07','01206189116','','Bùi Thị Thu Thủy',1,1,2,144,69),(68,'\0','2017-06-11 10:14:39','2017-06-11 10:14:39','01206189116','','Trần Thanh Hoài',1,1,2,144,70),(69,'\0','2017-06-11 10:15:20','2017-06-11 10:15:20','01206189116','','Trần Xuân Sang',1,1,3,144,71),(70,'\0','2017-06-11 10:16:13','2017-06-11 10:16:13','01206189116','','Lê Văn Tình',1,1,3,144,72),(71,'\0','2017-06-11 10:16:36','2017-06-11 10:16:36','01206189116','','Trương Công Nguyên Thanh',1,1,3,144,73),(72,'\0','2017-06-11 10:17:49','2017-06-11 10:17:49','01206189116','','Kpă Hương',1,1,2,145,74),(73,'\0','2017-06-11 10:18:28','2017-06-11 10:18:28','01206189116','','Đỗ Thị Trang Thương',1,1,2,145,75),(74,'\0','2017-06-11 10:18:48','2017-06-11 10:18:48','01206189116','','Nguyễn Thị Hồng',1,1,3,145,76),(75,'\0','2017-06-11 10:19:26','2017-06-11 10:19:26','01206189116','','Nguyễn Xuân Hoàn',1,1,3,145,77),(76,'\0','2017-06-11 10:20:01','2017-06-11 10:20:01','01206189116','','Đinh Hải Nam',1,1,3,145,78),(77,'\0','2017-06-11 10:24:55','2017-06-11 10:24:55','01206189116','','UBND quận Hải Châu',1,1,1,21,79),(78,'\0','2017-06-11 10:25:23','2017-06-11 10:25:23','01206189116','','Lê Văn Cương',1,1,1,21,80),(79,'\0','2017-06-11 10:25:48','2017-06-11 10:25:48','01206189116','','Võ Trần Chí',1,1,1,21,81),(80,'\0','2017-06-11 10:26:14','2017-06-11 10:26:14','01206189116','','Nguyễn Cao Tuấn',1,1,1,21,82),(81,'\0','2017-06-11 10:26:38','2017-06-11 10:26:38','01206189116','','Nguyễn Thị Yến Vy',1,1,4,21,83),(82,'\0','2017-06-11 10:26:59','2017-06-11 10:26:59','01206189116','','Thái Thị Hương',1,1,2,147,84),(83,'\0','2017-06-11 10:27:22','2017-06-11 10:27:22','01206189116','','Trần Thị Uyên Trang',1,1,2,147,85),(84,'\0','2017-06-11 10:27:42','2017-06-11 10:27:42','01206189116','','Hoàng Thị Thu',1,1,3,147,86),(85,'\0','2017-06-11 10:28:07','2017-06-11 10:28:07','01206189116','','Nguyễn Đặng Khiêm An',1,1,3,147,87),(86,'\0','2017-06-11 10:30:01','2017-06-11 10:30:01','01206189116','','Nguyễn Đình Huy',1,1,3,147,88),(87,'\0','2017-06-11 10:30:29','2017-06-11 10:30:29','01206189116','','Nguyễn Hoàng Gia',1,1,2,148,89),(88,'\0','2017-06-11 10:30:56','2017-06-11 10:30:56','01206189116','','Phạm Trúc Mai',1,1,2,148,90),(89,'\0','2017-06-11 10:31:28','2017-06-11 10:31:28','01206189116','','Huỳnh Cao Huyền Trâm',1,1,3,148,91),(90,'\0','2017-06-11 10:31:56','2017-06-11 10:31:56','01206189116','','Nguyễn Thị Bích Vân',1,1,3,148,92),(91,'\0','2017-06-11 10:32:17','2017-06-11 10:32:17','01206189116','','Nguyễn Thị Ánh Nga',1,1,3,148,93),(92,'\0','2017-06-11 10:33:59','2017-06-11 10:33:59','01206189116','','UBND phường Tân Chính',1,1,1,36,94),(93,'\0','2017-06-11 10:36:42','2017-06-11 10:36:42','01206189116','','UBND phường Thanh Bình',1,1,1,42,95),(94,'\0','2017-07-21 00:46:29','2017-07-21 00:46:29','','\0','UBND Thành phố Đà Nẵng',1,1,1,1,96),(95,'\0','2017-07-21 00:52:36','2017-07-21 00:50:31','','','Trần Văn Tám',1,1,4,165,97),(96,'\0','2017-07-21 00:52:23','2017-07-21 00:51:45','','','Lê Văn Hòa',1,1,2,165,98),(97,'\0','2017-07-21 00:52:17','2017-07-21 00:52:17','','','Trần Xuân Tiên',1,1,3,165,99),(98,'\0','2017-07-21 00:56:42','2017-07-21 00:56:42','','','Lê Xuân Mai',1,1,2,167,100),(99,'\0','2017-07-21 00:57:22','2017-07-21 00:57:22','','','Trần Tuấn Tú',1,1,3,167,101);
/*!40000 ALTER TABLE `congchuc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `congdan`
--

DROP TABLE IF EXISTS `congdan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `congdan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `diaChi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `gioiTinh` bit(1) NOT NULL,
  `hoVaTen` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `ngayCap` datetime DEFAULT NULL,
  `ngaySinh` datetime DEFAULT NULL,
  `soCMNDHoChieu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soDienThoai` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `danToc_id` bigint(20) DEFAULT NULL,
  `noiCapCMND_id` bigint(20) DEFAULT NULL,
  `phuongXa_id` bigint(20) DEFAULT NULL,
  `quanHuyen_id` bigint(20) DEFAULT NULL,
  `quocTich_id` bigint(20) DEFAULT NULL,
  `tinhThanh_id` bigint(20) DEFAULT NULL,
  `toDanPho_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8ceaui7e987tj9f7mltj76frh` (`nguoiSua_id`),
  KEY `FKlkhlre4pd0j9hh29fl0ukl4qo` (`nguoiTao_id`),
  KEY `FKpluk9dnwforiccib6l9hk8gek` (`danToc_id`),
  KEY `FKsw4o27m7new9e192nx2qglu65` (`noiCapCMND_id`),
  KEY `FK2lv30se81ev0gj0qyii981rsh` (`phuongXa_id`),
  KEY `FKioxhrhif5gvxdrchn9vo0qobh` (`quanHuyen_id`),
  KEY `FKd6x82c9yfp37e143ucaycy1l3` (`quocTich_id`),
  KEY `FKg6c7j69ne2q6tka6qtj0we9nc` (`tinhThanh_id`),
  KEY `FK2pa8vhiyhcgwvgbuu14u911o5` (`toDanPho_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `congdan`
--

LOCK TABLES `congdan` WRITE;
/*!40000 ALTER TABLE `congdan` DISABLE KEYS */;
INSERT INTO `congdan` VALUES (17,'\0','2017-07-13 18:20:38','2017-05-17 09:45:37','221 Hà Huy Tập nối dài','\0','Huỳnh Bảo Ngọc',NULL,'1989-02-09 00:00:00','201574408','0932110442',4,1,1,86,31,15,1,9,116),(16,'\0','2017-06-28 17:56:03','2017-05-16 20:44:21','K377/34 Hải Phòng','','Trần Võ Đình Nam','2010-11-19 17:00:00','1994-01-06 17:00:00','201702275','01206189116',4,1,1,86,31,15,1,9,107),(18,'\0','2017-06-28 17:51:51','2017-05-17 10:05:05','20 Nguyễn Huy Tưởng','','Lê Văn Quý',NULL,'1975-09-29 00:00:00','201425632','01206116305',4,1,NULL,86,26,14,NULL,9,61),(19,'\0','2017-06-28 17:55:03','2017-05-17 10:05:05','35 Phan Chu Trinh','','Võ Hoài Nam','2010-12-22 00:00:00','1983-10-05 00:00:00','201356214','0982137146',4,1,1,86,40,16,1,9,197),(20,'\0','2017-06-28 17:37:26','2017-05-17 10:05:05','12 Cù Chính Lan','\0','Đỗ Bảo Trân',NULL,NULL,'201356214','0982137146',4,1,1,86,35,15,1,9,147),(21,'\0','2017-06-28 17:54:28','2017-05-17 10:05:05','15 Tản Đà','','Trần Bá Hòa',NULL,'1975-09-29 00:00:00','201115642','008',4,1,NULL,86,34,15,NULL,9,140),(22,'\0','2017-06-28 17:51:51','2017-05-17 10:05:05','23 Phan Tứ','','Đặng Đình Cường',NULL,NULL,'201575538','',4,1,NULL,86,57,18,NULL,9,375),(23,'\0','2017-06-28 17:55:43','2017-05-17 10:05:05','30 Quang Trung','\0','Nguyễn Thị Kim',NULL,'1983-10-05 07:00:00','201245578','',4,1,NULL,86,40,16,NULL,9,197),(24,'\0','2017-06-28 17:53:53','2017-05-17 10:14:19','20 Nguyễn Huy Tưởng','','Nguyễn Văn Khải',NULL,NULL,'201426632','006',4,1,1,86,26,14,1,9,61),(25,'\0','2017-06-28 17:51:51','2017-05-17 10:40:57','88 Cần Giuộc','\0','Nguyễn Thị Trung Chinh','2012-01-24 00:00:00','1970-02-10 00:00:00','201052987','01206116305',4,1,1,86,36,15,1,9,165),(26,'\0','2017-06-13 18:06:26','2017-05-17 11:13:00','221 Trường Chinh','\0','Phạm Thị Cẩm Nhung',NULL,'1993-09-02 00:00:00','201648215','01214645823',3,1,1,86,35,15,1,9,155),(27,'\0','2017-06-28 17:56:25','2017-05-17 11:23:07','70 Nguyễn Lương Bằng','','Đinh Nguyễn Anh Khuê',NULL,'1993-10-05 00:00:00','201357214','0982137146',4,1,1,86,24,14,1,9,40),(28,'\0','2017-06-28 17:56:50','2017-05-17 11:36:30','70 Nguyễn Lương Bằng','\0','Dương Thanh Ái Quyên','2010-12-23 00:00:00','1993-09-29 00:00:00','201225632','01206116305',4,1,1,86,24,14,1,9,40),(29,'\0','2017-06-13 18:07:45','2017-05-17 12:40:20','534 Trần Cao Vân','','Huỳnh Quốc Đạt','2011-10-21 00:00:00','1987-09-23 00:00:00','201537408','0906345210',3,1,1,86,34,15,1,9,145),(30,'\0','2017-05-17 12:48:49','2017-05-17 12:48:49','30 Bà Huyện Thanh Quan','','Lê Quang Tuấn','2015-12-21 00:00:00','1987-09-20 00:00:00','201575786','01202052973',1,1,NULL,86,57,18,NULL,9,371),(31,'\0','2017-06-13 18:07:32','2017-05-17 12:48:49','24 Quang Trung','','Nguyễn Tiến Bá','2010-12-02 00:00:00','1983-10-05 00:00:00','205356214','0905234123',3,1,1,86,40,16,1,9,197),(32,'\0','2017-05-17 12:48:49','2017-05-17 12:48:49','50 Hà Huy Tập','\0','Nguyễn Hồng Quyên','2013-12-22 00:00:00','1981-06-05 00:00:00','201356467','0903300143',1,1,NULL,86,35,15,NULL,9,147),(33,'\0','2017-05-17 12:48:49','2017-05-17 12:48:49','43 Hồ Tùng Mậu','','Nguyễn Bá Quang','1999-12-23 00:00:00','1970-08-19 00:00:00','201422432','0973389168',1,1,NULL,86,26,14,NULL,9,61),(34,'\0','2017-05-17 12:48:49','2017-05-17 12:48:49','30 Quang Trung','\0','Trần Thị Nguyệt','1998-12-22 00:00:00','1976-10-05 00:00:00','201245523','0987371772',1,1,NULL,86,40,16,NULL,9,197),(35,'\0','2017-05-17 12:48:49','2017-05-17 12:48:49','15 Tản Đà','','Huỳnh Văn Chương','1991-12-23 00:00:00','1965-08-29 00:00:00','200213224','01636629861',1,1,NULL,86,34,15,NULL,9,140),(36,'\0','2017-06-13 18:07:14','2017-05-17 13:01:05','23 Ngô Thì Nhậm','','Trần Quang Diệu','2014-03-09 00:00:00','1978-09-29 00:00:00','204025632','01261246721',3,1,1,86,26,14,1,9,61),(37,'\0','2017-06-28 17:53:07','2017-05-17 14:03:24','12 Hàm Nghi','\0','Nguyễn Thị Nụ','2012-01-24 00:00:00','1970-02-10 00:00:00','201052966','01201090931',4,1,1,86,34,15,1,9,138),(38,'\0','2017-07-21 01:24:22','2017-07-21 01:24:22','400 Tôn Đản','','Huỳnh Văn Bách',NULL,NULL,'201578412','0936568789',95,95,1,86,68,19,1,9,485),(39,'\0','2017-07-21 01:30:22','2017-07-21 01:30:22','40 Quang Trung','','Trần Văn Đông',NULL,'1983-10-05 00:00:00','205356277','0905234123',4,4,1,86,40,16,1,9,197),(40,'\0','2017-07-21 01:33:16','2017-07-21 01:33:16','20/3 Ngô Thì Nhậm','\0','Nguyễn Thị Bông',NULL,NULL,'204028541','01206189445',4,4,1,86,26,14,1,9,59),(41,'\0','2017-07-21 01:35:04','2017-07-21 01:35:04','66 Phan Thanh','\0','Trương Thị Trang',NULL,NULL,'201052522','01205145226',4,4,1,86,34,15,1,9,138);
/*!40000 ALTER TABLE `congdan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coquanquanly`
--

DROP TABLE IF EXISTS `coquanquanly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coquanquanly` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `ma` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `capCoQuanQuanLy_id` bigint(20) NOT NULL,
  `cha_id` bigint(20) DEFAULT NULL,
  `donVi_id` bigint(20) DEFAULT NULL,
  `donViHanhChinh_id` bigint(20) NOT NULL,
  `loaiCoQuanQuanLy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKb5xnhgo4gm076ij94qfk2yxvw` (`nguoiSua_id`),
  KEY `FKbda07equ39nxg1exbow209u1t` (`nguoiTao_id`),
  KEY `FKjxxgfun75pmqjp1upgenk7q3p` (`capCoQuanQuanLy_id`),
  KEY `FK6g0yfb2vr2lrf7a96p11mb11j` (`cha_id`),
  KEY `FKpg1eakpstxhw4vpb9kuqt5aew` (`donVi_id`),
  KEY `FKqvda4xoqiflqmtx16b3df104a` (`donViHanhChinh_id`),
  KEY `FK7e22uj5l0xg0f6lgkb1lee6nk` (`loaiCoQuanQuanLy_id`)
) ENGINE=MyISAM AUTO_INCREMENT=168 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coquanquanly`
--

LOCK TABLES `coquanquanly` WRITE;
/*!40000 ALTER TABLE `coquanquanly` DISABLE KEYS */;
INSERT INTO `coquanquanly` VALUES (1,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','001','UBND Thành phố Đà Nẵng','UBND Thành phố Đà Nẵng',1,1,2,NULL,1,9,NULL),(2,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','002','Thanh tra thành phố','Thanh tra thành phố',1,1,5,1,2,9,NULL),(3,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','003','Sở Công Thương','Sở Công Thương',1,1,5,1,3,9,NULL),(4,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','004','Sở Giao thông Vận tải','Sở Giao thông Vận tải',1,1,5,1,4,9,NULL),(5,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','005','Sở Giáo dục và Đào tạo','Sở Giáo dục và Đào tạo',1,1,5,1,5,9,NULL),(6,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','006','Sở Khoa học và Công nghệ','Sở Khoa học và Công nghệ',1,1,5,1,6,9,NULL),(7,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','007','Sở Kế hoạch và Đầu tư','Sở Kế hoạch và Đầu tư',1,1,5,1,7,9,NULL),(8,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','008','Sở Lao động, Thương binh và Xã hội','Sở Lao động, Thương binh và Xã hội',1,1,5,1,8,9,NULL),(9,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','009','Sở Ngoại vụ','Sở Ngoại vụ',1,1,5,1,9,9,NULL),(10,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','010','Sở Nông nghiệp và Phát triển nông thôn','Sở Nông nghiệp và Phát triển nông thôn',1,1,5,1,10,9,NULL),(11,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','011','Sở Nội vụ','Sở Nội vụ',1,1,5,1,11,9,NULL),(12,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','012','Sở Thông tin và Truyền thông','Sở Thông tin và Truyền thông',1,1,5,1,12,9,NULL),(13,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','013','Sở Tài chính','Sở Tài chính',1,1,5,1,13,9,NULL),(14,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','014','Sở Tài nguyên và Môi trường','Sở Tài nguyên và Môi trường',1,1,5,1,14,9,NULL),(15,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','015','Sở Tư pháp','Sở Tư pháp',1,1,5,1,15,9,NULL),(16,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','016','Sở Văn hóa, Thể thao và Du lịch','Sở Văn hóa, Thể thao và Du lịch',1,1,5,1,16,9,NULL),(17,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','017','Sở Xây dựng','Sở Xây dựng',1,1,5,1,17,9,NULL),(18,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','018','Sở Y tế','Sở Y tế',1,1,5,1,18,9,NULL),(19,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','019','UBND quận Liên Chiểu','UBND quận Liên Chiểu',1,1,3,1,19,14,NULL),(20,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','020','UBND quận Thanh Khê','UBND quận Thanh Khê',1,1,3,1,20,15,NULL),(21,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','021','UBND quận Hải Châu','UBND quận Hải Châu',1,1,3,1,21,16,NULL),(22,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','022','UBND quận Sơn Trà','UBND quận Sơn Trà',1,1,3,1,22,17,NULL),(23,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','023','UBND quận Ngũ Hành Sơn','UBND quận Ngũ Hành Sơn',1,1,3,1,23,18,NULL),(24,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','024','UBND quận Cẩm Lệ','UBND quận Cẩm Lệ',1,1,3,1,24,19,NULL),(25,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','025','UBND huyện Hòa Vang','UBND huyện Hòa Vang',1,1,3,1,25,20,NULL),(26,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','026','UBND huyện Hoàng Sa','UBND huyện Hoàng Sa',1,1,3,1,26,21,NULL),(27,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','027','UBND phường Hòa Hiệp Bắc','UBND phường Hòa Hiệp Bắc',1,1,4,19,27,22,NULL),(28,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','028','UBND phường Hòa Hiệp Nam','UBND phường Hòa Hiệp Nam',1,1,4,19,28,23,NULL),(29,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','029','UBND Phường Hòa Khánh Bắc','UBND Phường Hòa Khánh Bắc',1,1,4,19,29,24,NULL),(30,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','030','UBND phường Hòa Khánh Nam','UBND phường Hòa Khánh Nam',1,1,4,19,30,25,NULL),(31,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','031','UBND phường Hòa Minh','UBND phường Hòa Minh',1,1,4,19,31,26,NULL),(32,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','032','UBND phường Tam Thuận','UBND phường Tam Thuận',1,1,4,20,32,27,NULL),(33,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','033','UBND phường Thanh Khê Tây','UBND phường Thanh Khê Tây',1,1,4,20,33,28,NULL),(34,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','034','UBND phường Thanh Khê Đông','UBND phường Thanh Khê Đông',1,1,4,20,34,29,NULL),(35,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','035','UBND phường Xuân Hà','UBND phường Xuân Hà',1,1,4,20,35,30,NULL),(36,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','036','UBND phường Tân Chính','UBND phường Tân Chính',1,1,4,20,36,31,NULL),(37,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','037','UBND phường Chính Gián','UBND phường Chính Gián',1,1,4,20,37,32,NULL),(38,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','038','UBND phường Vĩnh Trung','UBND phường Vĩnh Trung',1,1,4,20,38,33,NULL),(39,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','039','UBND phường Thạc Gián','UBND phường Thạc Gián',1,1,4,20,39,34,NULL),(40,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','040','UBND phường An Khê','UBND phường An Khê',1,1,4,20,40,35,NULL),(41,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','041','UBND phường Hòa Khê','UBND phường Hòa Khê',1,1,4,20,41,36,NULL),(42,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','042','UBND phường Thanh Bình','UBND phường Thanh Bình',1,1,4,21,42,37,NULL),(43,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','043','UBND phường Thuận Phước','UBND phường Thuận Phước',1,1,4,21,43,38,NULL),(44,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','044','UBND phường Thạch Thang','UBND phường Thạch Thang',1,1,4,21,44,39,NULL),(45,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','045','UBND phường Hải Châu I','UBND phường Hải Châu I',1,1,4,21,45,40,NULL),(46,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','046','UBND phường Hải Châu II','UBND phường Hải Châu II',1,1,4,21,46,41,NULL),(47,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','047','UBND phường Phước Ninh','UBND phường Phước Ninh',1,1,4,21,47,42,NULL),(48,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','048','UBND phường Hòa Thuận Tây','UBND phường Hòa Thuận Tây',1,1,4,21,48,43,NULL),(49,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','049','UBND phường Hòa Thuận Đông','UBND phường Hòa Thuận Đông',1,1,4,21,49,44,NULL),(50,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','050','UBND phường Nam Dương','UBND phường Nam Dương',1,1,4,21,50,45,NULL),(51,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','051','UBND phường Bình Hiên','UBND phường Bình Hiên',1,1,4,21,51,46,NULL),(52,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','052','UBND phường Bình Thuận','UBND phường Bình Thuận',1,1,4,21,52,47,NULL),(53,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','053','UBND phường Hòa Cường Bắc','UBND phường Hòa Cường Bắc',1,1,4,21,53,48,NULL),(54,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','054','UBND phường Hòa Cường Nam','UBND phường Hòa Cường Nam',1,1,4,21,54,49,NULL),(55,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','055','UBND phường Thọ Quang','UBND phường Thọ Quang',1,1,4,22,55,50,NULL),(56,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','056','UBND phường Nại Hiên Đông','UBND phường Nại Hiên Đông',1,1,4,22,56,51,NULL),(57,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','057','UBND phường Mân Thái','UBND phường Mân Thái',1,1,4,22,57,52,NULL),(58,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','058','UBND phường An Hải Bắc','UBND phường An Hải Bắc',1,1,4,22,58,53,NULL),(59,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','059','UBND phường Phước Mỹ','UBND phường Phước Mỹ',1,1,4,22,59,54,NULL),(60,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','060','UBND phường An Hải Tây','UBND phường An Hải Tây',1,1,4,22,60,55,NULL),(61,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','061','UBND phường An Hải Đông','UBND phường An Hải Đông',1,1,4,22,61,56,NULL),(62,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','062','UBND phường Mỹ An','UBND phường Mỹ An',1,1,4,23,62,57,NULL),(63,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','063','UBND phường Khuê Mỹ','UBND phường Khuê Mỹ',1,1,4,23,63,58,NULL),(64,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','064','UBND phường Hòa Quý','UBND phường Hòa Quý',1,1,4,23,64,59,NULL),(65,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','065','UBND phường Hòa Hải','UBND phường Hòa Hải',1,1,4,23,65,60,NULL),(66,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','066','UBND phường Khuê Trung','UBND phường Khuê Trung',1,1,4,24,66,61,NULL),(67,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','067','UBND phường Hòa Phát','UBND phường Hòa Phát',1,1,4,24,67,67,NULL),(68,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','068','UBND phường Hòa An','UBND phường Hòa An',1,1,4,24,68,68,NULL),(69,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','069','UBND phường Hòa Thọ Tây','UBND phường Hòa Thọ Tây',1,1,4,24,69,69,NULL),(70,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','070','UBND phường Hòa Thọ Đông','UBND phường Hòa Thọ Đông',1,1,4,24,70,70,NULL),(71,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','071','UBND phường Hòa Xuân','UBND phường Hòa Xuân',1,1,4,24,71,71,NULL),(72,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','072','UBND xã Hòa Bắc','UBND xã Hòa Bắc',1,1,4,25,72,72,NULL),(73,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','073','UBND xã Hòa Liên','UBND xã Hòa Liên',1,1,4,25,73,73,NULL),(74,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','074','UBND xã Hòa Ninh','UBND xã Hòa Ninh',1,1,4,25,74,74,NULL),(75,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','075','UBND xã Hòa Sơn','UBND xã Hòa Sơn',1,1,4,25,75,75,NULL),(76,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','076','UBND xã Hòa Nhơn','UBND xã Hòa Nhơn',1,1,4,25,76,76,NULL),(77,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','077','UBND xã Hòa Phú','UBND xã Hòa Phú',1,1,4,25,77,77,NULL),(78,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','078','UBND xã Hòa Phong','UBND xã Hòa Phong',1,1,4,25,78,78,NULL),(79,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','079','UBND xã Hòa Châu','UBND xã Hòa Châu',1,1,4,25,79,79,NULL),(80,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','080','UBND xã Hòa Tiến','UBND xã Hòa Tiến',1,1,4,25,80,80,NULL),(81,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','081','UBND xã Hòa Phước','UBND xã Hòa Phước',1,1,4,25,81,81,NULL),(82,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','082','UBND xã Hòa Khương','UBND xã Hòa Khương',1,1,4,25,82,82,NULL),(83,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','083','UBND Thành phố Hồ Chí Minh','UBND Thành phố Hồ Chí Minh',1,1,2,NULL,83,10,NULL),(84,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','084','UBND Thành phố Hà Nội','UBND Thành phố Hà Nội',1,1,2,NULL,84,12,NULL),(85,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','085','UBND Thành phố Hải Phòng','UBND Thành phố Hải Phòng',1,1,2,NULL,85,11,NULL),(86,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','086','Công an Đà Nẵng','Công an Đà Nẵng',1,1,5,1,86,9,2),(87,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','087','Công an Hồ Chí Minh','Công an Hồ Chí Minh',1,1,5,83,87,10,2),(88,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','088','Công an Hà Nội','Công an Hà Nội',1,1,5,84,88,12,2),(89,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','089','Công an Hải Phòng','Công an Hải Phòng',1,1,5,85,89,11,NULL),(90,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','090','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,2,2,9,NULL),(91,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','091','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,2,2,9,NULL),(92,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','092','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,2,2,9,NULL),(93,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','093','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,14,14,9,NULL),(94,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','094','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,14,14,9,NULL),(95,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','095','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,14,14,9,NULL),(96,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','096','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,4,4,9,NULL),(99,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','099','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,3,3,9,NULL),(97,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','097','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,4,4,9,NULL),(98,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','098','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,4,4,9,NULL),(100,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','100','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,3,3,9,NULL),(101,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','101','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,3,3,9,NULL),(102,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','102','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,5,5,9,NULL),(103,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','103','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,5,5,9,NULL),(104,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','104','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,5,5,9,NULL),(105,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','105','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,6,6,9,NULL),(106,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','106','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,6,6,9,NULL),(107,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','107','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,6,6,9,NULL),(108,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','108','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,7,7,9,NULL),(109,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','109','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,7,7,9,NULL),(110,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','110','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,7,7,9,NULL),(111,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','111','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,8,8,9,NULL),(112,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','112','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,8,8,9,NULL),(113,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','113','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,8,8,9,NULL),(114,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','114','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,9,9,9,NULL),(115,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','115','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,9,9,9,NULL),(116,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','116','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,9,9,9,NULL),(117,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','117','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,10,10,9,NULL),(118,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','118','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,10,10,9,NULL),(119,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','119','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,10,10,9,NULL),(120,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','120','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,11,11,9,NULL),(121,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','121','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,11,11,9,NULL),(122,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','122','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,11,11,9,NULL),(123,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','123','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,12,12,9,NULL),(124,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','124','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,12,12,9,NULL),(125,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','125','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,12,12,9,NULL),(126,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','126','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,13,13,9,NULL),(127,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','127','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,13,13,9,NULL),(128,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','128','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,13,13,9,NULL),(129,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','129','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,15,15,9,NULL),(130,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','130','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,15,15,9,NULL),(131,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','131','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,15,15,9,NULL),(132,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','132','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,16,16,9,NULL),(133,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','133','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,16,16,9,NULL),(134,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','134','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,16,16,9,NULL),(135,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','135','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,17,17,9,NULL),(136,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','136','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,17,17,9,NULL),(137,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','137','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,17,17,9,NULL),(138,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','138','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,18,18,9,NULL),(139,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','139','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,18,18,9,NULL),(140,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','140','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,18,18,9,NULL),(141,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','141','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,19,19,9,NULL),(142,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','142','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,19,19,9,NULL),(143,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','143','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,19,19,9,NULL),(144,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','144','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,20,20,9,NULL),(145,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','145','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,20,20,9,NULL),(146,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','146','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,20,20,9,NULL),(147,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','147','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,21,21,9,NULL),(148,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','148','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,21,21,9,NULL),(149,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','149','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,21,21,9,NULL),(150,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','150','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,22,22,9,NULL),(151,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','151','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,22,22,9,NULL),(152,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','152','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,22,22,9,NULL),(153,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','153','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,23,23,9,NULL),(154,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','154','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,23,23,9,NULL),(155,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','155','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,23,23,9,NULL),(156,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','156','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,24,24,9,NULL),(157,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','157','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,24,24,9,NULL),(158,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','158','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,24,24,9,NULL),(159,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','159','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,25,25,9,NULL),(160,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','160','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,25,25,9,NULL),(161,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','161','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,25,25,9,NULL),(162,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','162','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,26,26,9,NULL),(163,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','163','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,26,26,9,NULL),(164,'\0','2017-04-23 14:05:20','2017-04-23 14:05:20','164','Phòng Thanh tra phòng chống tham nhũng','Phòng Thanh tra phòng chống tham nhũng',1,1,6,26,26,9,NULL),(165,'\0','2017-07-21 00:49:31','2017-07-21 00:49:31','165','Phòng xử lý đơn','Phòng xử lý đơn',1,1,6,1,1,9,NULL),(166,'','2017-07-21 00:55:34','2017-07-21 00:49:45','166','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,NULL,166,9,NULL),(167,'\0','2017-07-21 00:55:48','2017-07-21 00:55:48','166','Phòng giải quyết đơn','Phòng giải quyết đơn',1,1,6,1,1,9,NULL);
/*!40000 ALTER TABLE `coquanquanly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coquantochuctiepdan`
--

DROP TABLE IF EXISTS `coquantochuctiepdan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coquantochuctiepdan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `chucVu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `coQuanDonVi_id` bigint(20) NOT NULL,
  `nguoiDaiDien_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKm45j02khl648myfq5ms97tdhv` (`nguoiSua_id`),
  KEY `FKj92x42wpougt7hrlkk1gigwfa` (`nguoiTao_id`),
  KEY `FKdg4wftk4r7hdsbs1u7ltef1rc` (`coQuanDonVi_id`),
  KEY `FK5cqh5r9leahji49o75pgebypk` (`nguoiDaiDien_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coquantochuctiepdan`
--

LOCK TABLES `coquantochuctiepdan` WRITE;
/*!40000 ALTER TABLE `coquantochuctiepdan` DISABLE KEYS */;
/*!40000 ALTER TABLE `coquantochuctiepdan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coquantochuctiepdan_has_sotiepcongdan`
--

DROP TABLE IF EXISTS `coquantochuctiepdan_has_sotiepcongdan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coquantochuctiepdan_has_sotiepcongdan` (
  `soTiepCongDan_id` bigint(20) NOT NULL,
  `coQuanToChucTiepDan_id` bigint(20) NOT NULL,
  KEY `FKnr156hp7pqg91p7l8ayqqvurw` (`coQuanToChucTiepDan_id`),
  KEY `FK80365qi9uuf6aff00r76ysts8` (`soTiepCongDan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coquantochuctiepdan_has_sotiepcongdan`
--

LOCK TABLES `coquantochuctiepdan_has_sotiepcongdan` WRITE;
/*!40000 ALTER TABLE `coquantochuctiepdan_has_sotiepcongdan` DISABLE KEYS */;
/*!40000 ALTER TABLE `coquantochuctiepdan_has_sotiepcongdan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dantoc`
--

DROP TABLE IF EXISTS `dantoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dantoc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `ma` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `tenKhac` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9x71u9y734rik892bx8a1fdhc` (`nguoiSua_id`),
  KEY `FKcqhioyh3xr66oc2eqwx3lw67i` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dantoc`
--

LOCK TABLES `dantoc` WRITE;
/*!40000 ALTER TABLE `dantoc` DISABLE KEYS */;
INSERT INTO `dantoc` VALUES (1,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','001','Kinh','Kinh','Việt',1,1),(2,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','002','Tày','Tày','Thổ, Ngạn, Phén, Thù Lao, Pa Dí',1,1),(3,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','003','Thái','Thái','Tày, Tày Khao (Thái trắng), Tày Dăm (Thái đen), Tày Mười Tây Thanh, Màn Thanh, Hang Ông, Tày Mường, Pi Thay, Thổ Đà Bắc',1,1),(4,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','004','Hoa','Hoa','Hán, Triều Châu, Phúc Kiến, Quảng Đông, Hải Nam, Hạ, Xạ Phạng',1,1),(5,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','005','Khơ Me','Khơ Me','Cur, Cul, Cu, Thổ, Việt gốc Miên, Khơ-me Krôm',1,1),(6,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','006','Mường','Mường','Mol, Mual, Mọi, Mọi Bi, Ao Tá (Ậu Tá)',1,1),(7,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','007','Nùng','Nùng','Xuồng, Giang, Nùng An, Phàn Sinh, Nùng Cháo, Nùng Lòi, Quý Rim, Khèn Lài, ...',1,1),(8,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','008','HMông','HMông','Mèo, Mẹo, Hoa, Mèo Xanh, Mèo Đỏ, Mèo Đen, Ná Mẻo, Mán Trắng',1,1),(9,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','009','Dao','Dao','Mán, Động, Trại, Xá, Dìu Miền, Kiềm, Miền, Quần Trắng, Dao Đỏ, Quần Chẹt, Lô Gang, Dao Tiền, Thanh Y,Lan Tẻn, Đại Bản,Tiểu Bản, Cóc Ngáng, Cóc Mùn, Sơn Đầu, ...  Mán, Động, Trại, Xá, Dìu Miền, Kiềm, Miền, Quần Trắng, Dao Đỏ, Quần Chẹt, Lô Gang, Dao Tiền',1,1),(10,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','010','Gia Rai','Gia Rai','Giơ-rai, Tơ-buăn, Chơ-rai, Hơ-bau, Hđrung, Chor, ...',1,1),(11,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','011','Ngái','Ngái','Xín, Lê, Đản, Khách Gia',1,1),(12,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','012','Ê - Đê','Ê - Đê','Ra-đê, Đê, Kpạ, A-đham, Krung, Ktul, Đliê Ruê, Blô, E-pan, Mđhur, Bih, ...',1,1),(13,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','013','Ba na','Ba na','Gơ-lar, Tơ-lô, Giơ-lâng (Y-Lăng), Rơ-ngao, Krem, Roh, ConKđê, A-la Công, Kpăng Công, Bơ-nâm',1,1),(14,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','014','Xơ Đăng','Xơ Đăng','Xơ-teng, Hđang, Tơ-đra, Mơ-nâm, Ha-lăng, Ca-dông, Kmrăng, Con Lan, Bri-la, Tang',1,1),(15,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','015','Sán Chay','Sán Chay','Cao Lan-Sán chỉ, Cao Lan, Mán Cao Lan, Hờn Bạn, Sán Chỉ (Sơn Tử)',1,1),(16,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','016','Cơ Ho','Cơ Ho','Xrê, Nôp (Tu Lốp), Cơ-don, Chil, Lat (Lach), Trinh',1,1),(17,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','017','Chăm','Chăm','Chàm, Chiêm Thành, Hroi',1,1),(18,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','018','SánDìu','SánDìu','Sán Dẻo, Trại, Trại Đất, Mán Quần Cộc',1,1),(19,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','019','HRê','HRê','Chăm Rê, Chom, Krẹ Lũy',1,1),(20,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','020','MNông','MNông','Pnông, Nông, Pré, Bu-đâng, ĐiPri, Biat, Gar, Rơ-lam, Chil',1,1),(21,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','021','RagLai','RagLai','Ra-clây, Rai, Noang, La Oang',1,1),(22,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','022','XTiêng','XTiêng','Xa Điêng',1,1),(23,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','023','Bru','Bru','Bru, Vân Kiều, Măng Coong, Tri Khùa',1,1),(24,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','024','Thổ','Thổ','Kẹo, Mọn, Cuối, Họ, Đan Lai, Ly Hà, Tày Pọng, Con Kha, Xá Lá Vàng',1,1),(25,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','025','Giáy','Giáy','Nhắng, Dẩng, Pầu Thìn Pu Nà, Cùi Chu, Xa',1,1),(26,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','026','Cơ Tu','Cơ Tu','Ca-tu, Cao, Hạ, Phương, Ca-tang',1,1),(27,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','027','Gié','Gié','Đgiéh, Tareh, Giang Rẫy Pin, Triêng, Treng, Ta Riêng, Ve (Veh), La-ve, Ca-tang',1,1),(28,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','028','Mạ','Mạ','Châu Mạ, Mạ Ngăn, Mạ Xốp, Mạ Tô, Mạ Krung, ...',1,1),(29,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','029','Khơ Mú','Khơ Mú','Xá Cẩu, Mứn Xen, Pu Thênh Tềnh, Tày Hay',1,1),(30,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','030','Co','Co','Cor, Col, Cùa, Trầu',1,1),(31,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','031','Ta Ôi','Ta Ôi','Tôi-ôi, Pa-co, Pa-hi (Ba-hi)',1,1),(32,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','032','Chơ Ro','Chơ Ro','Dơ-ro, Châu-ro',1,1),(33,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','033','Kháng','Kháng','Xá Khao, Xá Súa, Xá Dón, Xá Dẩng, Xá Hốc, Xá Ái, Xá Bung, Quảng Lâm',1,1),(34,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','034','Xing Mun','Xing Mun','Puộc, Pụa',1,1),(35,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','035','Ha Nhì','Ha Nhì','U Ni, Xá U Ni',1,1),(36,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','036','Chu Ru','Chu Ru','Chơ-ru, Chu',1,1),(37,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','037','Lào','Lào','Lào Bốc, Lào Nọi',1,1),(38,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','038','La Chi','La Chi','Cù Tê, La Quả',1,1),(39,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','039','La Ha','La Ha','Xá Khao, Khlá Phlạo',1,1),(40,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','040','Phù Lá','Phù Lá','Bồ Khô Pạ, Mu Di, Pạ Xá, Phó, Phổ, VaXơ',1,1),(41,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','041','La Hủ','La Hủ','Lao, Pu Đang, Khù Xung, Cò Xung, Khả Quy',1,1),(42,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','042','Lự','Lự','Lừ, Nhuồn Duôn, Mun Di',1,1),(43,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','043','Lô Lô','Lô Lô','Lô Lô',1,1),(44,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','044','Chứt','Chứt','Sách, May, Rục, Mã-liêng, A-rem, Tu Vang, Pa-leng, Xơ-lang, Tơ-hung, Chà-củi, Tắc-củi, U-mo, Xá Lá Vàng',1,1),(45,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','045','Mảng','Mảng','Mảng Ư, Xá Lá Vàng',1,1),(46,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','046','Pà Thẻn','Pà Thẻn','Pà Hưng, Tống',1,1),(47,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','047','Cơ Lao','Cơ Lao','Cơ Lao',1,1),(48,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','048','Cống','Cống','Xắm Khống, Mấng Nhé, Xá Xeng',1,1),(49,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','049','Bố Y','Bố Y','Chủng Chá, Trọng Gia, Tu Dí, Tu Dìn',1,1),(50,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','050','Xi La','Xi La','Cù Dề Xừ, Khả pẻ',1,1),(51,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','051','Pu Péo','Pu Péo','Ka Bèo, Pen Ti Lô Lô',1,1),(52,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','052','Brâu','Brâu','Brao',1,1),(53,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','053','Ơ Đu','Ơ Đu','Tày Hạt',1,1),(54,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','054','Rơ Măm','Rơ Măm','Rơ Măm',1,1),(55,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','055','Hán','Hán','Hán',1,1),(56,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','056','Cà Dong','Cà Dong','Cà Dong',1,1),(57,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','057','Chiêng','Chiêng','Chiêng',1,1),(58,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','058','Tà Riềng','Tà Riềng','Tà Riềng',1,1),(59,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','059','Dẻ','Dẻ','Dẻ',1,1),(60,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','060','Nước Ngoài','Nước Ngoài','Nước Ngoài',1,1),(61,'\0','2017-04-23 15:25:00','2017-04-23 15:25:02','061','Không xác định','Không xác định','Không xác định',1,1);
/*!40000 ALTER TABLE `dantoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doandicung`
--

DROP TABLE IF EXISTS `doandicung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doandicung` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `cmndHoChieu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `diaChi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `hoVaTen` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soDienThoai` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `don_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjkws9vgfaeudy0f2yfjeneut6` (`nguoiSua_id`),
  KEY `FK7yny51k0u4pni9kgbqewvm1vj` (`nguoiTao_id`),
  KEY `FKfdwwx2ao5u0f09swgahormtyw` (`don_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doandicung`
--

LOCK TABLES `doandicung` WRITE;
/*!40000 ALTER TABLE `doandicung` DISABLE KEYS */;
INSERT INTO `doandicung` VALUES (1,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201575538','23 Phan Tứ','Đặng Đình Cường','0932110442',1,1,19),(2,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201115642','15 Tản Đà','Trần Bá Hòa','01206116305',1,1,19),(3,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201245578','30 Quang Trung','Nguyễn Thị Kim','0982137146',1,1,19),(4,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201425632','20 Nguyễn Huy Tưởng','Lê Văn Quý','01206116305',1,1,23),(5,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201356214','12 Cù Chính Lan','Đỗ Bảo Trân','0982137146',1,1,23),(6,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201115642','15 Tản Đà','Trần Bá Hòa','01206116305',1,1,23),(7,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201575538','23 Phan Tứ','Đặng Đình Cường','0932110442',1,1,23),(8,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201245578','30 Quang Trung','Nguyễn Thị Kim','0982137146',1,1,23),(9,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201575786','30 Bà Huyện Thanh Quan','Lê Quang Tuấn','01202052973',1,1,26),(10,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201422432','43 Hồ Tùng Mậu','Nguyễn Bá Quang','0973389168',1,1,26),(11,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201245523','30 Quang Trung','Trần Thị Nguyệt','0987371772',1,1,26),(12,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','200213224','15 Tản Đà','Huỳnh Văn Chương','01636629861',1,1,26),(13,'\0','2017-06-06 14:58:44','2017-06-06 14:58:44','201356467','50 Hà Huy Tập','Nguyễn Hồng Quyên','0903300143',1,1,26),(14,'\0','2017-07-21 01:30:22','2017-07-21 01:30:22','201356198','12 Dương Nguyệt','Nguyễn Tiến Bá','0905234123',4,4,31),(15,'\0','2017-07-21 01:30:22','2017-07-21 01:30:22','201356467','50 Hà Huy Tập','Nguyễn Hồng Quyên','0903300143',4,4,31),(16,'\0','2017-07-21 01:30:22','2017-07-21 01:30:22','201422432','43 Hồ Tùng Mậu','Nguyễn Bá Quang','0973389168',4,4,31),(17,'\0','2017-07-21 01:30:22','2017-07-21 01:30:22','201575786','30 Bà Huyện Thanh Quan','Lê Quang Tuấn','01202052973',4,4,31),(18,'\0','2017-07-21 01:30:22','2017-07-21 01:30:22','201245523','30 Quang Trung','Trần Thị Nguyệt','0987371772',4,4,31),(19,'\0','2017-07-21 01:30:22','2017-07-21 01:30:22','200213224','15 Tản Đà','Huỳnh Văn Chương','01636629861',4,4,31);
/*!40000 ALTER TABLE `doandicung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentmetadata`
--

DROP TABLE IF EXISTS `documentmetadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentmetadata` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `fileLocation` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `salkey` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKku6e9kbdas0a2o8lxyouvvb4r` (`nguoiSua_id`),
  KEY `FK4644u67y4ovy6nag7msp9ggdr` (`nguoiTao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentmetadata`
--

LOCK TABLES `documentmetadata` WRITE;
/*!40000 ALTER TABLE `documentmetadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentmetadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `don`
--

DROP TABLE IF EXISTS `don`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `don` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `coThongTinCoQuanDaGiaiQuyet` bit(1) NOT NULL,
  `coUyQuyen` bit(1) NOT NULL,
  `daGiaiQuyet` bit(1) NOT NULL,
  `daXuLy` bit(1) NOT NULL,
  `donChuyen` bit(1) NOT NULL,
  `ghiChuXuLyDon` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `hinhThucDaGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `hoanThanhDon` bit(1) NOT NULL,
  `huongGiaiQuyetDaThucHien` longtext COLLATE utf8_vietnamese_ci,
  `huongXuLyXLD` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `lanhDaoDuyet` bit(1) NOT NULL,
  `loaiDoiTuong` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `loaiDon` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `loaiNguoiDungDon` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `lyDoDinhChi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ma` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ngayBanHanhVanBanDaGiaiQuyet` datetime DEFAULT NULL,
  `ngayBatDauXLD` datetime DEFAULT NULL,
  `ngayKetThucXLD` datetime DEFAULT NULL,
  `ngayLapDonGapLanhDaoTmp` datetime DEFAULT NULL,
  `ngayQuyetDinhDinhChi` datetime DEFAULT NULL,
  `ngayTiepNhan` datetime DEFAULT NULL,
  `nguonTiepNhanDon` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `noiDung` longtext COLLATE utf8_vietnamese_ci NOT NULL,
  `noiDungThongTinTrinhLanhDao` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `old` bit(1) NOT NULL,
  `processType` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `quyTrinhXuLy` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soLanKhieuNaiToCao` int(11) NOT NULL,
  `soNguoi` int(11) NOT NULL,
  `soQuyetDinhDinhChi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soVanBanDaGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `thanhLapDon` bit(1) NOT NULL,
  `thanhLapTiepDanGapLanhDao` bit(1) NOT NULL,
  `thoiHanXuLyXLD` datetime DEFAULT NULL,
  `tongSoLuotTCD` int(11) NOT NULL,
  `trangThaiDon` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `yKienXuLyDon` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `yeuCauCuaCongDan` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `yeuCauGapTrucTiepLanhDao` bit(1) NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `canBoXuLy_id` bigint(20) DEFAULT NULL,
  `canBoXuLyChiDinh_id` bigint(20) DEFAULT NULL,
  `canBoXuLyPhanHeXLD_id` bigint(20) DEFAULT NULL,
  `chiTietLinhVucDonThuChiTiet_id` bigint(20) DEFAULT NULL,
  `coQuanDaGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `coQuanDangGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `currentState_id` bigint(20) DEFAULT NULL,
  `donGoc_id` bigint(20) DEFAULT NULL,
  `donLanTruoc_id` bigint(20) DEFAULT NULL,
  `donViThamTraXacMinh_id` bigint(20) DEFAULT NULL,
  `donViXuLyDonChuyen_id` bigint(20) DEFAULT NULL,
  `linhVucDonThu_id` bigint(20) NOT NULL,
  `linhVucDonThuChiTiet_id` bigint(20) DEFAULT NULL,
  `phongBanGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `thamQuyenGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `ketQuaXLDGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `trangThaiTTXM` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `trangThaiXLDGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `donViXuLyGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `giaiQuyetDonCuoiCung_id` bigint(20) DEFAULT NULL,
  `giaiQuyetTTXMCuoiCung_id` bigint(20) DEFAULT NULL,
  `xuLyDonCuoiCung_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKle6vcyxx4cpgoqtm2o98e1gig` (`nguoiSua_id`),
  KEY `FKi26gnvwpqihb6ghk6kpldpywj` (`nguoiTao_id`),
  KEY `FKgld302prex5kyuixl71f50lta` (`canBoXuLy_id`),
  KEY `FKd5e5jqciknilcrcbg3cyinepp` (`canBoXuLyChiDinh_id`),
  KEY `FKjme5he22rybjexnb5n30boea4` (`canBoXuLyPhanHeXLD_id`),
  KEY `FKo3340sqgl2gp9hs7qdxnialet` (`chiTietLinhVucDonThuChiTiet_id`),
  KEY `FK6rr83fn2mfxl34o5gqn50tmya` (`coQuanDaGiaiQuyet_id`),
  KEY `FKc6k0qvemb1xyh50slqh3ggdf` (`coQuanDangGiaiQuyet_id`),
  KEY `FK6gxjnr1mm4l4v5yg3v32w3et` (`currentState_id`),
  KEY `FK4l6n5gm3otpgnsyhm3j44em8k` (`donGoc_id`),
  KEY `FKms6sdk1weha5o1tmql3f8ba62` (`donLanTruoc_id`),
  KEY `FK9esu05q89qi31irwma0unc66i` (`donViThamTraXacMinh_id`),
  KEY `FKbwhmh3opfpk7crna1d3svs0v9` (`donViXuLyDonChuyen_id`),
  KEY `FKs68ok103jkvgf0n6cd92w4yoi` (`linhVucDonThu_id`),
  KEY `FKk5mqov4ao40w3919uaigupajy` (`linhVucDonThuChiTiet_id`),
  KEY `FKehu8rqxcgq6015b5avbmnxum` (`phongBanGiaiQuyet_id`),
  KEY `FKjmui05kok7bl12k4tx8nyb49j` (`thamQuyenGiaiQuyet_id`),
  KEY `FKmbiidysy48xebog9dqseg827n` (`donViXuLyGiaiQuyet_id`),
  KEY `FKl6d4khf363xy1s8p8yrt29x13` (`giaiQuyetDonCuoiCung_id`),
  KEY `FKkts1ayrc7wi0p1egpkum6ni3s` (`giaiQuyetTTXMCuoiCung_id`),
  KEY `FK6farclskj2kqxd3li9jbhnst1` (`xuLyDonCuoiCung_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `don`
--

LOCK TABLES `don` WRITE;
/*!40000 ALTER TABLE `don` DISABLE KEYS */;
INSERT INTO `don` VALUES (18,'\0','2017-06-13 18:05:50','2017-05-17 09:45:36','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','QUYET_DINH_HANH_CHINH','DON_KHIEU_NAI','CA_NHAN','','',NULL,NULL,NULL,'2017-05-17 09:45:36',NULL,'2017-05-17 09:39:35','TRUC_TIEP','Khiếu nại 2 cán bộ Công an kiểm soát trật tự tại khu công nghiệp An Đồn đối với hành vi yêu cầu tôi dừng xe lại nhưng lại không xuất trình những giấy tờ chứng minh việc đang thi hành công vụ, không đeo biển hiệu.					',NULL,'\0',NULL,NULL,0,1,'','','\0','\0',NULL,1,NULL,'','','\0',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,'\0','2017-06-13 18:05:07','2017-05-17 10:05:04','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','HANH_VI_HANH_CHINH','DON_TO_CAO','DOAN_DONG_NGUOI','','',NULL,NULL,NULL,'2017-05-17 10:05:04',NULL,'2017-05-17 09:48:57','TRUC_TIEP','Tố cáo ông Trần Văn X, cán bộ địa chính - xây dựng Quận Hải Châu nhận hối lộ số tiền 100.000.000 triệu đồng để không gây khó dễ trong việc cấp giấy phép xây dựng 					',NULL,'\0',NULL,NULL,0,4,'','','\0','\0',NULL,1,NULL,'','','\0',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,'\0','2017-06-13 17:57:09','2017-05-17 10:14:18','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','HANH_VI_HANH_CHINH','DON_KIEN_NGHI_PHAN_ANH','CO_QUAN_TO_CHUC','','',NULL,NULL,NULL,'2017-05-17 10:14:18',NULL,'2017-05-17 10:06:27','TRUC_TIEP','Chúng tôi là tập thể nhân dân sinh sống tại tổ 5- Hòa Minh - Liên Chiểu - Đà Nẵng, xin được phản ánh về tình hình ô nhiễm môi trường trong thời gian qua tại nơi chúng tôi sống.\nCụ thể như sau: mấy năm gần đây cạnh nhà chúng tôi ở mọc lên hai trạm trộn bêtông nhựa đường nóng hoạt động suất ngày đêm, gây ô nhiễm nghiêm trọng tại nơi chung tôi sinh sống. Nhà máy hoạt động gây ra những ảnh hưởng đến đời sống sinh hoạt của người dân :\nGây khói bụi đến ngạt thở.\nTiếng ồn của nhà máy, của máy xúc làm đầu chúng tôi như nổ tung không ăn ngủ gì được.\nTiếng rung của nhà máy gầm lên làm nứt nhà chúng tôi.\nTiếng còi, tiếng đật thùng xe ben kêu vang trời.		',NULL,'\0','XU_LY_DON',NULL,0,1,'','','\0','\0',NULL,1,NULL,'','','\0',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,'\0','2017-06-13 17:56:52','2017-05-17 10:40:57','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','QUYET_DINH_HANH_CHINH','DON_KIEN_NGHI_PHAN_ANH','CO_QUAN_TO_CHUC','','',NULL,NULL,NULL,'2017-05-17 10:40:57',NULL,'2017-05-17 10:37:16','TRUC_TIEP','Chúng tôi là tập thể giáo viên trường tiểu học Điện Biên Phủ, nay chúng tôi xin kiến nghị về việc không đồng ý sự quyết định bổ nhiệm bà Vương Thị Vân về làm hiệu trưởng trường tiểu học Điện Biên Phủ vì theo thông tin chính xác thì năm học 2013-2014 bà Vương Thị Vân đã bị kỷ luật và lên làm việc tại Phòng Giáo Dục.',NULL,'\0',NULL,NULL,0,1,'','','\0','\0',NULL,1,NULL,'','','\0',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,52,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,'\0','2017-06-13 18:06:26','2017-05-17 11:13:00','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','HANH_VI_HANH_CHINH','DON_KHIEU_NAI','CA_NHAN','','',NULL,NULL,NULL,'2017-05-17 11:13:00',NULL,'2017-05-17 05:33:58','TRUC_TIEP','Ông nội tôi có 06 người con (04 nam 02 nữ) trong đó bố tôi là người con trai thứ hai trong nhà. ông nội tôi có hai mảnh đất. Một mảnh đã cho người con trai thứ ba trong nhà (em bố tôi) sở hữu. Mảnh đất còn lại hiện nay gia đình đang ở được chia làm 2, bố tôi được hưởng 1/2 mảnh đất trên và đã được tách tên sở hữu đứng tên bố tôi (được vẽ trong bản đồ địa chính 299 của xã vẽ năm 1996) nhưng chưa có sổ đỏ (do địa phương chưa cấp sổ đỏ từ trước đến nay)',NULL,'\0',NULL,NULL,0,1,'','','\0','',NULL,1,NULL,'','','',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,'\0','2017-06-13 18:06:12','2017-05-17 11:23:06','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','HANH_VI_HANH_CHINH','DON_TO_CAO','DOAN_DONG_NGUOI','','',NULL,NULL,NULL,'2017-05-17 11:23:06',NULL,'2017-05-17 05:33:58','TRUC_TIEP','Anh Trần Võ Đình Nam có hành vi lừa đảo, chiếm đoạt tài sản của bà Khuê là một chiếc nhẫn vàng 18k trị giá 1,8 chỉ.	',NULL,'\0',NULL,NULL,0,6,'','','\0','',NULL,1,NULL,'','','',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'\0','2017-06-13 17:54:12','2017-05-17 11:36:30','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','HANH_VI_HANH_CHINH','DON_KIEN_NGHI_PHAN_ANH','CO_QUAN_TO_CHUC','','',NULL,NULL,NULL,'2017-05-17 11:36:30',NULL,'2017-05-17 11:23:16','TRUC_TIEP','Chúng tôi là tập thể nhân dân sinh sống tại tổ 5- Hòa Khánh Bắc - Liên Chiểu - Đà Nẵng, xin được phản ánh về tình hình ô nhiễm môi trường trong thời gian qua tại nơi chúng tôi sống.\nCụ thể như sau: mấy năm gần đây cạnh nhà chúng tôi ở mọc lên hai trạm trộn bêtông nhựa đường nóng hoạt động suất ngày đêm, gây ô nhiễm nghiêm trọng tại nơi chung tôi sinh sống. Nhà máy hoạt động gây ra những ảnh hưởng đến đời sống sinh hoạt của người dân :\nGây khói bụi đến ngạt thở.\nTiếng ồn của nhà máy, của máy xúc làm đầu chúng tôi như nổ tung không ăn ngủ gì được.\nTiếng rung của nhà máy gầm lên làm nứt nhà chúng tôi.\nTiếng còi, tiếng đật thùng xe ben kêu vang trời.',NULL,'\0',NULL,NULL,0,1,'','','\0','\0',NULL,1,NULL,'','','',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,19,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'\0','2017-06-13 18:07:45','2017-05-17 12:40:20','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','QUYET_DINH_HANH_CHINH','DON_KIEN_NGHI_PHAN_ANH','CA_NHAN','','',NULL,NULL,NULL,'2017-05-17 12:40:20',NULL,'2017-05-17 12:37:12','TRUC_TIEP','Khiếu nại công ty TNHH A trong quá trình sản xuất đã lấn chiếm trái phép diện tích đất công',NULL,'\0',NULL,NULL,0,1,'','','\0','\0',NULL,0,NULL,'','','\0',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,23,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'\0','2017-06-13 18:07:32','2017-05-17 12:48:49','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','HANH_VI_HANH_CHINH','DON_TO_CAO','DOAN_DONG_NGUOI','','',NULL,NULL,NULL,'2017-05-17 12:48:49',NULL,'2017-05-17 12:40:53','TRUC_TIEP','Tố cáo ông Nguyễn Văn B nhận hối lộ của công ty C 1 tỷ đồng và làm ngơ cho việc công ty C trong quá trình sản xuất đã xả chất thải chưa qua xử lý ra môi trường gây ô nhiễm môi trường',NULL,'\0',NULL,NULL,0,6,'','','\0','\0',NULL,0,NULL,'','','\0',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,17,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,'\0','2017-06-13 18:07:14','2017-05-17 13:01:05','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','HANH_VI_HANH_CHINH','DON_KIEN_NGHI_PHAN_ANH','CO_QUAN_TO_CHUC','','',NULL,NULL,NULL,'2017-05-17 13:01:05',NULL,'2017-05-17 12:57:33','TRUC_TIEP','Phản ánh công ty VinGrow trong quá trình sản xuất đã xả chất thải chưa qua xử lý gây ô nhiễm môi trường gây ảnh hưởng đến sức khỏe của các khu dân cư lân cận',NULL,'\0',NULL,NULL,0,1,'','','\0','\0',NULL,0,NULL,'','','\0',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'\0','2017-06-13 18:06:56','2017-05-17 14:03:23','\0','\0','\0','\0','\0','',NULL,'\0',' ',NULL,'\0','QUYET_DINH_HANH_CHINH','DON_KIEN_NGHI_PHAN_ANH','CO_QUAN_TO_CHUC','','',NULL,NULL,NULL,'2017-05-17 14:03:23',NULL,'2017-05-17 13:59:59','TRUC_TIEP','Cơ sở sản xuất gia công cơ khí, sản xuất ốc vít của hộ kinh doanh Tường Vinh hoạt động liên tục từ thứ Hai đến thứ Bảy hàng tuần, từ 07h15 đến 17,18giờ00 (chỉ nghỉ khoản 1,5 giờ vào buổi trưa). Cơ sở sản xuất này gây nên tiếng ồn rất lớn, tiếng máy dập kim loại, tiếng khoan cắt kim loại làm ảnh hưởng nghiêm trọng và gây khó khăn cho sinh hoạt của các hộ dân xung quanh.					',NULL,'\0','GIAI_QUYET_DON',NULL,0,1,'','','\0','\0',NULL,0,NULL,'','','\0',3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,24,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `don` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `don_congdan`
--

DROP TABLE IF EXISTS `don_congdan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `don_congdan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `chucVu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `diaChi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `diaChiCoQuan` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `donVi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `gioiTinh` bit(1) NOT NULL,
  `hoVaTen` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `luatSu` bit(1) NOT NULL,
  `ngayCap` datetime DEFAULT NULL,
  `ngayCapTheLuatSu` datetime DEFAULT NULL,
  `ngaySinh` datetime DEFAULT NULL,
  `noiCapTheLuatSu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `phanLoaiCongDan` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `soCMNDHoChieu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soDienThoai` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soDienThoaiCoQuan` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soTheLuatSu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `tenCoQuan` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `thongTinGioiThieu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `congDan_id` bigint(20) NOT NULL,
  `danToc_id` bigint(20) DEFAULT NULL,
  `don_id` bigint(20) NOT NULL,
  `noiCapCMND_id` bigint(20) DEFAULT NULL,
  `phuongXa_id` bigint(20) DEFAULT NULL,
  `quanHuyen_id` bigint(20) DEFAULT NULL,
  `quocTich_id` bigint(20) DEFAULT NULL,
  `tinhThanh_id` bigint(20) DEFAULT NULL,
  `toDanPho_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IndexPLDDX` (`phanLoaiCongDan`,`don_id`,`daXoa`),
  KEY `IndexPLDCD` (`phanLoaiCongDan`,`don_id`,`congDan_id`),
  KEY `IndexDDX` (`don_id`,`daXoa`),
  KEY `IndexIDDX` (`id`,`daXoa`),
  KEY `IndexCDDX` (`congDan_id`,`daXoa`),
  KEY `IndexDX` (`daXoa`),
  KEY `FKfevxgcufw32414nfloji3dd1e` (`nguoiSua_id`),
  KEY `FK46a1i8bk19bcrkbyat97ru8lj` (`nguoiTao_id`),
  KEY `FKs3enjgbyfqhpo3r27r54ynj58` (`danToc_id`),
  KEY `FKobrsqn1y7475enh96rke2lhot` (`noiCapCMND_id`),
  KEY `FKaoofnbfu1hejf62hywbus5f9t` (`phuongXa_id`),
  KEY `FK7eankxofo3fetxkma511pajle` (`quanHuyen_id`),
  KEY `FKfj8whk1eqf72khdw06jsms6qw` (`quocTich_id`),
  KEY `FKkr74sr31wedvdoage80tpkax` (`tinhThanh_id`),
  KEY `FKoqeqhpe8i1x9k6895u95yxrfn` (`toDanPho_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `don_congdan`
--

LOCK TABLES `don_congdan` WRITE;
/*!40000 ALTER TABLE `don_congdan` DISABLE KEYS */;
INSERT INTO `don_congdan` VALUES (32,'\0','2017-06-13 18:05:50','2017-05-17 09:45:37','','221 Hà Huy Tập nối dài','','','\0','Huỳnh Bảo Ngọc','\0','2011-10-21 00:00:00',NULL,'1989-09-02 00:00:00','','NGUOI_DUNG_DON','201574408','0932110442','','','','',3,1,17,1,18,86,31,15,1,9,116),(33,'\0','2017-06-13 18:05:07','2017-05-17 10:05:05','','12 Cù Chính Lan','','','\0','Đỗ Bảo Trân','\0',NULL,NULL,NULL,'','NGUOI_DUNG_DON','201356214','0982137146','','','','',3,1,20,1,19,86,35,15,1,9,147),(34,'\0','2017-06-13 18:05:07','2017-05-17 10:05:05','','20 Nguyễn Huy Tưởng','','','','Lê Văn Quý','\0',NULL,NULL,'1975-09-29 00:00:00','','NGUOI_DUNG_DON','201425632','01206116305','','','','',3,1,18,NULL,19,86,26,14,NULL,9,61),(35,'\0','2017-06-13 18:05:07','2017-05-17 10:05:05','','35 Phan Chu Trinh','','','','Võ Hoài Nam','\0','2010-12-22 00:00:00',NULL,'1983-10-05 00:00:00','','NGUOI_DUNG_DON','201356214','0982137146','','','','',3,1,19,1,19,86,40,16,1,9,197),(39,'\0','2017-06-13 17:57:09','2017-05-17 10:14:19','','20 Nguyễn Huy Tưởng','47 Hòa Minh - Liên Chiểu - Đà Nẵng','','','Nguyễn Văn Khải','\0',NULL,NULL,NULL,'','NGUOI_DUNG_DON','201426632','01206116305','','','Công ty Vin Group','',3,1,24,1,20,86,26,14,1,9,61),(40,'\0','2017-06-13 17:56:52','2017-05-17 10:40:57','','88 Cần Giuộc','26 Trường Chinh','','\0','Nguyễn Thị Trung Chinh','\0','2012-01-24 00:00:00',NULL,'1970-02-10 00:00:00','','NGUOI_DUNG_DON','201052987','01206116305','','','Trường tiểu học Điện Biên Phủ','',3,1,25,1,21,86,36,15,1,9,165),(41,'\0','2017-06-13 18:06:26','2017-05-17 11:13:00','','221 Trường Chinh','','','\0','Phạm Thị Cẩm Nhung','\0',NULL,NULL,'1993-09-02 00:00:00','','NGUOI_DUNG_DON','201648215','01214645823','','','','',3,1,26,1,22,86,35,15,1,9,155),(42,'\0','2017-06-13 18:06:12','2017-05-17 11:23:07','','70 Nguyễn Lương Bằng','','','','Đinh Nguyễn Anh Khuê','\0',NULL,NULL,'1993-10-05 00:00:00','','NGUOI_DUNG_DON','201357214','0982137146','','','','',3,1,27,1,23,86,24,14,1,9,40),(48,'\0','2017-06-13 17:54:12','2017-05-17 11:36:30','','70 Nguyễn Lương Bằng','76 Hòa Khánh Bắc - Liên Chiểu - Đà Nẵng','','\0','Dương Thanh Ái Quyên','\0','2010-12-23 00:00:00',NULL,'1993-09-29 00:00:00','','NGUOI_DUNG_DON','201225632','01206116305','','','Vin Group','',3,1,28,1,24,86,24,14,1,9,40),(49,'\0','2017-06-13 18:07:45','2017-05-17 12:40:20','','534 Trần Cao Vân','','','','Huỳnh Quốc Đạt','\0','2011-10-21 00:00:00',NULL,'1987-09-23 00:00:00','','NGUOI_DUNG_DON','201537408','0906345210','','','','',3,1,29,1,25,86,34,15,1,9,145),(51,'\0','2017-06-13 18:07:32','2017-05-17 12:48:49','','24 Quang Trung','','','','Nguyễn Tiến Bá','\0','2010-12-02 00:00:00',NULL,'1983-10-05 00:00:00','','NGUOI_DUNG_DON','205356214','0905234123','','','','',3,1,31,1,26,86,40,16,1,9,197),(56,'\0','2017-06-13 18:07:14','2017-05-17 13:01:05','','23 Ngô Thì Nhậm','Hải Phòng','','','Trần Quang Diệu','\0','2014-03-09 00:00:00',NULL,'1978-09-29 00:00:00','','NGUOI_DUNG_DON','204025632','01261246721','','','Vina Group','',3,1,36,1,27,86,26,14,1,9,61),(57,'\0','2017-06-13 18:06:56','2017-05-17 14:03:24','','12 Hàm Nghi','346 Tôn Đức Thắng','','\0','Nguyễn Thị Nụ','\0','2012-01-24 00:00:00',NULL,'1970-02-10 00:00:00','','NGUOI_DUNG_DON','201052966','01201090931','','','Hòa Bình','',3,1,37,1,28,86,34,15,1,9,138);
/*!40000 ALTER TABLE `don_congdan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donvihanhchinh`
--

DROP TABLE IF EXISTS `donvihanhchinh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donvihanhchinh` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `ma` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `capDonViHanhChinh_id` bigint(20) NOT NULL,
  `cha_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKlupepl2viw3pp85r19c9t3lnt` (`nguoiSua_id`),
  KEY `FKlh7l3e1vu15jwjn1p8sy1yuv6` (`nguoiTao_id`),
  KEY `FKpl3lg3vfs2rl19013rgnfc2f2` (`capDonViHanhChinh_id`),
  KEY `FK39gtupy50f9p0yg1pnv1fdq6q` (`cha_id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donvihanhchinh`
--

LOCK TABLES `donvihanhchinh` WRITE;
/*!40000 ALTER TABLE `donvihanhchinh` DISABLE KEYS */;
INSERT INTO `donvihanhchinh` VALUES (24,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','016','phường Hòa Khánh Bắc','phường Hòa Khánh Bắc',1,1,6,14),(25,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','017','phường Hòa Khánh Nam','phường Hòa Khánh Nam',1,1,6,14),(23,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','015','phường Hòa Hiệp Nam','phường Hòa Hiệp Nam',1,1,6,14),(22,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','014','phường Hòa Hiệp Bắc','phường Hòa Hiệp Bắc',1,1,6,14),(9,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','001','thành phố Đà Nẵng','thành phố Đà Nẵng',1,1,4,NULL),(10,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','002','thành phố Hồ Chí Minh','thành phố Hồ Chí Minh',1,1,4,NULL),(11,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','003','thành phố Hải Phòng','thành phố Hải Phòng',1,1,4,NULL),(12,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','004','thành phố Hà Nội','thành phố Hà Nội',1,1,4,NULL),(13,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','005','thành phố Cần Thơ','thành phố Cần Thơ',1,1,4,NULL),(14,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','006','quận Liên Chiểu','quận Liên Chiểu',1,1,5,9),(15,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','007','quận Thanh Khê','quận Thanh Khê',1,1,5,9),(16,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','008','quận Hải Châu','quận Hải Châu',1,1,5,9),(17,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','009','quận Sơn Trà','quận Sơn Trà',1,1,5,9),(18,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','010','quận Ngũ Hành Sơn','quận Ngũ Hành Sơn',1,1,5,9),(19,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','011','quận Cẩm Lệ','quận Cẩm Lệ',1,1,5,9),(20,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','012','huyện Hòa Vang','huyện Hòa Vang',1,1,5,9),(21,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','013','huyện Hoàng Sa','huyện Hoàng Sa',1,1,5,9),(26,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','018','phường Hòa Minh','phường Hòa Minh',1,1,6,14),(27,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','019','phường Tam Thuận','phường Tam Thuận',1,1,6,15),(28,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','020','phường Thanh Khê Tây','phường Thanh Khê Tây',1,1,6,15),(29,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','021','phường Thanh Khê Đông','phường Thanh Khê Đông',1,1,6,15),(30,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','022','phường Xuân Hà','phường Xuân Hà',1,1,6,15),(31,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','023','phường Tân Chính','phường Tân Chính',1,1,6,15),(32,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','024','phường Chính Gián','phường Chính Gián',1,1,6,15),(33,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','025','phường Vĩnh Trung','phường Vĩnh Trung',1,1,6,15),(34,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','026','phường Thạc Gián','phường Thạc Gián',1,1,6,15),(35,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','027','phường An Khê','phường An Khê',1,1,6,15),(36,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','028','phường Hòa Khê','phường Hòa Khê',1,1,6,15),(37,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','029','phường Thanh Bình','phường Thanh Bình',1,1,6,16),(38,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','030','phường Thuận Phước','phường Thuận Phước',1,1,6,16),(39,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','031','phường Thạch Thang','phường Thạch Thang',1,1,6,16),(40,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','032','phường Hải Châu  I','phường Hải Châu  I',1,1,6,16),(41,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','033','phường Hải Châu II','phường Hải Châu II',1,1,6,16),(42,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','034','phường Phước Ninh','phường Phước Ninh',1,1,6,16),(43,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','035','phường Hòa Thuận Tây','phường Hòa Thuận Tây',1,1,6,16),(44,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','036','phường Hòa Thuận Đông','phường Hòa Thuận Đông',1,1,6,16),(45,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','037','phường Nam Dương','phường Nam Dương',1,1,6,16),(46,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','038','phường Bình Hiên','phường Bình Hiên',1,1,6,16),(47,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','039','phường Bình Thuận','phường Bình Thuận',1,1,6,16),(48,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','040','phường Hòa Cường Bắc','phường Hòa Cường Bắc',1,1,6,16),(49,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','041','phường Hòa Cường Nam','phường Hòa Cường Nam',1,1,6,16),(50,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','042','phường Thọ Quang','phường Thọ Quang',1,1,6,17),(51,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','043','phường Nại Hiên Đông','phường Nại Hiên Đông',1,1,6,17),(52,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','044','phường Mân Thái','phường Mân Thái',1,1,6,17),(53,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','045','phường An Hải Bắc','phường An Hải Bắc',1,1,6,17),(54,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','046','phường Phước Mỹ','phường Phước Mỹ',1,1,6,17),(55,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','047','phường An Hải Tây','phường An Hải Tây',1,1,6,17),(56,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','048','phường An Hải Đông','phường An Hải Đông',1,1,6,17),(57,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','049','phường Mỹ An','phường Mỹ An',1,1,6,18),(58,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','050','phường Khuê Mỹ','phường Khuê Mỹ',1,1,6,18),(59,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','051','phường Hoà Quý','phường Hoà Quý',1,1,6,18),(60,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','052','phường Hoà Hải','phường Hoà Hải',1,1,6,18),(61,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','053','phường Khuê Trung','phường Khuê Trung',1,1,6,19),(70,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','057','phường Hòa Thọ Đông','phường Hòa Thọ Đông',1,1,6,19),(69,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','056','phường Hòa Thọ Tây','phường Hòa Thọ Tây',1,1,6,19),(68,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','055','phường Hòa An','phường Hòa An',1,1,6,19),(67,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','054','phường Hòa Phát','phường Hòa Phát',1,1,6,19),(71,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','058','phường Hòa Xuân','phường Hòa Xuân',1,1,6,19),(72,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','059','xã Hòa Bắc','xã Hòa Bắc',1,1,3,20),(73,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','060','xã Hòa Liên','xã Hòa Liên',1,1,3,20),(74,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','061','xã Hòa Ninh','xã Hòa Ninh',1,1,3,20),(75,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','062','xã Hòa Sơn','xã Hòa Sơn',1,1,3,20),(76,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','063','xã Hòa Nhơn','xã Hòa Nhơn',1,1,3,20),(77,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','064','xã Hòa Phú','xã Hòa Phú',1,1,3,20),(78,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','065','xã Hòa Phong','xã Hòa Phong',1,1,3,20),(79,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','066','xã Hòa Châu','xã Hòa Châu',1,1,3,20),(80,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','067','xã Hòa Tiến','xã Hòa Tiến',1,1,3,20),(81,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','068','xã Hòa Phước','xã Hòa Phước',1,1,3,20),(82,'\0','2017-04-23 11:18:40','2017-04-23 11:18:40','069','xã Hòa Khương','xã Hòa Khương',1,1,3,20);
/*!40000 ALTER TABLE `donvihanhchinh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `giaiquyetdon`
--

DROP TABLE IF EXISTS `giaiquyetdon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `giaiquyetdon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `chucVu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `donChuyen` bit(1) NOT NULL,
  `laTTXM` bit(1) NOT NULL,
  `old` bit(1) NOT NULL,
  `thuTuThucHien` int(11) NOT NULL,
  `tinhTrangGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `yKienGiaiQuyet` longtext COLLATE utf8_vietnamese_ci,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `canBoXuLyChiDinh_id` bigint(20) DEFAULT NULL,
  `congChuc_id` bigint(20) DEFAULT NULL,
  `donViChuyenDon_id` bigint(20) DEFAULT NULL,
  `donViGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `nextForm_id` bigint(20) DEFAULT NULL,
  `nextState_id` bigint(20) DEFAULT NULL,
  `phongBanGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `soTiepCongDan_id` bigint(20) DEFAULT NULL,
  `thongTinGiaiQuyetDon_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKaqoyonge1hpdsveym1ff6sjb9` (`nguoiSua_id`),
  KEY `FKqra0r04vqy33g4s64v2boh9mj` (`nguoiTao_id`),
  KEY `FKplbaa7jsmjx4e3kladjq5cnrd` (`canBoXuLyChiDinh_id`),
  KEY `FK6vhuyukjhvuj0mv47gioshp2c` (`congChuc_id`),
  KEY `FK8wohf7qotprbk7vh3insdg326` (`donViChuyenDon_id`),
  KEY `FKt2obad00p4qd6hlh14ba0k7ub` (`donViGiaiQuyet_id`),
  KEY `FKknh8aqhk2xl3lkxpo4k2uboi7` (`nextForm_id`),
  KEY `FK2dgl89ia5u6i2jynuaxbjra4e` (`nextState_id`),
  KEY `FKr1kd4rsxo24a4euhdcp4dsvvo` (`phongBanGiaiQuyet_id`),
  KEY `FK8bnmxaixhesm2qw9ydbr1blxo` (`soTiepCongDan_id`),
  KEY `FKkew05m2wjplc3i4b9mawhl4kq` (`thongTinGiaiQuyetDon_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `giaiquyetdon`
--

LOCK TABLES `giaiquyetdon` WRITE;
/*!40000 ALTER TABLE `giaiquyetdon` DISABLE KEYS */;
/*!40000 ALTER TABLE `giaiquyetdon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `giayuyquyen`
--

DROP TABLE IF EXISTS `giayuyquyen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `giayuyquyen` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `duongDan` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `congDan_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKrmlg1xckpiydvluj2oaocb0lx` (`nguoiSua_id`),
  KEY `FKhelmbi3iux2lyljlh17fqt4vs` (`nguoiTao_id`),
  KEY `FKjt8utfc7xoehvnirferc17e6i` (`congDan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `giayuyquyen`
--

LOCK TABLES `giayuyquyen` WRITE;
/*!40000 ALTER TABLE `giayuyquyen` DISABLE KEYS */;
/*!40000 ALTER TABLE `giayuyquyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invalidtoken`
--

DROP TABLE IF EXISTS `invalidtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invalidtoken` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `token` longtext COLLATE utf8_vietnamese_ci,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKsxehts5f7ahh4um3g23pq965h` (`nguoiSua_id`),
  KEY `FK1xr1dxav6q3u8g79yyvjh4f3a` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invalidtoken`
--

LOCK TABLES `invalidtoken` WRITE;
/*!40000 ALTER TABLE `invalidtoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `invalidtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lichsuquatrinhxuly`
--

DROP TABLE IF EXISTS `lichsuquatrinhxuly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lichsuquatrinhxuly` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `ngayXuLy` datetime DEFAULT NULL,
  `noiDung` longtext COLLATE utf8_vietnamese_ci,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `thuTuThucHien` int(11) NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `don_id` bigint(20) DEFAULT NULL,
  `donViXuLy_id` bigint(20) DEFAULT NULL,
  `nguoiXuLy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKt86xmfgpw4w0edeyyub0nq1wk` (`nguoiSua_id`),
  KEY `FKfpms7b7lj930vef3l1bni0wja` (`nguoiTao_id`),
  KEY `FK8kly90h20osnbj2vaxld9m7cm` (`don_id`),
  KEY `FKio7gvggym3tdtu87dtlaj31rh` (`donViXuLy_id`),
  KEY `FKq2l74p0b1ht5p67kcoi8igebs` (`nguoiXuLy_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lichsuquatrinhxuly`
--

LOCK TABLES `lichsuquatrinhxuly` WRITE;
/*!40000 ALTER TABLE `lichsuquatrinhxuly` DISABLE KEYS */;
/*!40000 ALTER TABLE `lichsuquatrinhxuly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lichsuthaydoi`
--

DROP TABLE IF EXISTS `lichsuthaydoi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lichsuthaydoi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `chiTietThayDoi` longtext COLLATE utf8_vietnamese_ci,
  `doiTuongThayDoi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `idDoiTuong` bigint(20) DEFAULT NULL,
  `noiDung` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbf8c0l5r75h4000beia7f1rg0` (`nguoiSua_id`),
  KEY `FKa9ima7a6hqqc2mqldaj93owui` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lichsuthaydoi`
--

LOCK TABLES `lichsuthaydoi` WRITE;
/*!40000 ALTER TABLE `lichsuthaydoi` DISABLE KEYS */;
/*!40000 ALTER TABLE `lichsuthaydoi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linhvucdonthu`
--

DROP TABLE IF EXISTS `linhvucdonthu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linhvucdonthu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `linhVucKhac` bit(1) NOT NULL,
  `loaiDon` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `ma` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soThuTu` int(11) NOT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `cha_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8kjnjuj5m9k3h26hws6dfo1ci` (`nguoiSua_id`),
  KEY `FK4a77ckc5l0x15i8fgjfh6s94i` (`nguoiTao_id`),
  KEY `FK5ufddli1x5lbcvwd06o3omv4v` (`cha_id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linhvucdonthu`
--

LOCK TABLES `linhvucdonthu` WRITE;
/*!40000 ALTER TABLE `linhvucdonthu` DISABLE KEYS */;
INSERT INTO `linhvucdonthu` VALUES (1,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','001','Hành chính',1,'Hành chính',1,1,NULL),(2,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','002','Tôn giáo, tín ngưỡng',1,'Tôn giáo, tín ngưỡng',1,1,1),(3,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','003','Chế độ, chính sách',2,'Chế độ, chính sách',1,1,1),(4,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','004','Đất đai, nhà cửa',3,'Đất đai, nhà cửa',1,1,1),(5,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','005','Khác',4,'Khác',1,1,1),(6,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','006','Tư pháp',2,'Tư pháp',1,1,NULL),(7,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','007','Điều tra',1,'Điều tra',1,1,6),(8,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','008','Truy tố',2,'Truy tố',1,1,6),(9,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','009','Xét xử',3,'Xét xử',1,1,6),(10,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','010','Thi hành án',4,'Thi hành án',1,1,6),(11,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','011','Đảng, Đoàn thể',3,'Đảng, Đoàn thể',1,1,NULL),(12,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','012','Vi phạm điều lệ, kỉ luật Đảng',1,'Vi phạm điều lệ, kỉ luật Đảng',1,1,11),(13,'\0','2017-04-24 10:32:37','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','013','Khác',4,'Khác',1,1,NULL),(14,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','014','Đối với người lao động',1,'Đối với người lao động',1,1,3),(15,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','015','Hành chính',1,'Hành chính',1,1,NULL),(16,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','016','Tư pháp',2,'Tư pháp',1,1,NULL),(20,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','020','Môi trường',1,'Môi trường',1,1,NULL),(17,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','017','Đảng, Đoàn thể',3,'Đảng, Đoàn thể',1,1,NULL),(18,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','018','Vi phạm pháp luật trong các lĩnh vực',1,'Vi phạm pháp luật trong các lĩnh vực',1,1,15),(19,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','019','Đất đai',2,'Đất đai',1,1,NULL),(21,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','021','Tư pháp',3,'Tư pháp',1,1,NULL),(22,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','022','Quy hoạch, xây dựng, quản lý đô thị',4,'Quy hoạch, xây dựng, quản lý đô thị',1,1,NULL),(23,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','023','Giáo dục, đào tạo, y tế',5,'Giáo dục, đào tạo, y tế',1,1,NULL),(24,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','024','Giao thông, vận tải',6,'Giao thông, vận tải',1,1,NULL),(25,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','025','Thông tin, truyền thông',7,'Thông tin, truyền thông',1,1,NULL),(26,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_TRANH_CHAP_DAT','026','Hành chính',1,'Hành chính',1,1,NULL),(27,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_TRANH_CHAP_DAT','027','Đất đai',2,'Đất đai',1,1,26),(41,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','041','Kinh tế',1,'Kinh tế',1,1,18),(28,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','028','Đối với người có công',2,'Đối với người có công',1,1,3),(29,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','029','Thu hồi',1,'Thu hồi',1,1,4),(30,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','030','Bồi thường, hỗ trợ, tái',2,'Bồi thường, hỗ trợ, tái',1,1,4),(31,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','031','Tranh chấp',3,'Tranh chấp',1,1,4),(32,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','032','Đòi nhà',4,'Đòi nhà',1,1,4),(34,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','034','Cấp giấy chứng nhận',5,'Cấp giấy chứng nhận',1,1,4),(33,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','033','Đòi đất',6,'Đòi đất',1,1,4),(35,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_KHIEU_NAI','035','Khác',7,'Khác',1,1,4),(36,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','036','Vi phạm hoạt động công vụ',2,'Vi phạm hoạt động công vụ',1,1,15),(37,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','037','Tham nhũng',1,'Tham nhũng',1,1,16),(38,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','038','Vi phạm luật hình sự',2,'Vi phạm luật hình sự',1,1,16),(39,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','039','Khác',4,'Khác',1,1,NULL),(40,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','040','Vi phạm điều lệ, kỉ luật Đảng',1,'Vi phạm điều lệ, kỉ luật Đảng',1,1,17),(42,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','042','Văn hóa Xã hội',2,'Văn hóa Xã hội',1,1,18),(43,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','043','Đất đai',3,'Đất đai',1,1,18),(44,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','044','Tài nguyên mội trường',4,'Tài nguyên mội trường',1,1,18),(45,'\0','2017-04-24 10:31:04','2017-04-24 10:32:37','\0','DON_TO_CAO','045','Tôn giáo, tín ngưỡng',5,'Tôn giáo, tín ngưỡng',1,1,18),(47,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','047','Văn hóa, thể thao, du lịch',8,'Văn hóa, thể thao, du lịch',1,1,NULL),(48,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','048','Thuế, tài chính',9,'Thuế, tài chính',1,1,NULL),(49,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','049','Nông nghiệp và phát triển nông thôn',10,'Nông nghiệp và phát triển nông thôn',1,1,NULL),(50,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','050','Kế hoạch và đầu tư',11,'Kế hoạch và đầu tư',1,1,NULL),(51,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','051','Khoa học công nghệ',12,'Khoa học công nghệ',1,1,NULL),(52,'\0','2017-04-24 10:32:30','2017-04-24 10:32:37','\0','DON_KIEN_NGHI_PHAN_ANH','052','Khác',13,'Khác',1,1,NULL);
/*!40000 ALTER TABLE `linhvucdonthu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loaicoquanquanly`
--

DROP TABLE IF EXISTS `loaicoquanquanly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loaicoquanquanly` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK828hnqxbnb71xfuwd5o29999k` (`nguoiSua_id`),
  KEY `FK6rpc6hsmc4i3w3iiwy0vcmw96` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loaicoquanquanly`
--

LOCK TABLES `loaicoquanquanly` WRITE;
/*!40000 ALTER TABLE `loaicoquanquanly` DISABLE KEYS */;
INSERT INTO `loaicoquanquanly` VALUES (2,'\0','2017-05-03 13:20:39','2017-05-03 13:20:41','Bộ Công An','Bộ Công An',1,1),(1,'\0','2017-05-03 13:20:39','2017-05-03 13:20:41','Sở Y Tế','Sở Y Tế',1,1);
/*!40000 ALTER TABLE `loaicoquanquanly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loaitailieu`
--

DROP TABLE IF EXISTS `loaitailieu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loaitailieu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soThuTu` int(11) NOT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3wnssk7lrmpa95kuuip3024y7` (`nguoiSua_id`),
  KEY `FKmsjjnjbwyc2ethakh05latafr` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loaitailieu`
--

LOCK TABLES `loaitailieu` WRITE;
/*!40000 ALTER TABLE `loaitailieu` DISABLE KEYS */;
INSERT INTO `loaitailieu` VALUES (1,'\0','2017-05-03 15:47:23','2017-04-27 08:29:07','Văn bản',1,'Văn bản',1,1),(2,'\0','2017-05-03 15:53:34','2017-05-03 15:47:36','Video',2,'Video',1,1),(3,'\0','2017-05-03 15:53:31','2017-05-03 15:50:26','Hình ảnh',3,'Hình ảnh',1,1),(4,'\0','2017-05-03 15:53:45','2017-05-03 15:53:45','File ghi âm',4,'File ghi âm',1,1);
/*!40000 ALTER TABLE `loaitailieu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medial_doandicung`
--

DROP TABLE IF EXISTS `medial_doandicung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medial_doandicung` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKtdq4u30ed3rw277ecyo73vva3` (`nguoiSua_id`),
  KEY `FKjurcj38qi8k8hxknltlwmwnpk` (`nguoiTao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medial_doandicung`
--

LOCK TABLES `medial_doandicung` WRITE;
/*!40000 ALTER TABLE `medial_doandicung` DISABLE KEYS */;
/*!40000 ALTER TABLE `medial_doandicung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medial_doncongdan`
--

DROP TABLE IF EXISTS `medial_doncongdan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medial_doncongdan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6usuw7ves846reoahcdnm1hqt` (`nguoiSua_id`),
  KEY `FKmj2yc9vessmt4q5ctc7p1cyow` (`nguoiTao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medial_doncongdan`
--

LOCK TABLES `medial_doncongdan` WRITE;
/*!40000 ALTER TABLE `medial_doncongdan` DISABLE KEYS */;
/*!40000 ALTER TABLE `medial_doncongdan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medial_form_state`
--

DROP TABLE IF EXISTS `medial_form_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medial_form_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `currentForm` tinyblob,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKoxf9js6a2gajuisxonut54k8n` (`nguoiSua_id`),
  KEY `FK80u4v8o7tpr76axsmx4vwfsvo` (`nguoiTao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medial_form_state`
--

LOCK TABLES `medial_form_state` WRITE;
/*!40000 ALTER TABLE `medial_form_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `medial_form_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medial_process`
--

DROP TABLE IF EXISTS `medial_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medial_process` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1nt1mg43cl1q52pvjbj96sanf` (`nguoiSua_id`),
  KEY `FK8031wudhyp6lcr4xpfh1p4ncq` (`nguoiTao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medial_process`
--

LOCK TABLES `medial_process` WRITE;
/*!40000 ALTER TABLE `medial_process` DISABLE KEYS */;
/*!40000 ALTER TABLE `medial_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medial_tailieubangchung`
--

DROP TABLE IF EXISTS `medial_tailieubangchung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medial_tailieubangchung` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2ikj0e4kc2wfci5xyudxovch4` (`nguoiSua_id`),
  KEY `FKc2ckhslcnhh01wbyvk9g9d1d9` (`nguoiTao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medial_tailieubangchung`
--

LOCK TABLES `medial_tailieubangchung` WRITE;
/*!40000 ALTER TABLE `medial_tailieubangchung` DISABLE KEYS */;
/*!40000 ALTER TABLE `medial_tailieubangchung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medial_tailieuvanthu`
--

DROP TABLE IF EXISTS `medial_tailieuvanthu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medial_tailieuvanthu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbknof9b5xyspmovx21vr7lss` (`nguoiSua_id`),
  KEY `FKsa4b9ssyx6oavxd4cy4igh520` (`nguoiTao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medial_tailieuvanthu`
--

LOCK TABLES `medial_tailieuvanthu` WRITE;
/*!40000 ALTER TABLE `medial_tailieuvanthu` DISABLE KEYS */;
/*!40000 ALTER TABLE `medial_tailieuvanthu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medial_tepdinhkem`
--

DROP TABLE IF EXISTS `medial_tepdinhkem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medial_tepdinhkem` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKhixd7sp1w76ttbe9qd6c1tljn` (`nguoiSua_id`),
  KEY `FKjvpl31mpa33tx80k1resl2yy7` (`nguoiTao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medial_tepdinhkem`
--

LOCK TABLES `medial_tepdinhkem` WRITE;
/*!40000 ALTER TABLE `medial_tepdinhkem` DISABLE KEYS */;
/*!40000 ALTER TABLE `medial_tepdinhkem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nguoidung`
--

DROP TABLE IF EXISTS `nguoidung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nguoidung` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `email` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `matKhau` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `salkey` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `vaiTroMacDinh_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKj7xotjm1dm5pirxi26gxos8t5` (`nguoiSua_id`),
  KEY `FKeabbvfd8a1o51p2pbjnvcbydk` (`nguoiTao_id`),
  KEY `FK4oq97pi5mobmpar00hwqj327q` (`vaiTroMacDinh_id`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nguoidung`
--

LOCK TABLES `nguoidung` WRITE;
/*!40000 ALTER TABLE `nguoidung` DISABLE KEYS */;
INSERT INTO `nguoidung` VALUES (1,'\0','2017-06-10 16:06:31','2017-04-24 10:49:48','','admin@danang.gov.vn','8dc12f49943d3305e49bd87d26e4c4bf','L8LWQ8eZFMpu1+AsqxRb/seH166G/iRY',1,1,1),(2,'\0','2017-06-10 16:07:05','2017-05-03 15:30:58','','namtvd@danang.gov.vn','47617de8848cb3031d008b180a4dd82e','/qSJ1OEet4MprtKovK9xXEMO6wBfN21c',1,1,2),(4,'\0','2017-06-10 16:07:10','2017-05-03 15:51:28','','thanhpx@danang.gov.vn','fb1c742480899b0de56aed55bcd44d55','7JTAQTtxge2xdA+E7ZZNyzw/r31fowVa',1,1,3),(5,'\0','2017-06-10 16:07:01','2017-05-03 15:52:46','','anvt@danang.gov.vn','a58ef10f165afc02728b7dcbf32a137e','+Jgigb9UOPv1J1BrSEnw/u8g+pis8y23',1,1,4),(6,'\0','2017-06-10 16:07:07','2017-05-17 19:06:57','','vinhlv@danang.gov.vn','56b567c66a1ecd5342406c798abeac25','NuUeBrHmYkITYXaEFe9v2xE5wB7rGuBP',1,1,2),(11,'\0','2017-06-10 16:06:43','2017-05-17 19:52:42','','thienpd@danang.gov.vn','0500a1398a85c343998479bf08b26ccb','6aETrNWR/p8YdRVu7Q/78MC6kZlH3Q1S',1,1,1),(7,'\0','2017-06-10 16:07:13','2017-05-17 19:42:57','','thanghq@danang.gov.vn','463421a070dc0eb15cca3f45720a5ebd','CzUDm7/rIsUgR7aG5B41QnKayrSS0n+J',1,1,3),(8,'\0','2017-06-10 16:07:27','2017-05-17 19:43:49','','toantt@danang.gov.vn','729b6d4e79f57fdca83dc95e72082f1b','RvwQ6tD1TOZPwZFYuGtQkCFoGhGSvkXM',1,1,3),(9,'\0','2017-06-10 16:06:34','2017-05-17 19:44:59','','tttp@danang.gov.vn','97ba5a976aada33b83d2592815b5ea4a','LEqhvXoSp0lp+sciRAPA8HYXwTYUu52D',1,1,1),(10,'\0','2017-06-10 16:06:40','2017-05-17 19:47:34','','thanhhx@danang.gov.vn','48d605e2dc607c5fc553c86b2bd6a9bd','fLoCuw1jfOIIoH5RYhP8tF1EC7tD9zYC',1,1,1),(12,'\0','2017-06-10 16:06:37','2017-05-17 19:53:38','','vutx@danang.gov.vn','69979180716cd53a419c2321dfe151aa','0ld8Lj9q0A0JeGhV2Qw3egzWH+2CXrpr',1,1,1),(13,'\0','2017-06-11 08:58:45','2017-05-31 16:37:56','','stnmt@danang.gov.vn','b9932b995e33df7dce392d0769be9992','Tyx2DAAWpYwqL22EcfmRTvNjS4zDMaLE',1,1,1),(14,'\0','2017-06-11 08:58:42','2017-05-31 16:39:46','','mynv@danang.gov.vn','31f11998e09f02f53cfe83d073a69c62','g5lwGMk4SQYey9b1hqbpFAhJ+sP2nq6S',1,1,3),(15,'\0','2017-06-10 16:15:31','2017-05-31 16:44:22','','hungtt@danang.gov.vn','0ec8753739d3e69bee00a704371b37ce','L9ANeK9DLrOLdN9huMZZtNfo5bIcGsTh',1,1,2),(16,'\0','2017-06-10 16:15:19','2017-05-31 16:46:51','','nhanlt@danang.gov.vn','6deabdbe62203b9f7b59c25790611404','Bk1P2AGzY3K2J0IUlccN/YhkzSGwICbx',1,1,2),(18,'\0','2017-06-11 08:57:54','2017-06-10 17:23:12','','namnv@danang.gov.vn','912db0a51102d956c1fac222f25712ce','9Nw5bkQc4akmCvcvd1ZOLxmeVRikj7H8',1,1,3),(19,'\0','2017-06-11 08:58:27','2017-06-10 17:24:09','','hungnpx@danang.gov.vn','79e4cf18cac91f6dc998803359827178','yVEB9JSFOSGlLul0FmROhco9DeWG0YEK',1,1,3),(20,'\0','2017-06-11 08:59:18','2017-06-10 17:24:53','','bangvn@danang.gov.vn','734120eb250992af711f25eccdaf85f8','sd3ByGEMF7MDLuBH6RfK4VyuPcoaekYp',1,1,1),(21,'\0','2017-06-11 09:02:49','2017-06-10 17:25:33','','tranvth@danang.gov.vn','ea481521b112a570056927ec366c7282','8C7j/PbcSD3G5/7jkrOSu+EnrkW2fySf',1,1,1),(22,'\0','2017-06-11 09:31:43','2017-06-11 09:31:43','','vuha@danang.gov.vn','b18cf42d94319a1c976367b88bd7509c','G2k+BCBazGkmRDDyUgK3TYFGyN01T1S1',1,1,1),(23,'\0','2017-06-11 09:34:12','2017-06-11 09:34:12','','thuyttt@danang.gov.vn','b834d9de01a9fe0dd6d3d51b016dbfe5','zAP3tMUWVKTiRcdGhSRTQW/Q7qivYyps',1,1,4),(24,'\0','2017-06-11 09:35:23','2017-06-11 09:35:23','','dongnd@danang.gov.vn','76f4e50f0cd6e55b07db99159c7919e6','xrBx0COmH8C2KmWzV0ruX3MtZo0HYgkS',1,1,2),(25,'\0','2017-06-11 09:36:09','2017-06-11 09:36:09','','vuongbv@danang.gov.vn','2fd61f998350ad35caedb68556a455dc','K8yt37FyUO/KQfM7ELeu3ZKjuSLcomIV',1,1,2),(26,'\0','2017-06-11 09:37:52','2017-06-11 09:37:52','','phongpn@danang.gov.vn','0b76c81864d3f977f0f62a6ffc5d08be','4FPeIAIy7bXU3GwzY4eh+IKYMCPrBMRp',1,1,3),(27,'\0','2017-06-11 09:38:33','2017-06-11 09:38:33','','binhqd@danang.gov.vn','337a354eae5c25de5fe1b6d18551eaf9','4eIOuuW3EsdGHi/sIzY6GWfxW+aCs7DP',1,1,3),(28,'\0','2017-06-11 09:39:01','2017-06-11 09:39:01','','trongdd@danang.gov.vn','fdfcc75afefeb2ca6fa7e7beb913f196','TdcSpNvuB/n0hDEGGpTdkjRTWQ3Krpj1',1,1,3),(29,'\0','2017-06-11 09:39:50','2017-06-11 09:39:50','','huytbt@danang.gov.vn','c47c944871bf05be9aa079460cb925d0','MXFj9Sgq0Wb/Yvkvq/e9XoDDkIP0uzPD',1,1,2),(30,'\0','2017-06-11 09:41:36','2017-06-11 09:40:27','','toanpc@danang.gov.vn','4b2fce70470ee8f4b958b3f740fff049','HxTDZ+xXZw+YSqt9/rJOG2UeAaxAdDpT',1,1,2),(31,'\0','2017-06-11 09:41:39','2017-06-11 09:41:17','','thanhnt@danang.gov.vn','0fdf6c9e4d883c3085d531cbc6319d96','/Kie4vmPMz29YhO1qIZh+OU31xDdCP5R',1,1,3),(32,'\0','2017-06-11 09:42:06','2017-06-11 09:42:06','','truonghn@danang.gov.vn','ab9ff3bb217a0d73d1c33243b8ec9448','Q8uW8JWx6fCEuTntK4j92O0Oz8/ZSdSL',1,1,3),(33,'\0','2017-06-11 09:42:33','2017-06-11 09:42:33','','vietpq@danang.gov.vn','bdca3963fa36a59823dfa55446c940c2','4P7JxuvNaWlD8a/md2ht5FuEvuxn6pKO',1,1,3),(34,'\0','2017-06-11 09:48:07','2017-06-11 09:48:07','','sgtvt@danang.gov.vn','3e280ecc641199c71c912a612fdc1dc1','7xFMBtKLHz+zQgb7E49vw50WDQ1wmmA6',1,1,1),(35,'\0','2017-06-11 09:48:41','2017-06-11 09:48:41','','baonq@danang.gov.vn','515e0b9e42ca3871beee499a7eb40477','CNyPcKdkKnZtYtvZ0ioXcswj+za2Ybue',1,1,1),(36,'\0','2017-06-11 09:49:10','2017-06-11 09:49:10','','tinlvv@danang.gov.vn','c64218be054c347bcff19545b57758af','UHwYploNw/iNlLe7OFtjIL3sLhH211b4',1,1,1),(37,'\0','2017-06-11 09:49:34','2017-06-11 09:49:34','','hoand@danang.gov.vn','7c70703baad32f6b4251febcbf89481f','OQNokVY9FjPGTuxQiNiW4Ju40TJqbq6q',1,1,1),(38,'\0','2017-06-11 09:50:01','2017-06-11 09:50:01','','thaopn@danang.gov.vn','79d01327e490daea163c7b3a665b3564','aiJxVb+nKveAPz+exVq1vjiWJrobG3mU',1,1,4),(39,'\0','2017-06-11 09:51:24','2017-06-11 09:51:11','','dungvhp@danang.gov.vn','5b79ebb39e4e613c5bec046c315e153c','6ayWct0I6rRfDhVWDgPBNyUBMQHl2b/Q',1,1,2),(40,'\0','2017-06-11 09:51:49','2017-06-11 09:51:49','','vynln@danang.gov.vn','e6c0dc07c9ba686d588f4ca7520194af','HVbFGSi23jCnxV0+L2/jHsHcHT26EgKS',1,1,2),(41,'\0','2017-06-11 09:52:11','2017-06-11 09:52:11','','hieunh@danang.gov.vn','b8bf4cfc8e2cff95cd2630f09c46dea7','QoYJKKmYk6ddGqUDk6a4/YJg/lEA4eWM',1,1,3),(42,'\0','2017-06-11 09:52:51','2017-06-11 09:52:51','','ninhva@danang.gov.vn','7c8d7398bdda04adc17895e581d2a9f4','Lk2xCcjxVavINyJHrXR7dM9L+fCP//W8',1,1,3),(43,'\0','2017-06-11 09:53:16','2017-06-11 09:53:16','','minhnv@danang.gov.vn','3e9737281251151917dc14c7a5969224','tiN+5Hpv4ZIEwk7VKLtQYjx5xDUvoVuL',1,1,3),(44,'\0','2017-06-11 09:53:43','2017-06-11 09:53:43','','thanhvv@danang.gov.vn','5c0db98c6b69e5ad171e45b22b8ed18e','0ujb0DK0jzgiqRgXkSnenlXaoQz5YPOR',1,1,2),(45,'\0','2017-06-11 09:54:16','2017-06-11 09:54:16','','thanhnt1@danang.gov.vn','9f6ff4717f70c5e815368cba297e9f33','0IHdasE8UhAe0ZLJWiZkRHog6D4WCROE',1,1,2),(46,'\0','2017-06-11 09:54:38','2017-06-11 09:54:38','','ducl@danang.gov.vn','f51d1f17615299806ebcfd4cb7c1f8cf','GDbWL55V/6YL2Gpa7vhiP+17aKVNKi/8',1,1,3),(47,'\0','2017-06-11 09:55:05','2017-06-11 09:55:05','','autn@danang.gov.vn','98fcaef7d84d5118939c9007bc011c57','T7jlw07SjotT0+3sCKC0d0AEZK9MgS01',1,1,3),(48,'\0','2017-06-11 09:55:25','2017-06-11 09:55:25','','vuhn@danang.gov.vn','8f2ddd72af341ccac16f40cc60cc66f9','OmN8aU2gQhGtPFH2bssSYf154x+9frLL',1,1,3),(49,'\0','2017-06-11 09:58:10','2017-06-11 09:58:10','','sxd@danang.gov.vn','11dd2fa46d0078a93d72a83a323afd45','qNnV81cSBZMwQ19DTM5Cf7ZX6mMKNLLL',1,1,1),(50,'\0','2017-06-11 09:59:49','2017-06-11 09:59:49','','hoantt@danang.gov.vn','b022c7b75a8078a5398e176c149c24fa','MoQgEQMNBMD/fS3rYdvh07KQc20f/ThZ',1,1,1),(51,'\0','2017-06-11 10:00:17','2017-06-11 10:00:17','','lanhtv@danang.gov.vn','c59e751e8a6b2e20d27fed8564d8cdf8','X0+iVet6VoA+hLDMUQCmxoDx4HrNS3oc',1,1,1),(52,'\0','2017-06-11 10:00:46','2017-06-11 10:00:46','','giangnt@danang.gov.vn','cc9e04f72009b5638461c2e8139e7176','z0av+zG9NRQyPJF0+tLmmW2pDPeom56d',1,1,1),(53,'\0','2017-06-11 10:01:12','2017-06-11 10:01:12','','khanhtp@danang.gov.vn','42b9c54a6e4c816223f214bda84dc771','3vlfmp8qprb6jfTGPIlXyq/RbEm2xSM9',1,1,4),(54,'\0','2017-06-11 10:01:44','2017-06-11 10:01:44','','minhtv@danang.gov.vn','30a76e954bcd0ddf617a0a6b62c4ac10','zztG9sXIALqW/v1W2jkMxM5wR4CuwhrK',1,1,2),(55,'\0','2017-06-11 10:02:06','2017-06-11 10:02:06','','tuanhm@danang.gov.vn','6662f786e70ce96306de4ba46aea36a6','Z3mhcwQ/1kCcdMiyIgvjWc4ASiP0BG9q',1,1,2),(56,'\0','2017-06-11 10:02:30','2017-06-11 10:02:30','','tientn@danang.gov.vn','899c2e01b0afab40eaccbfff527c6ecc','X3Fklh6JopoAdYBSUm+cvHq3uFgzhj/9',1,1,3),(57,'\0','2017-06-11 10:02:51','2017-06-11 10:02:51','','thanhhc@danang.gov.vn','21f81ed014ac5d025283e2f7fcfcf7c7','VpZZU6s8Igz5zigKMVLYecEQzlt2RqbW',1,1,3),(58,'\0','2017-06-11 10:03:23','2017-06-11 10:03:23','','thangdq@danang.gov.vn','c96908d4d5bc7bb67c89c870d0feb812','Hqplv+Ra0ZqCtqoVgq8zWyoBtKezW8WY',1,1,3),(59,'\0','2017-06-11 10:03:54','2017-06-11 10:03:46','','tanld@danang.gov.vn','b6767511551b916ed1dcbfd1a7b3e32b','prGHdfEpjMpJk/I/78IuJRBkYMRoU/3o',1,1,2),(60,'\0','2017-06-11 10:04:18','2017-06-11 10:04:18','','toandtc@danang.gov.vn','93de04d41db8fc4def8a8eceda9377ed','+Z05hVGp27w7lryZjLTq7Zr9X1zi8nNu',1,1,2),(61,'\0','2017-06-11 10:04:44','2017-06-11 10:04:44','','nghialt@danang.gov.vn','6941e2514ec8e370c880a27a94325b70','DEjugO8HBf4Vzk5kN3zHXNFV+Bsv88xU',1,1,3),(62,'\0','2017-06-11 10:05:07','2017-06-11 10:05:07','','tuanlk@danang.gov.vn','9d8deef2c669125500ec10446a18916b','rIgvKX3cmVilvroSH+JuhN+rkkU898+U',1,1,3),(63,'\0','2017-06-11 10:05:33','2017-06-11 10:05:33','','phutlq@danang.gov.vn','d66b2fc4a7df66d5093592404e1a5565','4OeosYmVAj+TRgug+RumIfCkfruJEb51',1,1,3),(64,'\0','2017-06-11 10:08:28','2017-06-11 10:08:28','','quanthanhkhe@danang.gov.vn','aaa299a6b9bd629e8883de56d2e6f016','c+H+KJnay0+gK63562t0V6tnQIWAF7Ly',1,1,1),(65,'\0','2017-06-11 10:08:57','2017-06-11 10:08:57','','huyenttt@danang.gov.vn','66bdade57e00ef3b88faa49661005c55','MUMFv9qHd/0WzF+1FxXxKvYJA3izF0tZ',1,1,1),(66,'\0','2017-06-11 10:09:27','2017-06-11 10:09:27','','chinhth@danang.gov.vn','d0006b47744bd4838d9d88999df83562','kNJ4ECNqx7sMiwloumaxRYjbjt7RwBCZ',1,1,1),(67,'\0','2017-06-11 10:11:56','2017-06-11 10:11:42','','haoda@danang.gov.vn','f32d01d28b026ed151ddc238e05c4f03','fmOAXdaR2RF2QtLEBBN9eUlPPQ3kUbPw',1,1,1),(68,'\0','2017-06-11 10:12:19','2017-06-11 10:12:19','','thuongbth@danang.gov.vn','fd7fd6300f152d2a2611732463b1d92a','O/0kqfZgfiXQXTBOYQbOCBLwPn8HhrPy',1,1,4),(69,'\0','2017-06-11 10:14:07','2017-06-11 10:14:07','','thuybtt@danang.gov.vn','88e7406630c628a130b5f9fc1edc6bbf','F6B2KOPZMvTZAo52NsoCv9XKZoMhrmxB',1,1,2),(70,'\0','2017-06-11 10:14:39','2017-06-11 10:14:39','','hoaitt@danang.gov.vn','e2f1f9dbe7c797142224ace4832c3c91','Jr3E5he3Bw8zhVxJS7hmgQE7PBiRIaa6',1,1,2),(71,'\0','2017-06-11 10:15:20','2017-06-11 10:15:20','','sangtx@danang.gov.vn','444ffbcc54fc93465c85eedecb65a53b','R0aQRq8daCiqfGZ53N7TG9HvR5lFzi3s',1,1,3),(72,'\0','2017-06-11 10:16:13','2017-06-11 10:16:13','','tinhlv@danang.gov.vn','18975727fc1858c4765a4e8b2afec313','jAQDQp54qY7C6o+aIJmIEwZdJVX+23Np',1,1,3),(73,'\0','2017-06-11 10:16:36','2017-06-11 10:16:36','','thanhtcn@danang.gov.vn','4fd0fa80a6fd644aa5cd1b1747a64abb','JNBHMyoWRpanykYc8Kj8zbaF52ysMoNR',1,1,3),(74,'\0','2017-06-11 10:17:49','2017-06-11 10:17:49','','huongkpa@danang.gov.vn','6f988f6ae9ff80416e9b098bd1a848a0','H2HcDQMp8WgqaZX87bDEbAXz7sWjx+aq',1,1,2),(75,'\0','2017-06-11 10:18:28','2017-06-11 10:18:28','','thuongdtt@danang.gov.vn','7694af1a0d7591f484af645abf35ccae','KLUzs5su1BvQ1ybVL9vSaKrcULBTT84t',1,1,2),(76,'\0','2017-06-11 10:18:48','2017-06-11 10:18:48','','hongnt@danang.gov.vn','ebba5c78c7209d43664fb5b74be11afc','5V/4sKUpZUQzBiQEdGmywUkCCG7grrIK',1,1,3),(77,'\0','2017-06-11 10:19:26','2017-06-11 10:19:26','','hoannx@danang.gov.vn','1f83f844168df33e83568431cae6771a','i9x/qrkTU0ks3ydxtc/QVZhG9Xrz1//2',1,1,3),(78,'\0','2017-06-11 10:20:01','2017-06-11 10:20:01','','namdh@danang.gov.vn','54d6e664560b8493de0d0ccd5c8e5dbc','usRvCA7CyB+1PnjLsU+7WWxgoLSinqR/',1,1,3),(79,'\0','2017-06-11 10:24:55','2017-06-11 10:24:55','','quanhaichau@danang.gov.vn','4d0448015df0b585a81ce85ab171a49c','l5SsI268owfX/SclpISBpuTJ1BqFWACs',1,1,1),(80,'\0','2017-06-11 10:25:23','2017-06-11 10:25:23','','cuonglv@danang.gov.vn','e3c917d7ead856de4431eac303fec915','4gINqV+3SIq7SEsA7nsnPedvgKxwCtSK',1,1,1),(81,'\0','2017-06-11 10:25:48','2017-06-11 10:25:48','','chivt@danang.gov.vn','bb8f7125e51588b999686fbfa047ff47','aGxE0LRcQzRAdF0Ro3Jn7CNMsvljWxfB',1,1,1),(82,'\0','2017-06-11 10:26:14','2017-06-11 10:26:14','','tuannc@danang.gov.vn','3c83b8ceaaff84e22f74db40fd4c037f','tLYknYn6E2xTTe4hq8eFrsJlAcuXeaAL',1,1,1),(83,'\0','2017-06-11 10:26:38','2017-06-11 10:26:38','','vynty@danang.gov.vn','187ac28b84bc922c0d5ef3fccd974874','9Bg7iVPA1Z4RQClSu3dW3CgxuxHHypfv',1,1,4),(84,'\0','2017-06-11 10:26:59','2017-06-11 10:26:59','','huongtt@danang.gov.vn','fd9183c926e7c1baae9330e47e411dbc','1DrFY/C5w64BiOxt20BcfFBvAcbkNg9m',1,1,2),(85,'\0','2017-06-11 10:27:22','2017-06-11 10:27:22','','trangttu@danang.gov.vn','7e71b1409257864d751fd8a934f5eb4e','xiNUCG/5lrrHTlgQh4OJteZ39PVDtfIV',1,1,2),(86,'\0','2017-06-11 10:27:42','2017-06-11 10:27:42','','thuht@danang.gov.vn','132114e1f2e00b957b45a2e93a357a7a','+qYlfcfUpUIfpnAuXXpzNDMNESPQIbZ9',1,1,3),(87,'\0','2017-06-11 10:28:07','2017-06-11 10:28:07','','anndk@danang.gov.vn','1e09e66d45ce5e122189f41b4bbe85e4','YFuEri+BU8ZQgMjzFQxpHoDefzHFecoq',1,1,3),(88,'\0','2017-06-11 10:30:01','2017-06-11 10:30:01','','huynd@danang.gov.vn','a6cb24600462b4c57d912bc7d885f280','BLolEh6LAo1ANGP2R6a9SUCwrsyq1LVD',1,1,3),(89,'\0','2017-06-11 10:30:29','2017-06-11 10:30:29','','gianh@danang.gov.vn','4586d131409f128dd9f02b5b8f0b991c','sqNwv8+YRHSkZHjRAi1FySxS5U6vh9W9',1,1,2),(90,'\0','2017-06-11 10:30:56','2017-06-11 10:30:56','','maipt@danang.gov.vn','4dbc57412f92e3fce5fa8412d314e729','ARiPOGvuTHf5i/qtak8koEsoD9BePclD',1,1,2),(91,'\0','2017-06-11 10:31:28','2017-06-11 10:31:28','','tramhch@danang.gov.vn','9be55946a68546d93e56cd4fb64f9b67','RnYj8zvLYl25EpvUHzdmgPeRudLOzKeU',1,1,3),(92,'\0','2017-06-11 10:31:56','2017-06-11 10:31:56','','vanntb@danang.gov.vn','b52b26caabdb6c072e11506fe091661b','u7HkGwwpzS02JmMMWD5RRqufHVaKVqY1',1,1,3),(93,'\0','2017-06-11 10:32:17','2017-06-11 10:32:17','','nganta@danang.gov.vn','4c37bc3046e4c4dc61f68a90f7e15615','ZlBijUxybHhEdfAwv8yfqVO07GJqorMM',1,1,3),(94,'\0','2017-06-11 10:33:59','2017-06-11 10:33:59','','tanchinh@danang.gov.vn','bdf13e58c742b6204db38222506f6d96','gXCeuO52SwhuhRkAHKZZcNtuuJszJIdz',1,1,1),(95,'\0','2017-06-11 10:36:42','2017-06-11 10:36:42','','thanhbinh@danang.gov.vn','95ffdc9246e4d12d773aa9314da05533','6f3OvUi1BH+cNdALjLV8JSHTXXE2eP1v',1,1,1),(96,'\0','2017-07-21 00:46:29','2017-07-21 00:46:29','','ubndtpdn@danang.gov.vn','fd8ab09e68c2f59016b3683912e5e5cf','ZqYMBBtkmBA4f27NQBnjjmHaGtKixjzp',1,1,1),(97,'\0','2017-07-21 00:52:36','2017-07-21 00:50:31','','tamtv@danang.gov.vn','6118fd7b19e9b6ade35ffe67272390a5','4vS0Kz+RXL1chJGh2OF8f2fRn0o4UBel',1,1,4),(98,'\0','2017-07-21 00:52:23','2017-07-21 00:51:45','','hoalv@danang.gov.vn','1ab844a266ac1e189f00442c3e144030','EMsw71BxYJEgzal0zMxTVG3r0fbHpZ1c',1,1,2),(99,'\0','2017-07-21 00:52:17','2017-07-21 00:52:17','','tientx@danang.gov.vn','605d14c6dc2e610983b2aa3588eee824','J/thuKgfk39Rwmw672vVJaVb+INxQdLk',1,1,3),(100,'\0','2017-07-21 00:56:42','2017-07-21 00:56:42','','mailx@danang.gov.vn','fd97c105b3bebc513a0fb4e1b68190bb','3fOPTgj0VsREtrlNqNcISUJBknGGYPrv',1,1,2),(101,'\0','2017-07-21 00:57:22','2017-07-21 00:57:22','','tutt@danang.gov.vn','f5909d2948150f1fca3c2960f1a223f4','mOtkB8OKeWdcxAzEifev6fUP5mfdm7q5',1,1,3);
/*!40000 ALTER TABLE `nguoidung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nguoidung_quyen`
--

DROP TABLE IF EXISTS `nguoidung_quyen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nguoidung_quyen` (
  `nguoidung_id` bigint(20) NOT NULL,
  `quyens` longtext COLLATE utf8_vietnamese_ci,
  KEY `FKqdfgx2vnr6lihkltybhafc0gx` (`nguoidung_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nguoidung_quyen`
--

LOCK TABLES `nguoidung_quyen` WRITE;
/*!40000 ALTER TABLE `nguoidung_quyen` DISABLE KEYS */;
/*!40000 ALTER TABLE `nguoidung_quyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nguoidung_vaitro`
--

DROP TABLE IF EXISTS `nguoidung_vaitro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nguoidung_vaitro` (
  `nguoidung_id` bigint(20) NOT NULL,
  `vaitro_id` bigint(20) NOT NULL,
  PRIMARY KEY (`nguoidung_id`,`vaitro_id`),
  KEY `FKnyd5p3gsmyqm2b2j7hna2him8` (`vaitro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nguoidung_vaitro`
--

LOCK TABLES `nguoidung_vaitro` WRITE;
/*!40000 ALTER TABLE `nguoidung_vaitro` DISABLE KEYS */;
INSERT INTO `nguoidung_vaitro` VALUES (1,1),(2,2),(4,3),(5,4),(6,2),(7,3),(8,3),(9,1),(10,1),(11,1),(12,1),(13,1),(14,3),(15,2),(16,2),(18,3),(19,3),(20,1),(21,1),(22,1),(23,4),(24,2),(25,2),(26,3),(27,3),(28,3),(29,2),(30,2),(31,3),(32,3),(33,3),(34,1),(35,1),(36,1),(37,1),(38,4),(39,2),(40,2),(41,3),(42,3),(43,3),(44,2),(45,2),(46,3),(47,3),(48,3),(49,1),(50,1),(51,1),(52,1),(53,4),(54,2),(55,2),(56,3),(57,3),(58,3),(59,2),(60,2),(61,3),(62,3),(63,3),(64,1),(65,1),(66,1),(67,1),(68,4),(69,2),(70,2),(71,3),(72,3),(73,3),(74,2),(75,2),(76,3),(77,3),(78,3),(79,1),(80,1),(81,1),(82,1),(83,4),(84,2),(85,2),(86,3),(87,3),(88,3),(89,2),(90,2),(91,3),(92,3),(93,3),(94,1),(95,1),(96,1),(97,4),(98,2),(99,3),(100,2),(101,3);
/*!40000 ALTER TABLE `nguoidung_vaitro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quoctich`
--

DROP TABLE IF EXISTS `quoctich`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quoctich` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `ma` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdfnt1b6uy4xax7d4bb9nvfwse` (`nguoiSua_id`),
  KEY `FKnsx4y3fp1qw87nradwkd9vnw0` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=252 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quoctich`
--

LOCK TABLES `quoctich` WRITE;
/*!40000 ALTER TABLE `quoctich` DISABLE KEYS */;
INSERT INTO `quoctich` VALUES (106,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','IT','Italia','Italia',1,1),(107,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','JM','Gia-mai-ca','Gia-mai-ca',1,1),(108,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','JP','Nhật','Nhật',1,1),(109,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','JO','Gioóc-đa-ni','Gioóc-đa-ni',1,1),(110,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KZ','Ca-dắc-xtan','Ca-dắc-xtan',1,1),(111,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KE','Cộng hòa Kenya','Cộng hòa Kenya',1,1),(112,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KI','Cộng hòa Kiribati','Cộng hòa Kiribati',1,1),(113,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KP','Cộng hòa Dân chủ Nhân dân Triều Tiên','Cộng hòa Dân chủ Nhân dân Triều Tiên',1,1),(114,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KR','Hàn Quốc','Hàn Quốc',1,1),(115,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KW','Cô-oét','Cô-oét',1,1),(116,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KG','Cư-rơ-gư-dơ-xtan','Cư-rơ-gư-dơ-xtan',1,1),(117,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LA','Lào','Lào',1,1),(118,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LV','Lát-vi-a','Lát-vi-a',1,1),(119,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LB','Li-băng','Li-băng',1,1),(120,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LS','Vương quốc Lesotho','Vương quốc Lesotho',1,1),(121,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LR','Cộng hòa Liberia','Cộng hòa Liberia',1,1),(122,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LY','Li-bi','Li-bi',1,1),(123,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LI','Thân vương quốc Liechtenstein','Thân vương quốc Liechtenstein',1,1),(124,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LT','Lít-va','Lít-va',1,1),(125,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LU','Lúc-xăm-bua','Lúc-xăm-bua',1,1),(126,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MO','Ma Cao','Ma Cao',1,1),(127,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MK','Cộng hòa Macedonia','Cộng hòa Macedonia',1,1),(128,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MG','Cộng hòa Madagascar','Cộng hòa Madagascar',1,1),(129,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MW','Ma-la-uy','Ma-la-uy',1,1),(130,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MY','Malaysia','Malaysia',1,1),(131,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MV','Man-đi-vơ','Man-đi-vơ',1,1),(132,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','ML','Cộng hòa Mali','Cộng hòa Mali',1,1),(133,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MT','Cộng hòa Malta','Cộng hòa Malta',1,1),(134,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MH','Quần đảo Marshall','Quần đảo Marshall',1,1),(135,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MQ','Martinique','Martinique',1,1),(136,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MR','Mô-ri-ta-ni','Mô-ri-ta-ni',1,1),(137,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MU','Mô-ri-xơ','Mô-ri-xơ',1,1),(138,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','YT','Tỉnh Mayotte','Tỉnh Mayotte',1,1),(139,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MX','Mê-xi-cô','Mê-xi-cô',1,1),(140,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','FM','Liên bang Micronesia','Liên bang Micronesia',1,1),(141,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MD','Moldova','Moldova',1,1),(142,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MC','Công quốc Monaco','Công quốc Monaco',1,1),(143,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MN','Mông Cổ','Mông Cổ',1,1),(144,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MS','Montserrat','Montserrat',1,1),(145,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MA','Vương quốc Maroc','Vương quốc Maroc',1,1),(146,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MZ','Cộng hòa Mozambique','Cộng hòa Mozambique',1,1),(147,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MM','Mi-an-ma','Mi-an-ma',1,1),(148,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NA','Cộng hòa Namibia','Cộng hòa Namibia',1,1),(149,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NR','Cộng hòa Nauru','Cộng hòa Nauru',1,1),(150,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NP','Nê-pan','Nê-pan',1,1),(151,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NL','Hà Lan','Hà Lan',1,1),(152,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AN','Antille thuộc Hà Lan','Antille thuộc Hà Lan',1,1),(153,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NC','Kanaky và Le caillou','Kanaky và Le caillou',1,1),(154,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NZ','Niu Di-lân','Niu Di-lân',1,1),(155,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NI','Nicaragua','Nicaragua',1,1),(156,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NE','Cộng hoà Niger','Cộng hoà Niger',1,1),(157,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NG','Cộng hòa Liên bang Nigeria','Cộng hòa Liên bang Nigeria',1,1),(158,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NU','Niue','Niue',1,1),(159,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NF','Đảo Norfolk','Đảo Norfolk',1,1),(160,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MP','Quần đảo Bắc Mariana','Quần đảo Bắc Mariana',1,1),(161,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','NO','Na Uy','Na Uy',1,1),(162,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','OM','Ô-man','Ô-man',1,1),(163,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PK','Pa-ki-xtan','Pa-ki-xtan',1,1),(164,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PW','Cộng hòa Palau','Cộng hòa Palau',1,1),(165,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PS','Chính quyền Quốc gia Palestine','Chính quyền Quốc gia Palestine',1,1),(166,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PA','Cộng hòa Panama','Cộng hòa Panama',1,1),(167,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PG','Pa-pu-a Niu Ghi-nê','Pa-pu-a Niu Ghi-nê',1,1),(168,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PY','Cộng hòa Paraguay','Cộng hòa Paraguay',1,1),(169,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PE','Cộng hòa Peru','Cộng hòa Peru',1,1),(170,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PH','Philippines','Philippines',1,1),(171,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PN','Quần đảo Pitcairn','Quần đảo Pitcairn',1,1),(172,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PL','Ba Lan','Ba Lan',1,1),(173,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PT','Bồ Đào Nha','Bồ Đào Nha',1,1),(174,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PR','Pu-éc-tô Ri-cô','Pu-éc-tô Ri-cô',1,1),(175,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','QA','Ca-ta','Ca-ta',1,1),(176,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','RE','Đảo Réunion','Đảo Réunion',1,1),(177,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','RO','Rumani','Rumani',1,1),(178,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','RU','Nga','Nga',1,1),(179,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','RW','Cộng hòa Ru-an-đa','Cộng hòa Ru-an-đa',1,1),(180,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SH','Xanh hê-li-na','Xanh hê-li-na',1,1),(181,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KN','Liên bang Saint Kitts và Nevis ','Liên bang Saint Kitts và Nevis ',1,1),(182,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LC','Saint Lucia','Saint Lucia',1,1),(183,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PM','Saint-Pierre và Miquelon','Saint-Pierre và Miquelon',1,1),(184,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','VC','Saint Vincent và Grenadines','Saint Vincent và Grenadines',1,1),(185,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','WS','Nhà nước Độc lập Samoa','Nhà nước Độc lập Samoa',1,1),(186,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SM','Cộng hòa Đại bình yên San Marino','Cộng hòa Đại bình yên San Marino',1,1),(187,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','ST','Cộng hòa Dân chủ São Tomé và Príncipe','Cộng hòa Dân chủ São Tomé và Príncipe',1,1),(188,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SA','Ả-rập Xê-út','Ả-rập Xê-út',1,1),(189,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SN','Cộng hoà Sénégal','Cộng hoà Sénégal',1,1),(190,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CS','Serbia và Montenegro','Serbia và Montenegro',1,1),(191,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SC','Xây-sen','Xây-sen',1,1),(192,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SL','Xi-ê-ra Lê-ôn','Xi-ê-ra Lê-ôn',1,1),(193,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SG','Singapore ','Singapore ',1,1),(194,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SK','Cộng hoà Slovak','Cộng hoà Slovak',1,1),(195,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SI','Cộng hòa Slovenia','Cộng hòa Slovenia',1,1),(196,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SB','Quần đảo Solomon','Quần đảo Solomon',1,1),(197,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SO','Cộng hoà Liên bang Somalia','Cộng hoà Liên bang Somalia',1,1),(198,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','ZA','Cộng hòa Nam Phi','Cộng hòa Nam Phi',1,1),(199,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GS','Nam Georgia và Quần đảo Nam Sandwich','Nam Georgia và Quần đảo Nam Sandwich',1,1),(200,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','ES','Tây Ban Nha','Tây Ban Nha',1,1),(201,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','LK','Sri Lanka','Sri Lanka',1,1),(202,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SD','Xu-đăng','Xu-đăng',1,1),(203,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SR','Xu-ri-nam','Xu-ri-nam',1,1),(204,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SJ','Svalbard và Jan Mayen','Svalbard và Jan Mayen',1,1),(205,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SZ','Xoa-di-len','Xoa-di-len',1,1),(206,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SE','Thụy Điển','Thụy Điển',1,1),(207,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CH','Thụy Sĩ','Thụy Sĩ',1,1),(208,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SY','Syria','Syria',1,1),(209,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TW','Trung quốc (Đài Loan)','Trung quốc (Đài Loan)',1,1),(210,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TJ','Ta-gi-ki-xtan','Ta-gi-ki-xtan',1,1),(211,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TZ','Tanzania','Tanzania',1,1),(212,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TH','Thái Lan','Thái Lan',1,1),(213,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TL','Đông Ti-mo','Đông Ti-mo',1,1),(214,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TG','Cộng hòa Togo','Cộng hòa Togo',1,1),(215,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TK','Tokelau','Tokelau',1,1),(216,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TO','Tonga','Tonga',1,1),(217,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TT','Trinidad và Tobago','Trinidad và Tobago',1,1),(218,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TN','Tunisia','Tunisia',1,1),(219,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TR','Turkey','Turkey',1,1),(220,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TM','Tuốc-mê-ni-xtan','Tuốc-mê-ni-xtan',1,1),(221,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TC','Quần đảo Turks và Caicos','Quần đảo Turks và Caicos',1,1),(222,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TV','Tuvalu','Tuvalu',1,1),(223,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','UG','Cộng hòa Uganda','Cộng hòa Uganda',1,1),(224,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','UA','Ukraina','Ukraina',1,1),(225,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AE','Các Tiểu Vương quốc Ả Rập Thống nhất','Các Tiểu Vương quốc Ả Rập Thống nhất',1,1),(226,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GB','Vương quốc Liên hiệp Anh và Bắc Ireland','Vương quốc Liên hiệp Anh và Bắc Ireland',1,1),(227,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','US','Hoa Kỳ','Hoa Kỳ',1,1),(228,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','UM','Các tiểu đảo xa của Hoa Kỳ','Các tiểu đảo xa của Hoa Kỳ',1,1),(229,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','UY','Uruguay','Uruguay',1,1),(230,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','UZ','U-dơ-bê-ki-xtan','U-dơ-bê-ki-xtan',1,1),(231,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','VU','Cộng hòa Vanuatu','Cộng hòa Vanuatu',1,1),(233,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','VE','Cộng hòa Bolivar Venezuela','Cộng hòa Bolivar Venezuela',1,1),(234,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AF','Cộng hòa Hồi giáo Afghanistan','Cộng hòa Hồi giáo Afghanistan',1,1),(235,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','VG','Quần đảo Virgin thuộc Anh','Quần đảo Virgin thuộc Anh',1,1),(236,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','VI','Quần đảo Virgin thuộc Mỹ','Quần đảo Virgin thuộc Mỹ',1,1),(237,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','WF','Wallis và Futuna','Wallis và Futuna',1,1),(238,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','EH','Tây Sahara','Tây Sahara',1,1),(239,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','YE','Y-ê-men','Y-ê-men',1,1),(240,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','ZM','Zambia ','Zambia ',1,1),(241,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','ZW','Cộng hòa Zimbabwe','Cộng hòa Zimbabwe',1,1),(242,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BIH','Bosna và Hercegovina','Bosna và Hercegovina',1,1),(243,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CUW','Curaçao','Curaçao',1,1),(244,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GGY','Địa hạt Guernsey','Địa hạt Guernsey',1,1),(245,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','IMN','Đảo Man','Đảo Man',1,1),(246,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','JEY','Jersey','Jersey',1,1),(247,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MNE','Cộng hòa Montenegro','Cộng hòa Montenegro',1,1),(248,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BLM','Saint-Barthélemy','Saint-Barthélemy',1,1),(249,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','MAF','Saint Martin (French part)','Saint Martin (French part)',1,1),(250,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SXM','Sint Maarten (Dutch part)','Sint Maarten (Dutch part)',1,1),(251,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SSD','South Sudan','South Sudan',1,1),(1,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','VIE','Việt Nam','Việt Nam',1,1),(2,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AX','And Islands','And Islands',1,1),(3,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AL','An-ba-ni','An-ba-ni',1,1),(4,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','DZ','An-giê-ri','An-giê-ri',1,1),(5,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AS','Samoa thuộc Mỹ','Samoa thuộc Mỹ',1,1),(6,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AD','An-đô-ra','An-đô-ra',1,1),(7,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AO','Ăng-gô-la','Ăng-gô-la',1,1),(8,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AI','Anguilla','Anguilla',1,1),(9,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AQ','Nam cực','Nam cực',1,1),(10,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AG','An-ti-goa và Bác-bu-đa','An-ti-goa và Bác-bu-đa',1,1),(11,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AR','Ác-hen-ti-na','Ác-hen-ti-na',1,1),(12,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AM','Ác-mê-ni-a','Ác-mê-ni-a',1,1),(13,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AW','Aruba','Aruba',1,1),(14,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AU','Úc','Úc',1,1),(15,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AT','Áo','Áo',1,1),(16,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','AZ','A-déc-bai-gian','A-déc-bai-gian',1,1),(17,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BS','Ba-ha-mát','Ba-ha-mát',1,1),(18,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BH','Vương quốc Ba-ranh','Vương quốc Ba-ranh',1,1),(19,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BD','Băng-la-đét','Băng-la-đét',1,1),(20,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BB','Bác-ba-đốt','Bác-ba-đốt',1,1),(21,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BY','Bê-la-rút','Bê-la-rút',1,1),(22,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BE','Bỉ','Bỉ',1,1),(23,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BZ','Bê-li-xê','Bê-li-xê',1,1),(24,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BJ','Bê-nanh','Bê-nanh',1,1),(25,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BM','Quần đảo Bermuda','Quần đảo Bermuda',1,1),(26,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BT','Bu-tan','Bu-tan',1,1),(27,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BO','Bô-li-vi-a','Bô-li-vi-a',1,1),(28,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BA','Bosnia và herzegovina','Bosnia và herzegovina',1,1),(29,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BW','Bốt-xoa-na','Bốt-xoa-na',1,1),(30,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BV','Đảo Bouvet','Đảo Bouvet',1,1),(31,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BR','Bra-xin','Bra-xin',1,1),(32,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','IO','Lãnh thổ Ấn Độ Dương','Lãnh thổ Ấn Độ Dương',1,1),(33,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BN','Nhà nước Brunei Darussalam','Nhà nước Brunei Darussalam',1,1),(34,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BG','Bun-ga-ri','Bun-ga-ri',1,1),(35,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BF','Buốc-ki-na Pha-xô','Buốc-ki-na Pha-xô',1,1),(36,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','BI','Cộng hòa Bu-run-đi','Cộng hòa Bu-run-đi',1,1),(37,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KH','Campuchia','Campuchia',1,1),(38,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CM','Cộng hòa Cameroon','Cộng hòa Cameroon',1,1),(39,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CA','Ca-na-đa','Ca-na-đa',1,1),(40,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CV','Cáp Ve','Cáp Ve',1,1),(41,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KY','Quần đảo Cayman','Quần đảo Cayman',1,1),(42,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CF','Cộng hòa Trung Phi','Cộng hòa Trung Phi',1,1),(43,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TD','Sát','Sát',1,1),(44,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CL','Chi-lê','Chi-lê',1,1),(45,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CN','Trung Quốc','Trung Quốc',1,1),(46,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CX','Đảo Christmas','Đảo Christmas',1,1),(47,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CC','Tiểu bang và vùng lãnh thổ Úc','Tiểu bang và vùng lãnh thổ Úc',1,1),(48,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CO','Cộng hòa Cô-lôm-bi-a','Cộng hòa Cô-lôm-bi-a',1,1),(49,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','KM','Cô-mo','Cô-mo',1,1),(50,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CG','Công-gô','Công-gô',1,1),(51,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CD','Cộng hòa Dân chủ Công-gô','Cộng hòa Dân chủ Công-gô',1,1),(52,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CK','Quần đảo Cook','Quần đảo Cook',1,1),(53,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CR','Cộng hoà Costa Rica','Cộng hoà Costa Rica',1,1),(54,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CI','Bờ Biển Ngà','Bờ Biển Ngà',1,1),(55,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','HR','Crô-a-ti-a','Crô-a-ti-a',1,1),(56,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CU','Cu Ba','Cu Ba',1,1),(57,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CY','Cộng hòa Síp','Cộng hòa Síp',1,1),(58,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','CZ','Cộng hòa Séc','Cộng hòa Séc',1,1),(59,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','DK','Đan Mạch','Đan Mạch',1,1),(60,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','DJ','Ả Rập','Ả Rập',1,1),(61,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','DM','Thịnh vượng chung Dominica','Thịnh vượng chung Dominica',1,1),(62,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','DO','Cộng hòa Đô-mi-ni-ca-na','Cộng hòa Đô-mi-ni-ca-na',1,1),(63,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','EC','Cộng hòa Ê-cu-a-đo','Cộng hòa Ê-cu-a-đo',1,1),(64,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','EG','Ai Cập','Ai Cập',1,1),(65,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','SV','Cộng hòa En Xan-va-đo','Cộng hòa En Xan-va-đo',1,1),(66,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GQ','Ghi-nê Xích Đạo','Ghi-nê Xích Đạo',1,1),(67,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','ER','Ê-ri-tơ-rê-a','Ê-ri-tơ-rê-a',1,1),(68,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','EE','E-xtô-ni-a','E-xtô-ni-a',1,1),(69,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','ET','Ê-ti-ô-pi-a','Ê-ti-ô-pi-a',1,1),(70,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','FK','Quần đảo Falkland','Quần đảo Falkland',1,1),(71,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','FO','Quần đảo Faroe','Quần đảo Faroe',1,1),(72,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','FJ','Cộng hòa Quần đảo Phi-gi','Cộng hòa Quần đảo Phi-gi',1,1),(73,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','FI','Phần Lan','Phần Lan',1,1),(74,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','FR','Pháp','Pháp',1,1),(75,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GF','Guyane thuộc Pháp','Guyane thuộc Pháp',1,1),(76,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','PF','Polynesia thuộc Pháp','Polynesia thuộc Pháp',1,1),(77,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','TF','Vùng đất phía nam thuộc Pháp','Vùng đất phía nam thuộc Pháp',1,1),(78,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GA','Cộng hòa Ga-bông','Cộng hòa Ga-bông',1,1),(79,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GM','Cộng hòa Găm-bi-a','Cộng hòa Găm-bi-a',1,1),(80,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GE','Georgia, Hoa Kỳ','Georgia, Hoa Kỳ',1,1),(81,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','DE','Đức','Đức',1,1),(82,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GH','Ga-na','Ga-na',1,1),(83,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GI','Gibraltar','Gibraltar',1,1),(84,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GR','Hy Lạp','Hy Lạp',1,1),(85,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GL','Greenland','Greenland',1,1),(86,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GD','Grê-na-đa','Grê-na-đa',1,1),(87,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GP','Goa-đê-lốp','Goa-đê-lốp',1,1),(88,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GU','Lãnh thổ Guam','Lãnh thổ Guam',1,1),(89,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GT','Cộng hoà Guatemala','Cộng hoà Guatemala',1,1),(90,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GN','Cộng hòa Ghi-nê','Cộng hòa Ghi-nê',1,1),(91,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GW','Ghi-nê Bít-xao','Ghi-nê Bít-xao',1,1),(92,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','GY','Guy-a-na','Guy-a-na',1,1),(93,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','HT','Cộng hòa Ha-i-ti','Cộng hòa Ha-i-ti',1,1),(94,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','HM','Đảo Heard và quần đảo McDonald','Đảo Heard và quần đảo McDonald',1,1),(95,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','VA','Thành Quốc Vatican','Thành Quốc Vatican',1,1),(96,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','HN','Cộng hoà Honduras','Cộng hoà Honduras',1,1),(97,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','HK','Hồng Kông','Hồng Kông',1,1),(98,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','HU','Hung-ga-ri','Hung-ga-ri',1,1),(99,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','IS','Ai-xơ-len','Ai-xơ-len',1,1),(100,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','IN','Ấn Độ','Ấn Độ',1,1),(101,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','ID','In-đô-nê-xi-a','In-đô-nê-xi-a',1,1),(102,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','IR','Iran','Iran',1,1),(103,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','IQ','Iraq','Iraq',1,1),(104,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','IE','Ai-len','Ai-len',1,1),(105,'\0','2017-04-23 15:54:07','2017-04-23 15:54:07','IL','Israel','Israel',1,1);
/*!40000 ALTER TABLE `quoctich` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sotiepcongdan`
--

DROP TABLE IF EXISTS `sotiepcongdan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sotiepcongdan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `diaDiemGapLanhDao` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ghiChuXuLy` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `hoanThanhTCDLanhDao` bit(1) NOT NULL,
  `hoanThanhTCDThuongXuyen` bit(1) NOT NULL,
  `huongGiaiQuyetTCDLanhDao` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `huongXuLy` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `ketQuaGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `loaiTiepDan` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `ngayBaoCaoKetQua` datetime DEFAULT NULL,
  `ngayGuiKetQua` datetime DEFAULT NULL,
  `ngayHenGapLanhDao` datetime DEFAULT NULL,
  `ngayTiepDan` datetime NOT NULL,
  `noiDungBaoCaoKetQuaKiemTra` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `noiDungBoSung` longtext COLLATE utf8_vietnamese_ci,
  `noiDungTiepCongDan` longtext COLLATE utf8_vietnamese_ci,
  `soThuTuLuotTiep` int(11) NOT NULL,
  `thoiHan` datetime DEFAULT NULL,
  `trangThaiKetQua` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `trinhTrangXuLyTCDLanhDao` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `yKienXuLy` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `canBoTiepDan_id` bigint(20) NOT NULL,
  `don_id` bigint(20) NOT NULL,
  `donViChuTri_id` bigint(20) DEFAULT NULL,
  `donViTiepDan_id` bigint(20) NOT NULL,
  `phongBanGiaiQuyet_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbo31wp05ykmu54gqqps7yykxs` (`nguoiSua_id`),
  KEY `FK2r3f13m3a8ea034sb5uq54td` (`nguoiTao_id`),
  KEY `FKpoqd3i2h5lxtvo7au4oss8s51` (`canBoTiepDan_id`),
  KEY `FK3vr19x07drifxy8dfdwynpwvx` (`don_id`),
  KEY `FK1fgxsmec6nwo5c7rux40pogp8` (`donViChuTri_id`),
  KEY `FK6grbn4yn0d8g5ebg6jhbsew1m` (`donViTiepDan_id`),
  KEY `FKk0e4yuj18g9sn7okgv6yncp7h` (`phongBanGiaiQuyet_id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sotiepcongdan`
--

LOCK TABLES `sotiepcongdan` WRITE;
/*!40000 ALTER TABLE `sotiepcongdan` DISABLE KEYS */;
INSERT INTO `sotiepcongdan` VALUES (35,'\0','2017-06-13 18:05:50','2017-05-17 09:45:37','','','\0','\0',NULL,'TU_CHOI','','THUONG_XUYEN',NULL,NULL,NULL,'2017-05-17 09:39:35',NULL,' ','Chưa có thông tin hồ sơ tài liệu bằng chứng',1,NULL,'',NULL,'',3,1,3,18,NULL,90,NULL),(36,'\0','2017-06-13 18:05:07','2017-05-17 10:05:05','','','\0','\0',NULL,'BO_SUNG_THONG_TIN','','THUONG_XUYEN',NULL,NULL,NULL,'2017-05-17 09:48:57',NULL,' ','Bổ sung thông tin đơn thư',1,NULL,'',NULL,'',3,1,3,19,NULL,90,NULL),(37,'\0','2017-06-13 17:57:09','2017-05-17 10:14:19','','','\0','\0',NULL,'TIEP_NHAN_DON','','THUONG_XUYEN',NULL,NULL,NULL,'2017-05-17 10:06:27',NULL,' ','Tiếp nhận đơn này.',1,NULL,'',NULL,'',3,1,3,20,NULL,90,NULL),(38,'\0','2017-06-13 17:56:52','2017-05-17 10:40:57','','','\0','\0',NULL,'TRA_DON_VA_HUONG_DAN','','THUONG_XUYEN',NULL,NULL,NULL,'2017-05-17 10:37:16',NULL,' ','Đến cơ quan đúng thẩm quyền để trình đơn.\nSở Tài Nguyên Môi Trường',1,NULL,'',NULL,'',3,1,3,21,NULL,90,NULL),(39,'\0','2017-06-13 17:55:55','2017-05-17 11:13:00','','','\0','\0',NULL,'YEU_CAU_GAP_LANH_DAO','','THUONG_XUYEN',NULL,NULL,NULL,'2017-05-17 11:06:40',NULL,' ',' ',1,NULL,'',NULL,'',3,1,3,22,NULL,90,NULL),(40,'\0','2017-06-13 17:55:09','2017-05-17 11:23:07','','','\0','\0',NULL,'YEU_CAU_GAP_LANH_DAO','','THUONG_XUYEN',NULL,NULL,NULL,'2017-05-17 11:14:02',NULL,' ',' ',1,NULL,'',NULL,'',3,1,3,23,NULL,90,NULL),(41,'\0','2017-06-13 17:54:12','2017-05-17 11:36:30','','','\0','\0',NULL,'YEU_CAU_GAP_LANH_DAO','','THUONG_XUYEN',NULL,NULL,NULL,'2017-05-17 11:23:16',NULL,' ',' ',1,NULL,'',NULL,'',3,1,3,24,NULL,90,NULL),(42,'\0','2017-06-13 18:06:26','2017-05-17 12:34:41','','','\0','\0','GIAI_QUYET_NGAY','KHOI_TAO',' ','DINH_KY',NULL,NULL,NULL,'2017-05-17 05:33:58',NULL,' ',' ',0,NULL,'',NULL,'',3,1,11,22,NULL,2,NULL),(43,'\0','2017-06-13 18:06:12','2017-05-17 12:34:41','','','\0','\0','CHO_GIAI_QUYET','KHOI_TAO',' ','DINH_KY',NULL,NULL,NULL,'2017-05-17 05:33:58',NULL,' ',' ',0,NULL,'',NULL,'',3,1,11,23,86,2,NULL),(44,'\0','2017-06-13 18:07:45','2017-05-17 12:40:20','','','\0','\0','GIAI_QUYET_NGAY','KHOI_TAO','','DOT_XUAT',NULL,NULL,NULL,'2017-05-17 12:37:12',NULL,' ',' ',0,NULL,'',NULL,'',3,1,9,25,NULL,2,NULL),(45,'\0','2017-06-13 18:07:32','2017-05-17 12:48:49','','','\0','\0','GIAI_QUYET_NGAY','KHOI_TAO','','DOT_XUAT',NULL,NULL,NULL,'2017-05-17 12:40:53',NULL,' ',' ',0,NULL,'',NULL,'',3,1,9,26,NULL,2,NULL),(46,'\0','2017-06-13 18:07:14','2017-05-17 13:01:05','','','\0','\0','GIAI_QUYET_NGAY','KHOI_TAO','','DOT_XUAT',NULL,NULL,NULL,'2017-05-17 12:57:33',NULL,' ',' ',0,NULL,'',NULL,'',3,1,10,27,NULL,2,NULL),(47,'\0','2017-06-13 18:06:56','2017-05-17 14:03:24','','','\0','\0','CHO_GIAI_QUYET','KHOI_TAO','','DOT_XUAT',NULL,NULL,NULL,'2017-05-17 13:59:59',NULL,' ',' ',0,NULL,'',NULL,'',3,1,10,28,5,2,NULL);
/*!40000 ALTER TABLE `sotiepcongdan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sotiepcongdan_has_donviphoihop`
--

DROP TABLE IF EXISTS `sotiepcongdan_has_donviphoihop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sotiepcongdan_has_donviphoihop` (
  `soTiepCongDan_id` bigint(20) NOT NULL,
  `coQuanQuanLy_id` bigint(20) NOT NULL,
  KEY `FKgdg9nrv2ekd97wwgpeernsdcu` (`coQuanQuanLy_id`),
  KEY `FK3q6ie589rhosaj8by8f0ca7wn` (`soTiepCongDan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sotiepcongdan_has_donviphoihop`
--

LOCK TABLES `sotiepcongdan_has_donviphoihop` WRITE;
/*!40000 ALTER TABLE `sotiepcongdan_has_donviphoihop` DISABLE KEYS */;
/*!40000 ALTER TABLE `sotiepcongdan_has_donviphoihop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tailieubangchung`
--

DROP TABLE IF EXISTS `tailieubangchung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tailieubangchung` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `duongDan` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soTrang` int(11) NOT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `tenFile` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `tinhTrangTaiLieu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `don_id` bigint(20) NOT NULL,
  `loaiTaiLieu_id` bigint(20) DEFAULT NULL,
  `soTiepCongDan_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKn55t7kgdw0fo299vsa2y7mwwn` (`nguoiSua_id`),
  KEY `FK6v9f6okh002ajyv65ckxhlnh2` (`nguoiTao_id`),
  KEY `FKm7lvmkr4t8q5e3i2ybcxhakxr` (`don_id`),
  KEY `FKtqbmjxy42x1t9ks4dp67h74m5` (`loaiTaiLieu_id`),
  KEY `FKr434cjl5l7ievuaxfltn7thm8` (`soTiepCongDan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tailieubangchung`
--

LOCK TABLES `tailieubangchung` WRITE;
/*!40000 ALTER TABLE `tailieubangchung` DISABLE KEYS */;
/*!40000 ALTER TABLE `tailieubangchung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tailieudinhkemdinhchi`
--

DROP TABLE IF EXISTS `tailieudinhkemdinhchi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tailieudinhkemdinhchi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `duongDan` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `tenFile` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `don_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbxas19mar2dk163dujssve1te` (`nguoiSua_id`),
  KEY `FKa4352w1u7hn8veupofrhlv0bp` (`nguoiTao_id`),
  KEY `FKebmwuaxcis8i4uhro9o6ehasa` (`don_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tailieudinhkemdinhchi`
--

LOCK TABLES `tailieudinhkemdinhchi` WRITE;
/*!40000 ALTER TABLE `tailieudinhkemdinhchi` DISABLE KEYS */;
/*!40000 ALTER TABLE `tailieudinhkemdinhchi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tailieuvanthu`
--

DROP TABLE IF EXISTS `tailieuvanthu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tailieuvanthu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `buocGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `duongDan` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `loaiQuyTrinh` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `loaiTepDinhKem` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `ngayQuyetDinh` datetime DEFAULT NULL,
  `required` bit(1) NOT NULL,
  `soQuyetDinh` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `tenFile` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `don_id` bigint(20) NOT NULL,
  `soTiepCongDan_id` bigint(20) DEFAULT NULL,
  `typeRequired` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbeblfdalvwob08ct7d667ia0v` (`nguoiSua_id`),
  KEY `FKvbwlu7jvghf673lonj7i5as7` (`nguoiTao_id`),
  KEY `FK9avt6pu1oim13y02mqxc8icm5` (`don_id`),
  KEY `FKknbyx9548nh4feci6uov61ecv` (`soTiepCongDan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tailieuvanthu`
--

LOCK TABLES `tailieuvanthu` WRITE;
/*!40000 ALTER TABLE `tailieuvanthu` DISABLE KEYS */;
/*!40000 ALTER TABLE `tailieuvanthu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tepdinhkem`
--

DROP TABLE IF EXISTS `tepdinhkem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tepdinhkem` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `loaiFileDinhKem` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `tenFile` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `urlFile` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `don_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK29d0ko5vcwhjqweurgeg2d8mr` (`nguoiSua_id`),
  KEY `FK7kn5yxjfbggt199r3kdg7wj7t` (`nguoiTao_id`),
  KEY `FKlj2wdxcxt7dgc6eryjrd3qk0l` (`don_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tepdinhkem`
--

LOCK TABLES `tepdinhkem` WRITE;
/*!40000 ALTER TABLE `tepdinhkem` DISABLE KEYS */;
/*!40000 ALTER TABLE `tepdinhkem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thamquyengiaiquyet`
--

DROP TABLE IF EXISTS `thamquyengiaiquyet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thamquyengiaiquyet` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soThuTu` int(11) NOT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkr8yg0qgmaabbgp2ecdqnnxvt` (`nguoiSua_id`),
  KEY `FK87j0pf567gb3x08ob6bl70m0k` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thamquyengiaiquyet`
--

LOCK TABLES `thamquyengiaiquyet` WRITE;
/*!40000 ALTER TABLE `thamquyengiaiquyet` DISABLE KEYS */;
INSERT INTO `thamquyengiaiquyet` VALUES (1,'\0','2017-04-27 09:36:37','2017-04-27 09:36:37','Hành chính',1,'Hành chính',1,1),(2,'\0','2017-04-27 09:36:43','2017-04-27 09:36:43','Tư pháp',2,'Tư pháp',1,1),(3,'\0','2017-05-03 14:25:00','2017-05-03 14:25:00','Cơ quan Đảng',3,'Cơ quan Đảng',1,1),(4,'\0','2017-05-03 14:25:52','2017-05-03 14:25:52','Cơ quan dân cử',4,'Cơ quan dân cử',1,1),(5,'\0','2017-05-03 15:45:04','2017-05-03 14:29:18','Đơn vị sự nghiệp công lập',5,'Đơn vị sự nghiệp công lập',1,1),(6,'\0','2017-05-03 15:37:56','2017-05-03 14:31:54','Doanh nghiệp nhà nước',6,'Doanh nghiệp nhà nước',1,1),(7,'\0','2017-05-24 16:08:50','2017-05-03 15:05:07','Khác',7,'Khác',1,1);
/*!40000 ALTER TABLE `thamquyengiaiquyet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thamso`
--

DROP TABLE IF EXISTS `thamso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thamso` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `giaTri` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKh7tmt45f1ik590qqcwg0v4w1s` (`nguoiSua_id`),
  KEY `FKlo4ke6t4f9ofyii0gr2g1sl87` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thamso`
--

LOCK TABLES `thamso` WRITE;
/*!40000 ALTER TABLE `thamso` DISABLE KEYS */;
INSERT INTO `thamso` VALUES (1,'\0','2017-04-23 11:09:41','2017-04-23 11:09:42','1','CDVHC_TINH','CDVHC_TINH',1,1),(2,'\0','2017-05-03 15:27:16','2017-04-23 11:09:42','4','CDVHC_THANH_PHO_TRUC_THUOC_TW','CDVHC_THANH_PHO_TRUC_THUOC_TW',1,1),(3,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','9','CDVHC_THANH_PHO-TRUC_THUOC_TINH','CDVHC_THANH_PHO-TRUC_THUOC_TINH',1,1),(4,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','5','CDVHC_QUAN','CDVHC_QUAN',1,1),(5,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','2','CDVHC_HUYEN','CDVHC_HUYEN',1,1),(6,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','6','CDVHC_PHUONG','CDVHC_PHUONG',1,1),(7,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','3','CDVHC_XA','CDVHC_XA',1,1),(8,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','7','CDVHC_THI_TRAN','CDVHC_THI_TRAN',1,1),(9,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','8','CDVHC_THI_XA','CDVHC_THI_XA',1,1),(10,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','5','CCQQL_SO_BAN_NGANH','CCQQL_SO_BAN_NGANH',1,1),(11,'\0','2017-05-03 15:29:44','2017-04-23 11:09:42','2','LCCQQL_BO_CONG_AN','LCCQQL_BO_CONG_AN',1,1),(12,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','6','CCQQL_PHONG_BAN','CCQQL_PHONG_BAN',1,1),(13,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','1','CQQL_UBNDTP_DA_NANG','CQQL_UBNDTP_DA_NANG',1,1),(14,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','9','DVHC_TP_DA_NANG','DVHC_TP_DA_NANG',1,1),(15,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','1','CCQQL_CAP_CHINH_PHU','CCQQL_CAP_CHINH_PHU',1,1),(16,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','2','CCQQL_UBND_TINH_TP','CCQQL_UBND_TINH_TP',1,1),(17,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','3','CCQQL_UBND_QUAN_HUYEN','CCQQL_UBND_QUAN_HUYEN',1,1),(18,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','4','CCQQL_UBND_PHUONG_XA_THI_TRAN','CCQQL_UBND_PHUONG_XA_THI_TRAN',1,1),(19,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','7','CCQQL_CHI_CUC','CCQQL_CHI_CUC',1,1),(20,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','8','CCQQL_CAP_BO_NGANH','CCQQL_CAP_BO_NGANH',1,1),(21,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','9','CCQQL_TONG_CUC','CCQQL_TONG_CUC',1,1),(22,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','10','CCQQL_CUC','CCQQL_CUC',1,1),(23,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','11','CCQQL_VU','CCQQL_VU',1,1),(24,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','12','CCQQL_TRUNG_TAM','CCQQL_TRUNG_TAM',1,1),(25,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','13','CCQQL_CUC_THUOC_TONG_CUC','CCQQL_CUC_THUOC_TONG_CUC',1,1),(26,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','14','CCQQL_VU_THUOC_TONG_VU','CCQQL_VU_THUOC_TONG_VU',1,1),(27,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','15','CCQQL_TRUNG_TAM_THUOC_TONG_CUC','CCQQL_TRUNG_TAM_THUOC_TONG_CUC',1,1),(28,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','16','CCQQL_CO_QUAN_HANH_CHINH_SU_NGHIEP','CCQQL_CO_QUAN_HANH_CHINH_SU_NGHIEP',1,1),(29,'\0','2017-05-03 15:29:44','2017-04-23 11:09:42','1','LCCQQL_SO_Y_TE','LCCQQL_SO_Y_TE',1,1),(30,'\0','2017-04-23 11:09:42','2017-04-23 11:09:42','2','CQQL_THANH_TRA_THANH_PHO','CQQL_THANH_TRA_THANH_PHO',1,1),(31,'\0','2017-07-17 20:42:10','2017-07-17 20:42:10','10','HAN_XU_LY_DON_MAC_DINH','HAN_XU_LY_DON_MAC_DINH',1,1),(32,'\0','2017-07-17 20:42:27','2017-07-17 20:42:27','60','HAN_GIAI_QUYET_DON_MAC_DINH','HAN_GIAI_QUYET_DON_MAC_DINH',1,1);
/*!40000 ALTER TABLE `thamso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thongtingiaiquyetdon`
--

DROP TABLE IF EXISTS `thongtingiaiquyetdon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thongtingiaiquyetdon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `canBoXuLyChiDinh` tinyblob,
  `daRaQuyetDinhGiaiQuyet` bit(1) NOT NULL,
  `daThamTraXacMinhVuViec` bit(1) NOT NULL,
  `daThuLy` bit(1) NOT NULL,
  `datDaThuNhaNuoc` bigint(20) NOT NULL,
  `datDaTraCongDan` bigint(20) NOT NULL,
  `datPhaiThuNhaNuoc` bigint(20) NOT NULL,
  `datPhaiThuNhaNuocQDGQ` bigint(20) NOT NULL,
  `datPhaiTraCongDan` bigint(20) NOT NULL,
  `datPhaiTraCongDanQDGQ` bigint(20) NOT NULL,
  `diaDiemDoiThoai` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `doiThoai` bit(1) NOT NULL,
  `giaHanGiaiQuyet` bit(1) NOT NULL,
  `giaHanTTXM` bit(1) NOT NULL,
  `giaiQuyetLanLai` bit(1) NOT NULL,
  `giaoCoQuanDieuTra` bit(1) NOT NULL,
  `hinhThucTheoDoi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ketLuanGiaiQuyetLai` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ketLuanNoiDungKhieuNai` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ketLuanNoiDungKhieuNaiGiaoTTXM` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ketQuaThucHienTheoDoi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `khoiTo` bit(1) NOT NULL,
  `lapToDoanXacMinh` bit(1) NOT NULL,
  `lyDoGiaHanGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `lyDoGiaHanTTXM` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nextState` tinyblob,
  `ngayBaoCaoKetQuaTTXM` datetime DEFAULT NULL,
  `ngayBatDauGiaiQuyet` datetime DEFAULT NULL,
  `ngayBatDauKTDX` datetime DEFAULT NULL,
  `ngayBatDauTTXM` datetime DEFAULT NULL,
  `ngayHetHanGiaiQuyet` datetime DEFAULT NULL,
  `ngayHetHanKTDX` datetime DEFAULT NULL,
  `ngayHetHanSauKhiGiaHanGiaiQuyet` datetime DEFAULT NULL,
  `ngayHetHanSauKhiGiaHanKTDX` datetime DEFAULT NULL,
  `ngayHetHanSauKhiGiaHanTTXM` datetime DEFAULT NULL,
  `ngayHetHanTTXM` datetime DEFAULT NULL,
  `ngayKetThucGiaiQuyet` datetime DEFAULT NULL,
  `ngayKetThucKTDX` datetime DEFAULT NULL,
  `ngayKetThucTTXM` datetime DEFAULT NULL,
  `ngayRaQuyetDinhGiaHanGiaiQuyet` datetime DEFAULT NULL,
  `ngayRaQuyetDinhGiaHanTTXM` datetime DEFAULT NULL,
  `noiDung` longtext COLLATE utf8_vietnamese_ci,
  `noiDungKetLuanGiaiQuyetLai` longtext COLLATE utf8_vietnamese_ci,
  `phongBanGiaiQuyet` tinyblob,
  `quyetDinhGiaiQuyetKhieuNai` bit(1) NOT NULL,
  `soDoiTuongBiKhoiTo` int(11) NOT NULL,
  `soDoiTuongGiaoCoQuanDieuTra` int(11) NOT NULL,
  `soLanGiaiQuyetLai` int(11) NOT NULL,
  `soNguoiDaBiXuLyHanhChinh` int(11) NOT NULL,
  `soNguoiDuocTraLaiQuyenLoi` int(11) NOT NULL,
  `soQuyetDinhGiaHanGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soQuyetDinhGiaHanTTXM` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soQuyetDinhThanhLapDTXM` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `soVuBiKhoiTo` int(11) NOT NULL,
  `soVuGiaiQuyetKhieuNai` int(11) NOT NULL,
  `soVuGiaoCoQuanDieuTra` int(11) NOT NULL,
  `theoDoiThucHien` bit(1) NOT NULL,
  `thoiGianDoiThoai` datetime DEFAULT NULL,
  `tienDaThuNhaNuoc` bigint(20) NOT NULL,
  `tienDaTraCongDan` bigint(20) NOT NULL,
  `tienPhaiThuNhaNuoc` bigint(20) NOT NULL,
  `tienPhaiThuNhaNuocQDGQ` bigint(20) NOT NULL,
  `tienPhaiTraCongDan` bigint(20) NOT NULL,
  `tienPhaiTraCongDanQDGQ` bigint(20) NOT NULL,
  `tongSoNguoiXuLyHanhChinh` int(11) NOT NULL,
  `yKienCuaDonViGiaoTTXM` longtext COLLATE utf8_vietnamese_ci,
  `yKienGiaiQuyet` longtext COLLATE utf8_vietnamese_ci,
  `yKienXuLyDon` longtext COLLATE utf8_vietnamese_ci,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `canBoGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `canBoThamTraXacMinh_id` bigint(20) DEFAULT NULL,
  `coQuanDieuTra_id` bigint(20) DEFAULT NULL,
  `coQuanTheoDoi_id` bigint(20) DEFAULT NULL,
  `don_id` bigint(20) DEFAULT NULL,
  `donViGiaoThamTraXacMinh_id` bigint(20) DEFAULT NULL,
  `donViThamTraXacMinh_id` bigint(20) DEFAULT NULL,
  `truongDoanTTXM_id` bigint(20) DEFAULT NULL,
  `ngayTraBaoCaoTTXM` datetime DEFAULT NULL,
  `ketQuaXLDGiaiQuyet` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6ioi5scioovck1me73kqtnhdc` (`nguoiSua_id`),
  KEY `FK9gcknd2aw0akopd2x9c9bokpo` (`nguoiTao_id`),
  KEY `FK7ap2qds34v26cl097bt1ax8wv` (`canBoGiaiQuyet_id`),
  KEY `FK34v3wxakkjfykjp75l62e4ce7` (`canBoThamTraXacMinh_id`),
  KEY `FK34oitbq6cy82m3y5b658ki1fa` (`coQuanDieuTra_id`),
  KEY `FKndjdts1hwtoxxy6tdlkwgbmom` (`coQuanTheoDoi_id`),
  KEY `FKtcqhuvp0xjfcaxd3ylky8gohn` (`don_id`),
  KEY `FKsir7eiwct4f7tvqe2vjawrdwu` (`donViGiaoThamTraXacMinh_id`),
  KEY `FKrwjbaheylnvd2yvju1vkjk68` (`donViThamTraXacMinh_id`),
  KEY `FKcwrbc5mvh39v80be1cn6t9uaj` (`truongDoanTTXM_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thongtingiaiquyetdon`
--

LOCK TABLES `thongtingiaiquyetdon` WRITE;
/*!40000 ALTER TABLE `thongtingiaiquyetdon` DISABLE KEYS */;
/*!40000 ALTER TABLE `thongtingiaiquyetdon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `todanpho`
--

DROP TABLE IF EXISTS `todanpho`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `todanpho` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `moTa` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `donViHanhChinh_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKeo4oo81c3t3f9p9vli7wj92c4` (`nguoiSua_id`),
  KEY `FKq98lg4lom4m036wihayx73rva` (`nguoiTao_id`),
  KEY `FKlxe3bui2j0p33kjqfk33aoodg` (`donViHanhChinh_id`)
) ENGINE=MyISAM AUTO_INCREMENT=516 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `todanpho`
--

LOCK TABLES `todanpho` WRITE;
/*!40000 ALTER TABLE `todanpho` DISABLE KEYS */;
INSERT INTO `todanpho` VALUES (1,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,23),(2,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,23),(3,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,25),(4,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,32),(5,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,23),(6,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,23),(7,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,23),(8,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,23),(9,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,23),(10,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,23),(11,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,23),(12,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,23),(13,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,22),(14,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,22),(15,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,22),(49,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,25),(48,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,25),(57,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,26),(19,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,22),(20,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,22),(21,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,22),(22,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,22),(23,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,22),(24,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,22),(25,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,22),(50,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,25),(51,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,25),(52,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,25),(53,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,25),(54,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,25),(55,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,25),(36,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,24),(37,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,24),(38,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,24),(39,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,24),(40,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,24),(41,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,24),(42,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,24),(43,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,24),(44,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,24),(45,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,24),(56,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,25),(58,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,26),(59,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,26),(60,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,26),(61,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,26),(62,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,26),(63,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,26),(64,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,26),(65,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,26),(66,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,26),(67,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,27),(68,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,27),(69,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,27),(70,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,27),(71,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,27),(72,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,27),(73,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,27),(74,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,27),(75,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,27),(76,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,27),(77,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,28),(78,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,28),(79,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,28),(80,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,28),(81,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,28),(82,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,28),(83,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,28),(84,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,28),(85,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,28),(86,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,28),(87,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,29),(88,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,29),(89,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,29),(90,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,29),(91,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,29),(92,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,29),(93,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,29),(94,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,29),(95,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,29),(96,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,29),(97,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,30),(98,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,30),(99,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,30),(100,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,30),(101,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,30),(102,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,30),(103,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,30),(104,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,30),(105,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,30),(106,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,30),(107,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,31),(108,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,31),(109,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,31),(110,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,31),(111,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,31),(112,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,31),(113,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,31),(114,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,31),(115,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,31),(116,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,31),(117,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,32),(118,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,32),(119,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,32),(120,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,32),(121,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,32),(122,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,32),(123,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,32),(124,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,32),(125,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,32),(126,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,33),(127,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,33),(128,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,33),(129,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,33),(130,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,33),(131,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,33),(132,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,33),(133,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,33),(134,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,33),(135,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,33),(136,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,34),(137,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,34),(138,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,34),(139,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,34),(140,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,34),(141,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,34),(142,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,34),(143,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,34),(144,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,34),(145,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,34),(146,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,35),(147,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,35),(148,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,35),(149,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,35),(150,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,35),(151,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,35),(152,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,35),(153,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,35),(154,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,35),(155,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,35),(156,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,36),(157,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,36),(158,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,36),(159,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,36),(160,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,36),(161,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,36),(162,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,36),(163,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,36),(164,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,36),(165,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,36),(166,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,37),(167,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,37),(168,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,37),(169,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,37),(170,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,37),(171,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,37),(172,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,37),(173,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,37),(174,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,37),(175,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,37),(176,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,38),(177,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,38),(178,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,38),(179,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,38),(180,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,38),(181,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,38),(182,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,38),(183,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,38),(184,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,38),(185,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,38),(186,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,39),(187,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,39),(188,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,39),(189,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,39),(190,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,39),(191,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,39),(192,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,39),(193,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,39),(194,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,39),(195,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,39),(196,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,40),(197,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,40),(198,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,40),(199,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,40),(200,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,40),(201,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,40),(202,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,40),(203,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,40),(204,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,40),(205,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,40),(206,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,41),(207,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,41),(208,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,41),(209,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,41),(210,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,41),(211,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,41),(212,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,41),(213,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,41),(214,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,41),(215,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,41),(216,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,42),(217,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,42),(218,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,42),(219,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,42),(220,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,42),(221,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,42),(222,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,42),(223,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,42),(224,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,42),(225,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,42),(226,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,43),(227,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,43),(228,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,43),(229,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,43),(230,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,43),(231,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,43),(232,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,43),(233,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,43),(234,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,43),(235,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,43),(236,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,44),(237,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,44),(238,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,44),(239,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,44),(240,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,44),(241,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,44),(242,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,44),(243,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,44),(244,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,44),(245,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,44),(246,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,45),(247,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,45),(248,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,45),(249,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,45),(250,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,45),(251,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,45),(252,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,45),(253,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,45),(254,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,45),(255,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,45),(256,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,46),(257,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,46),(258,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,46),(259,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,46),(260,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,46),(261,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,46),(262,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,46),(263,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,46),(264,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,46),(265,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,46),(266,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,47),(267,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,47),(268,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,47),(269,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,47),(270,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,47),(271,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,47),(272,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,47),(273,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,47),(274,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,47),(275,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,47),(276,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,48),(277,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,48),(278,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,48),(279,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,48),(280,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,48),(281,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,48),(282,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,48),(283,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,48),(284,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,48),(285,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,48),(286,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,49),(287,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,49),(288,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,49),(289,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,49),(290,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,49),(291,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,49),(292,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,49),(293,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,49),(294,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,49),(295,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,49),(296,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,50),(297,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,50),(298,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,50),(299,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,50),(300,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,50),(301,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,50),(302,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,50),(303,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,50),(304,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,50),(305,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,50),(306,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,51),(307,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,51),(308,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,51),(309,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,51),(310,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,51),(311,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,51),(312,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,51),(313,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,51),(314,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,51),(315,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,51),(316,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,52),(317,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,52),(318,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,52),(319,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,52),(320,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,52),(321,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,52),(322,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,52),(323,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,52),(324,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,52),(325,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,52),(326,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,53),(327,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,53),(328,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,53),(329,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,53),(330,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,53),(331,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,53),(332,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,53),(333,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,53),(334,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,53),(335,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,53),(336,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,54),(337,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,54),(338,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,54),(339,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,54),(340,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,54),(341,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,54),(342,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,54),(343,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,54),(344,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,54),(345,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,54),(346,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,55),(347,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,55),(348,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,55),(349,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,55),(350,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,55),(351,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,55),(352,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,55),(353,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,55),(354,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,55),(355,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,55),(356,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,56),(357,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,56),(358,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,56),(359,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,56),(360,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,56),(361,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,56),(362,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,56),(363,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,56),(364,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,56),(365,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,56),(366,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,57),(367,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,57),(368,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,57),(369,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,57),(370,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,57),(371,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,57),(372,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,57),(373,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,57),(374,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,57),(375,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,57),(376,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,58),(377,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,58),(378,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,58),(379,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,58),(380,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,58),(381,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,58),(382,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,58),(383,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,58),(384,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,58),(385,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,58),(386,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,59),(387,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,59),(388,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,59),(389,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,59),(390,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,59),(391,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,59),(392,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,59),(393,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,59),(394,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,59),(395,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,59),(396,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,60),(397,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,60),(398,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,60),(399,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,60),(400,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,60),(401,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,60),(402,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,60),(403,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,60),(404,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,60),(405,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,60),(406,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,61),(407,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,61),(408,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,61),(409,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,61),(410,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,61),(411,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,61),(412,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,61),(413,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,61),(414,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,61),(415,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,61),(466,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,67),(467,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,67),(468,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,67),(469,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,67),(470,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,67),(471,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,67),(472,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,67),(473,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,67),(474,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,67),(475,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,67),(476,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,68),(477,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,68),(478,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,68),(479,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,68),(480,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,68),(481,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,68),(482,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,68),(483,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,68),(484,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,68),(485,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,68),(486,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,69),(487,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,69),(488,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,69),(489,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,69),(490,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,69),(491,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,69),(492,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,69),(493,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,69),(494,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,69),(495,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,69),(496,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,70),(497,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,70),(498,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,70),(499,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,70),(500,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,70),(501,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,70),(502,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,70),(503,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,70),(504,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,70),(505,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,70),(506,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 01','Tổ 01',1,1,71),(507,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 02','Tổ 02',1,1,71),(508,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 03','Tổ 03',1,1,71),(509,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 04','Tổ 04',1,1,71),(510,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 05','Tổ 05',1,1,71),(511,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 06','Tổ 06',1,1,71),(512,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 07','Tổ 07',1,1,71),(513,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 08','Tổ 08',1,1,71),(514,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 09','Tổ 09',1,1,71),(515,'\0','2017-04-25 09:16:05','2017-04-25 09:16:05','Tổ 10','Tổ 10',1,1,71);
/*!40000 ALTER TABLE `todanpho` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaitro`
--

DROP TABLE IF EXISTS `vaitro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vaitro` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `loaiVaiTro` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3uwscuj1f6gvxme8ifyuwfoga` (`nguoiSua_id`),
  KEY `FKba7mse8kaa7rhx6623lpvkau4` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaitro`
--

LOCK TABLES `vaitro` WRITE;
/*!40000 ALTER TABLE `vaitro` DISABLE KEYS */;
INSERT INTO `vaitro` VALUES (1,'\0','2017-07-08 23:35:32','2017-04-25 15:36:45','LANH_DAO','Lãnh đạo',1,1),(2,'\0','2017-07-03 09:53:10','2017-05-10 14:48:29','TRUONG_PHONG','Trưởng Phòng',1,1),(3,'\0','2017-07-03 09:53:15','2017-05-10 14:48:46','CHUYEN_VIEN','Chuyên viên',1,1),(4,'\0','2017-07-08 23:35:47','2017-05-10 14:48:55','VAN_THU','Chuyên viên nhập liệu',1,1);
/*!40000 ALTER TABLE `vaitro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaitro_quyen`
--

DROP TABLE IF EXISTS `vaitro_quyen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vaitro_quyen` (
  `vaitro_id` bigint(20) NOT NULL,
  `quyens` longtext COLLATE utf8_vietnamese_ci,
  KEY `FKsx7h61ya2vb2sjj0rp32b3p38` (`vaitro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaitro_quyen`
--

LOCK TABLES `vaitro_quyen` WRITE;
/*!40000 ALTER TABLE `vaitro_quyen` DISABLE KEYS */;
INSERT INTO `vaitro_quyen` VALUES (1,'thamquyengiaiquyet:lietke,thamquyengiaiquyet:xem,thamquyengiaiquyet:them,thamquyengiaiquyet:sua,thamquyengiaiquyet:xoa,loaitailieu:lietke,loaitailieu:xem,loaitailieu:them,loaitailieu:sua,loaitailieu:xoa,chucvu:lietke,chucvu:xem,chucvu:them,chucvu:sua,chucvu:xoa,quoctich:lietke,quoctich:xem,quoctich:them,quoctich:sua,quoctich:xoa,capdonvihanhchinh:lietke,capdonvihanhchinh:xem,capdonvihanhchinh:them,capdonvihanhchinh:sua,capdonvihanhchinh:xoa,donvihanhchinh:lietke,donvihanhchinh:xem,donvihanhchinh:them,donvihanhchinh:sua,donvihanhchinh:xoa,loaicoquanquanly:lietke,loaicoquanquanly:xem,loaicoquanquanly:them,loaicoquanquanly:sua,loaicoquanquanly:xoa,capcoquanquanly:lietke,capcoquanquanly:xem,capcoquanquanly:them,capcoquanquanly:sua,capcoquanquanly:xoa,coquanquanly:lietke,coquanquanly:xem,coquanquanly:them,coquanquanly:sua,coquanquanly:xoa,todanpho:lietke,todanpho:xem,todanpho:them,todanpho:sua,todanpho:xoa,dantoc:lietke,dantoc:xem,dantoc:them,dantoc:sua,dantoc:xoa,linhvucdonthu:lietke,linhvucdonthu:xem,linhvucdonthu:them,linhvucdonthu:sua,linhvucdonthu:xoa,congchuc:lietke,congchuc:xem,congchuc:them,congchuc:sua,congchuc:xoa,congdan:lietke,congdan:xem,congdan:them,congdan:sua,congdan:xoa,vaitro:lietke,vaitro:xem,vaitro:them,vaitro:sua,vaitro:xoa,thoihan:lietke,thoihan:xem,thoihan:them,thoihan:sua,thoihan:xoa,thamso:lietke,thamso:xem,thamso:them,thamso:sua,thamso:xoa,sotiepcongdan:lietke,sotiepcongdan:xem,sotiepcongdan:sua,sotiepcongdan:them,sotiepcongdan:xoa,xulydon:lietke,xulydon:xem,xulydon:sua,xulydon:xoa,giaiquyetdon:xem,giaiquyetdon:them,giaiquyetdon:sua,giaiquyetdon:xoa,thanhtra:lietke,thanhtra:xem,thanhtra:them,thanhtra:sua,thanhtra:xoa,tonghopbaocao:lietke,tonghopbaocao:thongke,theodoigiamsat:lietke,theodoigiamsat:thongke,giaiquyetdon:dinhchi,xulydon:dinhchi:rutdon,transition:xoa,transition:sua,transition:them,transition:xem,transition:lietke,process:xoa,process:sua,process:them,process:xem,process:lietke,form:xoa,form:sua,form:them,form:xem,form:lietke,donvihasstate:them,donvihasstate:xem,donvihasstate:lietke,donvihasstate:sua,donvihasstate:xoa,state:xoa,state:them,state:sua,state:xem,state:lietke,xulydon:them'),(2,'xulydon:sua,xulydon:xoa,giaiquyetdon:lietke,giaiquyetdon:xem,giaiquyetdon:sua,giaiquyetdon:xoa,loaitailieu:xem,chucvu:xem,quoctich:xem,capdonvihanhchinh:xem,donvihanhchinh:xem,loaicoquanquanly:xem,capcoquanquanly:xem,coquanquanly:xem,todanpho:xem,dantoc:x,giaiquyetdon:dinhchi,xulydon:dinhchi:rutdon,xulydon:lietke,xulydon:xem,thamso:xem,vaitro:xem,congdan:xem,congchuc:xem,linhvucdonthu:xem,dantoc:xem,thamquyengiaiquyet:xem,sotiepcongdan:xem'),(3,'sotiepcongdan:xem,xulydon:xem,xulydon:sua,xulydon:xoa,giaiquyetdon:lietke,giaiquyetdon:xem,giaiquyetdon:sua,giaiquyetdon:xoa,thamquyengiaiquyet:xem,loaitailieu:xem,chucvu:xem,quoctich:xem,capdonvihanhchinh:xem,donvihanhchinh:xem,loaicoquanquanly:xem,capco,capcoquanquanly:xem,coquanquanly:xem,todanpho:xem,dantoc:xem,linhvucdonthu:xem,congchuc:xem,congdan:xem,vaitro:xem,thamso:xem,sotiepcongdan:lietke,sotiepcongdan:them,sotiepcongdan:sua,sotiepcongdan:xoa,xulydon:lietke,xulydon:dinhchi:rutdon,giaiquyetdon:dinhchi,xulydon:them'),(4,'xulydon:xem,xulydon:sua,xulydon:xoa,giaiquyetdon:xem,giaiquyetdon:sua,giaiquyetdon:xoa,xulydon:lietke,giaiquyetdon:dinhchi,xulydon:dinhchi:rutdon,thamquyengiaiq,thamquyengiaiquyet:xem,loaitailieu:xem,chucvu:xem,quoctich:xem,capdonvihanhchinh:xem,donvihanhchinh:xem,loaicoquanquanly:xem,capcoquanquanly:xem,coquanquanly:xem,todanpho:xem,dantoc:xem,linhvucdonthu:xem,congchuc:xem,congdan:xem,vaitro:xem,thamso:xem,xulydon:them,sotiepcongdan:xem');
/*!40000 ALTER TABLE `vaitro_quyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wf_donvi_has_state`
--

DROP TABLE IF EXISTS `wf_donvi_has_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wf_donvi_has_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `processType` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `soThuTu` int(11) NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `coQuanQuanLy_id` bigint(20) NOT NULL,
  `state_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgfct82l6mkxfs1gusl6wnar14` (`nguoiSua_id`),
  KEY `FKnkcvpj9phqj35q4xg3x3y40tu` (`nguoiTao_id`),
  KEY `FK3qqivwc1sk7rkvn58iuqq7f6p` (`coQuanQuanLy_id`),
  KEY `FKe0luwxjqa1syg49qwrq15nyh4` (`state_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wf_donvi_has_state`
--

LOCK TABLES `wf_donvi_has_state` WRITE;
/*!40000 ALTER TABLE `wf_donvi_has_state` DISABLE KEYS */;
INSERT INTO `wf_donvi_has_state` VALUES (1,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','XU_LY_DON',1,1,1,2,1),(2,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','XU_LY_DON',2,1,1,2,2),(3,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','XU_LY_DON',3,1,1,2,3),(5,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','XU_LY_DON',4,1,1,2,5),(6,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','XU_LY_DON',5,1,1,2,9),(8,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','XU_LY_DON',6,1,1,2,8),(9,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','GIAI_QUYET_DON',1,1,1,2,1),(10,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','GIAI_QUYET_DON',2,1,1,2,5),(12,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','GIAI_QUYET_DON',4,1,1,2,11),(13,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','GIAI_QUYET_DON',3,1,1,2,10),(14,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','GIAI_QUYET_DON',6,1,1,2,8),(15,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','GIAI_QUYET_DON',5,1,1,2,12),(25,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','KIEM_TRA_DE_XUAT',1,1,1,2,1),(17,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','THAM_TRA_XAC_MINH',1,1,1,14,1),(18,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','THAM_TRA_XAC_MINH',2,1,1,14,2),(19,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','THAM_TRA_XAC_MINH',6,1,1,14,15),(20,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','THAM_TRA_XAC_MINH',5,1,1,14,9),(22,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','THAM_TRA_XAC_MINH',4,1,1,14,5),(24,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','THAM_TRA_XAC_MINH',3,1,1,14,3),(26,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','KIEM_TRA_DE_XUAT',2,1,1,2,2),(27,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','KIEM_TRA_DE_XUAT',3,1,1,2,3),(29,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','KIEM_TRA_DE_XUAT',4,1,1,2,5),(31,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','KIEM_TRA_DE_XUAT',5,1,1,2,9),(32,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','KIEM_TRA_DE_XUAT',6,1,1,2,16);
/*!40000 ALTER TABLE `wf_donvi_has_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wf_form`
--

DROP TABLE IF EXISTS `wf_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wf_form` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `processType` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKlm02efkge96lyl5if8n1p6crj` (`nguoiSua_id`),
  KEY `FK5yg708co9s0w6g7hge4f40vjm` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wf_form`
--

LOCK TABLES `wf_form` WRITE;
/*!40000 ALTER TABLE `wf_form` DISABLE KEYS */;
INSERT INTO `wf_form` VALUES (1,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','WordProcessingOperatorAction','XU_LY_DON','Component Chuyên Viên nhập liệu trình lãnh đạo',1,1),(2,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','ManagerAction','XU_LY_DON','Component lãnh đạo giao việc cho trưởng phòng hoặc cán bộ',1,1),(3,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','LeaderAction','XU_LY_DON','Component trưởng phòng giao việc cán bộ',1,1),(4,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','WordProcessingSpecialistAction','XU_LY_DON','Component cán bộ đề xuất hướng xử lý',1,1),(5,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','WordProcessingOperatorLastAction','XU_LY_DON','Component Chuyên Viên nhập liệu chuyển bộ phân giải quyết hoặc lưu hồ sơ',1,1),(6,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','LeaderAction','XU_LY_DON','Component trưởng phòng đề xuất giao việc lại',1,1),(7,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','WordProcessingSpecialistAction','XU_LY_DON','Component cán bộ đề xuất giao việc lại',1,1),(11,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','TruongPhongGiaiQuyetDonAction','GIAI_QUYET_DON','Component Trưởng phòng giải quyết đơn giao việc cán bộ giải quyết đơn',1,1),(12,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','CanBoGiaiQuyetDonAction','GIAI_QUYET_DON','Component Cán bộ giải quyết đơn giải quyết đơn',1,1),(13,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','CanBoNhapLieuGiaiQuyetDonAction','GIAI_QUYET_DON','Component Cán bộ nhập liệu giải quyết đơn chuyển cho đơn vị TTXM',1,1),(14,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','CanBoNhapLieuTTXMAction','THAM_TRA_XAC_MINH','Component Cán bộ nhập liệu TTXM trình đơn lãnh đạo',1,1),(15,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','LanhDaoTTXMAction','THAM_TRA_XAC_MINH','Component Lãnh đạo TTXM giao việc cán bộ hoặc trưởng phòng TTXM',1,1),(16,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','TruongPhongTTXMAction','THAM_TRA_XAC_MINH','Component Trưởng phòng TTXM giao việc cán bộ TTXM',1,1),(17,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','CanBoTTXMAction','THAM_TRA_XAC_MINH','Component Cán bộ TTXM  chuyển về đơn vị giải quyết',1,1),(18,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','CanBoGiaiQuyetDonLapDuThaoAction','GIAI_QUYET_DON','Component Cán bộ giải quyết đơn nhận kết quả TTXM và giải quyết đơn',1,1),(19,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','vanThuKiemTraDeXuat','KIEM_TRA_DE_XUAT','Component Cán bộ nhập liệu trình đơn lãnh đạo',1,1),(20,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','lanhDaoKiemTraDeXuat','KIEM_TRA_DE_XUAT','Component Lãnh đạo giao việc',1,1),(21,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','truongPhongKiemTraDeXuat','KIEM_TRA_DE_XUAT','Component Trưởng phòng giao việc cán bộ',1,1),(22,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','canBoKiemTraDeXuat','KIEM_TRA_DE_XUAT','Component Cán bộ kiểm tra đề xuất',1,1);
/*!40000 ALTER TABLE `wf_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wf_process`
--

DROP TABLE IF EXISTS `wf_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wf_process` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `ghiChu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `owner` bit(1) NOT NULL,
  `processType` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `tenQuyTrinh` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `cha_id` bigint(20) DEFAULT NULL,
  `coQuanQuanLy_id` bigint(20) NOT NULL,
  `vaiTro_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKakdlqf2r15r03vitqn6pgfful` (`nguoiSua_id`),
  KEY `FKq544di50aornaqepvt1ajkrtw` (`nguoiTao_id`),
  KEY `FKfly0pot9pe5j719spr32mmryt` (`cha_id`),
  KEY `FK23i54r4o0gdumh61dodgqjbi` (`coQuanQuanLy_id`),
  KEY `FKjhucndrur3oxxu59brw9hxn25` (`vaiTro_id`)
) ENGINE=MyISAM AUTO_INCREMENT=135 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wf_process`
--

LOCK TABLES `wf_process` WRITE;
/*!40000 ALTER TABLE `wf_process` DISABLE KEYS */;
INSERT INTO `wf_process` VALUES (1,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,NULL,2,4),(2,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,1,2,4),(3,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Lãnh Đạo',1,1,NULL,2,1),(4,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Trưởng Phòng',1,1,NULL,2,2),(5,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên',1,1,NULL,2,3),(6,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Trưởng Phòng',1,1,NULL,2,2),(8,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên Viên',1,1,NULL,2,3),(9,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Lãnh Đạo',1,1,NULL,14,1),(10,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Trưởng Phòng',1,1,NULL,14,2),(11,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên nhập liệu',1,1,NULL,14,4),(12,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên',1,1,NULL,14,3),(13,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên Viên',1,1,NULL,2,3),(14,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên viên nhập liệu',1,1,NULL,2,4),(15,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Trưởng Phòng',1,1,NULL,2,2),(16,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Lãnh Đạo',1,1,NULL,2,1),(17,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Lãnh Đạo',1,1,NULL,4,1),(18,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Lãnh Đạo',1,1,NULL,14,1),(19,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Lãnh Đạo',1,1,NULL,17,1),(20,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Lãnh Đạo',1,1,NULL,20,1),(21,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Lãnh Đạo',1,1,NULL,21,1),(22,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Lãnh Đạo',1,1,NULL,36,1),(23,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Lãnh Đạo',1,1,NULL,42,1),(24,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Trưởng Phòng',1,1,NULL,4,2),(25,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Trưởng Phòng',1,1,NULL,14,2),(26,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Trưởng Phòng',1,1,NULL,17,2),(27,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Trưởng Phòng',1,1,NULL,20,2),(28,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Trưởng Phòng',1,1,NULL,21,2),(39,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên',1,1,NULL,4,3),(40,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên',1,1,NULL,14,3),(41,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên',1,1,NULL,17,3),(42,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên',1,1,NULL,20,3),(43,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên',1,1,NULL,21,3),(46,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,NULL,4,4),(47,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,NULL,14,4),(48,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,NULL,17,4),(49,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,NULL,20,4),(50,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,NULL,21,4),(53,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,1,4,4),(54,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,1,14,4),(55,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,1,17,4),(56,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,1,20,4),(57,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,1,21,4),(59,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Lãnh Đạo',1,1,NULL,42,1),(60,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Lãnh Đạo',1,1,NULL,36,1),(61,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Trưởng Phòng',1,1,NULL,14,2),(62,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Trưởng Phòng',1,1,NULL,4,2),(63,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Trưởng Phòng',1,1,NULL,17,2),(64,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Trưởng Phòng',1,1,NULL,20,2),(65,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Trưởng Phòng',1,1,NULL,21,2),(66,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên Viên',1,1,NULL,14,3),(67,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên Viên',1,1,NULL,4,3),(68,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên Viên',1,1,NULL,17,3),(69,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên Viên',1,1,NULL,20,3),(70,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên Viên',1,1,NULL,21,3),(76,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Lãnh Đạo',1,1,NULL,4,1),(77,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Lãnh Đạo',1,1,NULL,17,1),(78,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Lãnh Đạo',1,1,NULL,20,1),(79,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Lãnh Đạo',1,1,NULL,21,1),(80,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Trưởng Phòng',1,1,NULL,4,2),(81,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Trưởng Phòng',1,1,NULL,17,2),(82,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Trưởng Phòng',1,1,NULL,20,2),(83,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Trưởng Phòng',1,1,NULL,21,2),(84,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên',1,1,NULL,4,3),(85,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên',1,1,NULL,17,3),(86,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên',1,1,NULL,20,3),(87,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên',1,1,NULL,21,3),(88,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên nhập liệu',1,1,NULL,4,4),(89,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên nhập liệu',1,1,NULL,17,4),(90,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên nhập liệu',1,1,NULL,20,4),(91,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','THAM_TRA_XAC_MINH','Thẩm tra xác minh của Chuyên Viên nhập liệu',1,1,NULL,21,4),(92,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyen Viên',1,1,NULL,42,3),(93,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên Viên',1,1,NULL,42,3),(94,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên Viên',1,1,NULL,36,3),(95,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Trưởng Phòng',1,1,NULL,36,2),(96,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Trưởng Phòng',1,1,NULL,42,2),(97,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên viên nhập liệu',1,1,NULL,36,4),(98,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên viên nhập liệu',1,1,NULL,42,4),(99,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyen Viên',1,1,NULL,36,3),(100,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,NULL,42,4),(101,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,NULL,36,4),(102,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Trưởng Phòng',1,1,NULL,42,2),(103,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Trưởng Phòng',1,1,NULL,36,2),(104,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,NULL,1,4),(105,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'','XU_LY_DON','Xử lý đơn của Chuyên Viên nhập liệu',1,1,1,1,4),(106,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Lãnh Đạo',1,1,NULL,1,1),(107,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Trưởng Phòng',1,1,NULL,1,2),(108,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','XU_LY_DON','Xử lý đơn của Chuyên Viên',1,1,NULL,1,3),(109,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Trưởng Phòng',1,1,NULL,1,2),(110,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','GIAI_QUYET_DON','Giải quyết đơn của Chuyên Viên',1,1,NULL,1,3),(111,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên Viên',1,1,NULL,1,3),(112,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên viên nhập liệu',1,1,NULL,1,4),(113,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Trưởng Phòng',1,1,NULL,1,2),(114,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Lãnh Đạo',1,1,NULL,1,1),(115,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Lãnh Đạo',1,1,NULL,4,1),(116,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Lãnh Đạo',1,1,NULL,14,1),(117,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Lãnh Đạo',1,1,NULL,17,1),(118,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Lãnh Đạo',1,1,NULL,36,1),(119,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Lãnh Đạo',1,1,NULL,42,1),(120,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Trưởng Phòng',1,1,NULL,4,2),(121,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Trưởng Phòng',1,1,NULL,14,2),(122,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Trưởng Phòng',1,1,NULL,17,2),(123,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Trưởng Phòng',1,1,NULL,36,2),(124,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Trưởng Phòng',1,1,NULL,42,2),(125,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên Viên',1,1,NULL,4,3),(126,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên Viên',1,1,NULL,14,3),(127,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên Viên',1,1,NULL,17,3),(128,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên Viên',1,1,NULL,36,3),(129,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên Viên',1,1,NULL,42,3),(130,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên viên nhập liệu',1,1,NULL,4,4),(131,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên viên nhập liệu',1,1,NULL,14,4),(132,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên viên nhập liệu',1,1,NULL,17,4),(133,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên viên nhập liệu',1,1,NULL,36,4),(134,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',NULL,'\0','KIEM_TRA_DE_XUAT','Kiểm tra đề xuất của Chuyên viên nhập liệu',1,1,NULL,42,4);
/*!40000 ALTER TABLE `wf_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wf_state`
--

DROP TABLE IF EXISTS `wf_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wf_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `tenVietTat` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK55rccdtd35bei5r9gwghfdrx2` (`nguoiSua_id`),
  KEY `FKijg4n683sup3sxn3q281w3ddn` (`nguoiTao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wf_state`
--

LOCK TABLES `wf_state` WRITE;
/*!40000 ALTER TABLE `wf_state` DISABLE KEYS */;
INSERT INTO `wf_state` VALUES (1,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Bắt đầu','Bắt đầu','BAT_DAU',1,1),(2,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Văn thư Trình lãnh đạo','Trình lãnh đạo','TRINH_LANH_DAO',1,1),(3,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Lãnh đạo giao việc trưởng phòng','Giao việc trưởng phòng','LANH_DAO_GIAO_VIEC_TRUONG_PHONG',1,1),(4,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Trường phòng đề xuất giao việc lại','Đề xuất giao việc lại','TRUONG_PHONG_DE_XUAT_GIAO_VIEC_LAI',1,1),(5,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Trưởng phòng giao việc cán bộ','Giao việc cán bộ','TRUONG_PHONG_GIAO_VIEC_CAN_BO',1,1),(6,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Cán bộ đề xuất giao việc lại','Đề xuất giao việc lại','CAN_BO_DE_XUAT_GIAO_VIEC_LAI',1,1),(7,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Cán bộ đề xuất hướng xử lý','Đề xuất hướng xử lý','CAN_BO_DE_XUAT_HUONG_XU_LY',1,1),(8,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Kết thúc','Tự thẩm tra xác minh','KET_THUC',1,1),(9,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Lãnh đạo giao việc cán bộ','Giao việc cán bộ','LANH_DAO_GIAO_VIEC_CAN_BO',1,1),(10,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Cán bộ chuyển văn thư giao TTXM','Giao đơn vị khác TTXM','CAN_BO_CHUYEN_VAN_THU_GIAO_TTXM',1,1),(11,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Chuyên viên nhập liệu chuyển đơn cho đơn vị TTXM','Chuyển đơn vị TTXM','VAN_THU_CHUYEN_DON_VI_TTXM',1,1),(12,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Cán bộ nhận kết quả TTXM','Nhận kết quả TTXM','CAN_BO_NHAN_KET_QUA_TTXM',1,1),(13,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Cán bộ chuyển Chuyên viên nhập liệu kết quả TTXM','Chuyển văn thư kết quả TTXM','CAN_BO_CHUYEN_VAN_THU_KET_QUA_TTXM',1,1),(14,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Cán bộ giải quyết đơn','Tự thẩm tra xác minh','CAN_BO_GIAI_QUYET_DON',1,1),(15,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Cán bộ chuyển về đơn vị giải quyết','Chuyển về đơn vị giải quyết','CAN_BO_CHUYEN_VE_DON_VI_GIAI_QUYET',1,1),(16,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Cán bộ chuyển kết quả về đơn vị giao','Chuyển về đơn vị giao','CAN_BO_CHUYEN_KET_QUA_DON_VI_GIAO',1,1),(17,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Yêu cầu gặp lãnh đạo','Yêu cầu gặp lãnh đạo','YEU_CAU_GAP_LANH_DAO',1,1),(18,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39','Cán bộ chuyển đơn cho đơn vị TTXM','Giao đơn vị khác TTXM','CAN_BO_CHUYEN_DON_VI_TTXM',1,1);
/*!40000 ALTER TABLE `wf_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wf_transition`
--

DROP TABLE IF EXISTS `wf_transition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wf_transition` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `currentState_id` bigint(20) NOT NULL,
  `form_id` bigint(20) NOT NULL,
  `nextState_id` bigint(20) NOT NULL,
  `process_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKp1w8snyjgn1kslmn96iefhwwp` (`nguoiSua_id`),
  KEY `FKikhx6ex9a2hb0hysjqefwphub` (`nguoiTao_id`),
  KEY `FKkp7pja633l2ks30et92m11b9k` (`currentState_id`),
  KEY `FKgax7pfxrbm1droa3nwdtxvopf` (`form_id`),
  KEY `FKrfk6n3ds4jr0hv5ptoo1je3l3` (`nextState_id`),
  KEY `FKdcmimeash24b61vjf4b65t6ej` (`process_id`)
) ENGINE=MyISAM AUTO_INCREMENT=240 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wf_transition`
--

LOCK TABLES `wf_transition` WRITE;
/*!40000 ALTER TABLE `wf_transition` DISABLE KEYS */;
INSERT INTO `wf_transition` VALUES (1,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,1),(2,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,2),(3,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,3,3),(5,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,3,5,4),(8,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,4,8,5),(14,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,4,8,5),(15,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,9,3),(43,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,12,18,8,8),(42,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,11,18,12,8),(41,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,18,8),(40,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,8,8),(26,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,14,2,11),(27,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,3,9),(29,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,16,5,10),(32,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,17,15,12),(35,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,11,5,6),(45,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,17,15,12),(47,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,9,9),(50,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,1,16,13),(51,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,22,16,13),(53,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,19,2,14),(56,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,21,5,15),(58,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,9,16),(61,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,3,16),(62,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,46),(63,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,47),(64,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,48),(65,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,49),(66,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,50),(69,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,53),(70,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,54),(71,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,55),(72,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,56),(73,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,57),(75,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,3,17),(76,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,3,18),(77,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,3,19),(78,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,3,20),(79,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,3,21),(82,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,9,17),(83,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,9,18),(84,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,9,19),(85,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,9,20),(86,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,9,21),(87,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,4,8,22),(89,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,3,5,24),(90,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,3,5,25),(91,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,3,5,26),(92,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,3,5,27),(93,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,3,5,28),(96,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,4,8,39),(97,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,4,8,40),(98,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,4,8,41),(99,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,4,8,42),(100,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,4,8,43),(103,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,4,8,39),(104,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,4,8,40),(105,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,4,8,41),(106,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,4,8,42),(107,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,4,8,43),(109,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,4,8,45),(110,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,4,8,23),(111,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,12,8,59),(112,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,11,5,61),(113,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,11,5,62),(114,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,11,5,63),(115,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,11,5,64),(116,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,11,5,65),(117,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,11,18,12,66),(118,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,11,18,12,67),(119,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,11,18,12,68),(120,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,11,18,12,69),(121,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,11,18,12,70),(122,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,18,66),(123,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,18,67),(124,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,18,68),(125,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,18,69),(126,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,18,70),(127,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,8,66),(128,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,8,67),(129,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,8,68),(130,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,8,69),(131,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,8,70),(132,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,12,18,8,66),(133,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,12,18,8,67),(134,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,12,18,8,68),(135,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,12,18,8,69),(136,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,12,18,8,70),(142,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,3,76),(143,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,3,77),(144,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,3,78),(145,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,3,79),(146,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,9,76),(147,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,9,77),(148,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,9,78),(149,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,15,9,79),(150,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,16,5,80),(151,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,16,5,81),(152,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,16,5,82),(153,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,16,5,83),(154,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,17,15,84),(155,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,17,15,85),(156,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,17,15,86),(157,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,17,15,87),(158,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,17,15,84),(159,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,17,15,85),(160,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,17,15,86),(161,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,17,15,87),(162,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,14,2,88),(163,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,14,2,89),(164,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,14,2,90),(165,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,14,2,91),(166,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,4,8,92),(167,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,12,8,93),(168,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,1),(169,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,46),(170,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,47),(171,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,48),(172,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,49),(173,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,50),(174,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,53),(175,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,54),(176,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,55),(177,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,56),(178,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,57),(179,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,2),(180,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,12,8,94),(181,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,12,8,95),(182,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,12,8,96),(183,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,12,8,97),(184,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,12,8,98),(185,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,4,8,99),(186,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,4,8,100),(187,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,4,8,101),(188,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,4,8,102),(189,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,4,8,103),(190,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,104),(191,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,104),(192,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,2,105),(193,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,1,17,105),(194,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,3,106),(195,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,2,9,106),(196,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,3,5,107),(197,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,4,8,108),(198,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,4,8,108),(199,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,11,5,109),(200,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,12,18,8,110),(201,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,11,18,12,110),(202,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,18,110),(203,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,12,8,110),(204,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,22,16,111),(205,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,22,16,111),(206,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,19,2,112),(207,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,21,5,113),(208,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,9,114),(209,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,3,114),(210,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,9,115),(211,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,9,116),(212,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,9,117),(213,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,9,118),(214,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,9,119),(215,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,3,115),(216,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,3,116),(217,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,3,117),(218,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,3,118),(219,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,2,20,3,119),(220,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,21,5,120),(221,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,21,5,121),(222,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,21,5,122),(223,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,21,5,123),(224,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,3,21,5,124),(225,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,22,16,125),(226,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,22,16,126),(227,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,22,16,127),(228,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,22,16,128),(229,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,5,22,16,129),(230,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,22,16,125),(231,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,22,16,126),(232,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,22,16,127),(233,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,22,16,128),(234,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,9,22,16,129),(235,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,19,2,130),(236,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,19,2,131),(237,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,19,2,132),(238,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,19,2,133),(239,'\0','2017-05-03 13:20:39','2017-05-03 13:20:39',1,1,1,19,2,134);
/*!40000 ALTER TABLE `wf_transition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xulydon`
--

DROP TABLE IF EXISTS `xulydon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xulydon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `daXoa` bit(1) NOT NULL,
  `ngaySua` datetime DEFAULT NULL,
  `ngayTao` datetime DEFAULT NULL,
  `chucVu` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `chucVuGiaoViec` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `diaDiem` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `donChuyen` bit(1) NOT NULL,
  `donTra` bit(1) NOT NULL,
  `ghiChu` longtext COLLATE utf8_vietnamese_ci,
  `huongXuLy` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `moTaTrangThai` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `ngayHenGapLanhDao` datetime DEFAULT NULL,
  `ngayQuyetDinhDinhChi` datetime DEFAULT NULL,
  `noiDungXuLy` longtext COLLATE utf8_vietnamese_ci,
  `old` bit(1) NOT NULL,
  `soQuyetDinhDinhChi` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `thuTuThucHien` int(11) NOT NULL,
  `trangThaiDon` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `nguoiSua_id` bigint(20) DEFAULT NULL,
  `nguoiTao_id` bigint(20) DEFAULT NULL,
  `canBoChuyenDon_id` bigint(20) DEFAULT NULL,
  `canBoGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `canBoXuLy_id` bigint(20) DEFAULT NULL,
  `canBoXuLyChiDinh_id` bigint(20) DEFAULT NULL,
  `chuyenVienChiDinh_id` bigint(20) DEFAULT NULL,
  `coQuanChuyenDon_id` bigint(20) DEFAULT NULL,
  `coQuanTiepNhan_id` bigint(20) DEFAULT NULL,
  `congChuc_id` bigint(20) DEFAULT NULL,
  `don_id` bigint(20) DEFAULT NULL,
  `donViXuLy_id` bigint(20) DEFAULT NULL,
  `nextForm_id` bigint(20) DEFAULT NULL,
  `nextState_id` bigint(20) DEFAULT NULL,
  `phongBanGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `phongBanXuLy_id` bigint(20) DEFAULT NULL,
  `phongBanXuLyChiDinh_id` bigint(20) DEFAULT NULL,
  `thamQuyenGiaiQuyet_id` bigint(20) DEFAULT NULL,
  `truongPhongChiDinh_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKimnqncmjaeqlwywm28g1uyv6y` (`nguoiSua_id`),
  KEY `FKdsdt96gw7ak1k3x54w6k7ihaw` (`nguoiTao_id`),
  KEY `FKc9aencdo4qto9vyi42asnt3xk` (`canBoChuyenDon_id`),
  KEY `FKsncedahl1937etygc0ne3nvsy` (`canBoGiaiQuyet_id`),
  KEY `FK9ipyliv44wr0tht0x6w0b5ker` (`canBoXuLy_id`),
  KEY `FK1wbfcaniqa9bj0ehcm0iip0hn` (`canBoXuLyChiDinh_id`),
  KEY `FKmt2eql5y271ryhct6a49ik6pd` (`chuyenVienChiDinh_id`),
  KEY `FKofebyud3a5iipeeq6kq4dpg7q` (`coQuanChuyenDon_id`),
  KEY `FKhdd3wbwlbtro4kiqx66gmvgj5` (`coQuanTiepNhan_id`),
  KEY `FKb6ncetnq1ib406vpj9kww15vw` (`congChuc_id`),
  KEY `FK2jqskulrukamhc8897sofcxja` (`don_id`),
  KEY `FKjyisvmnq0p5mo6aia9bo2swu` (`donViXuLy_id`),
  KEY `FKhyn2golfeq05idlub5u4ir3wt` (`nextForm_id`),
  KEY `FKjvfjbuxsrn45haq7cll9eb42y` (`nextState_id`),
  KEY `FK9rk7scncacsb59wjw6t6p2bn3` (`phongBanGiaiQuyet_id`),
  KEY `FKe0w8kx6irtoyqc88bcaqi0x61` (`phongBanXuLy_id`),
  KEY `FKl94mjqmxb6vchw7y3h1m3a6dr` (`phongBanXuLyChiDinh_id`),
  KEY `FK79w5mvipene2vpj5aj4rt478` (`thamQuyenGiaiQuyet_id`),
  KEY `FKbatv5t5xyrrat4aueg3eafyit` (`truongPhongChiDinh_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xulydon`
--

LOCK TABLES `xulydon` WRITE;
/*!40000 ALTER TABLE `xulydon` DISABLE KEYS */;
/*!40000 ALTER TABLE `xulydon` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-26  8:21:35
